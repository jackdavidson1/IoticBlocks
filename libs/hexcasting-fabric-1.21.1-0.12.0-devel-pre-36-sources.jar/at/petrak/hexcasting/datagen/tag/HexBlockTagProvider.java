package at.petrak.hexcasting.datagen.tag;

import at.petrak.hexcasting.api.mod.HexTags;
import at.petrak.hexcasting.common.lib.HexBlocks;
import at.petrak.hexcasting.xplat.IXplatTags;
import java.util.concurrent.CompletableFuture;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2474;
import net.minecraft.class_2960;
import net.minecraft.class_3481;
import net.minecraft.class_6862;
import net.minecraft.class_7225;
import net.minecraft.class_7784;
import net.minecraft.class_7923;
import net.minecraft.class_7924;

public class HexBlockTagProvider extends class_2474<class_2248> {
    public final IXplatTags xtags;

    public HexBlockTagProvider(class_7784 output, CompletableFuture<class_7225.class_7874> lookupProvider, IXplatTags xtags) {
        super(output, class_7924.field_41254, lookupProvider);
        this.xtags = xtags;
    }

    @Override
    protected void method_10514(class_7225.class_7874 provider) {
        add(method_10512(HexTags.Blocks.IMPETI),
            HexBlocks.IMPETUS_LOOK.get(), HexBlocks.IMPETUS_RIGHTCLICK.get(), HexBlocks.IMPETUS_REDSTONE.get());
        add(method_10512(HexTags.Blocks.DIRECTRICES),
            HexBlocks.DIRECTRIX_REDSTONE.get(), HexBlocks.DIRECTRIX_BOOLEAN.get());
        method_10512(HexTags.Blocks.MINDFLAYED_CIRCLE_COMPONENTS)
            .method_26792(HexTags.Blocks.IMPETI)
            .method_26792(HexTags.Blocks.DIRECTRICES);

        add(method_10512(class_3481.field_33715),
            HexBlocks.SLATE_BLOCK.get(), HexBlocks.SLATE_TILES.get(), HexBlocks.SLATE_BRICKS.get(),
            HexBlocks.SLATE_BRICKS_SMALL.get(), HexBlocks.SLATE_PILLAR.get(), HexBlocks.SLATE.get(),
            HexBlocks.EMPTY_DIRECTRIX.get(), HexBlocks.DIRECTRIX_REDSTONE.get(), HexBlocks.DIRECTRIX_BOOLEAN.get(),
            HexBlocks.IMPETUS_EMPTY.get(),
            HexBlocks.IMPETUS_RIGHTCLICK.get(), HexBlocks.IMPETUS_LOOK.get(), HexBlocks.IMPETUS_REDSTONE.get(),
            HexBlocks.AMETHYST_TILES.get(), HexBlocks.AMETHYST_BRICKS.get(), HexBlocks.AMETHYST_BRICKS_SMALL.get(),
            HexBlocks.AMETHYST_PILLAR.get(), HexBlocks.SLATE_AMETHYST_TILES.get(), HexBlocks.SLATE_AMETHYST_BRICKS.get(),
            HexBlocks.SLATE_AMETHYST_BRICKS_SMALL.get(), HexBlocks.SLATE_AMETHYST_PILLAR.get(), HexBlocks.SCONCE.get(),
            HexBlocks.QUENCHED_ALLAY.get(), HexBlocks.QUENCHED_ALLAY_TILES.get(), HexBlocks.QUENCHED_ALLAY_BRICKS.get(),
            HexBlocks.QUENCHED_ALLAY_BRICKS_SMALL.get());

        add(method_10512(class_3481.field_33716),
            HexBlocks.AMETHYST_DUST_BLOCK.get());

        add(method_10512(class_3481.field_33713),
            HexBlocks.AKASHIC_RECORD.get(), HexBlocks.AKASHIC_BOOKSHELF.get(), HexBlocks.AKASHIC_LIGATURE.get(),
            HexBlocks.EDIFIED_LOG.get(), HexBlocks.EDIFIED_LOG_AMETHYST.get(),
            HexBlocks.EDIFIED_LOG_AVENTURINE.get(), HexBlocks.EDIFIED_LOG_CITRINE.get(),
            HexBlocks.EDIFIED_LOG_PURPLE.get(), HexBlocks.STRIPPED_EDIFIED_LOG.get(),
            HexBlocks.EDIFIED_WOOD.get(), HexBlocks.STRIPPED_EDIFIED_WOOD.get(),
            HexBlocks.EDIFIED_PLANKS.get(), HexBlocks.EDIFIED_PANEL.get(), HexBlocks.EDIFIED_TILE.get(),
            HexBlocks.EDIFIED_DOOR.get(), HexBlocks.EDIFIED_TRAPDOOR.get(), HexBlocks.EDIFIED_SLAB.get(),
            HexBlocks.EDIFIED_BUTTON.get(), HexBlocks.EDIFIED_STAIRS.get(), HexBlocks.EDIFIED_FENCE.get(), HexBlocks.EDIFIED_FENCE_GATE.get());

        add(method_10512(class_3481.field_33714),
            HexBlocks.AMETHYST_EDIFIED_LEAVES.get(), HexBlocks.AVENTURINE_EDIFIED_LEAVES.get(),
            HexBlocks.CITRINE_EDIFIED_LEAVES.get());

        add(method_10512(class_3481.field_26986),
            HexBlocks.CONJURED_LIGHT.get(), HexBlocks.CONJURED_BLOCK.get(), HexBlocks.AMETHYST_TILES.get(),
            HexBlocks.SCONCE.get());

        add(method_10512(HexTags.Blocks.EDIFIED_LOGS),
            HexBlocks.EDIFIED_LOG.get(), HexBlocks.EDIFIED_LOG_AMETHYST.get(),
            HexBlocks.EDIFIED_LOG_AVENTURINE.get(), HexBlocks.EDIFIED_LOG_CITRINE.get(),
            HexBlocks.EDIFIED_LOG_PURPLE.get(), HexBlocks.STRIPPED_EDIFIED_LOG.get(),
            HexBlocks.EDIFIED_WOOD.get(), HexBlocks.STRIPPED_EDIFIED_WOOD.get());
        add(method_10512(class_3481.field_15475),
            HexBlocks.EDIFIED_LOG.get(), HexBlocks.EDIFIED_LOG_AMETHYST.get(),
            HexBlocks.EDIFIED_LOG_AVENTURINE.get(), HexBlocks.EDIFIED_LOG_CITRINE.get(),
            HexBlocks.EDIFIED_LOG_PURPLE.get(), HexBlocks.STRIPPED_EDIFIED_LOG.get(),
            HexBlocks.EDIFIED_WOOD.get(), HexBlocks.STRIPPED_EDIFIED_WOOD.get());
        add(method_10512(class_3481.field_23210),
            HexBlocks.EDIFIED_LOG.get(), HexBlocks.EDIFIED_LOG_AMETHYST.get(),
            HexBlocks.EDIFIED_LOG_AVENTURINE.get(), HexBlocks.EDIFIED_LOG_CITRINE.get(),
            HexBlocks.EDIFIED_LOG_PURPLE.get(), HexBlocks.STRIPPED_EDIFIED_LOG.get(),
            HexBlocks.EDIFIED_WOOD.get(), HexBlocks.STRIPPED_EDIFIED_WOOD.get());
        add(method_10512(class_3481.field_15503),
            HexBlocks.AMETHYST_EDIFIED_LEAVES.get(), HexBlocks.AVENTURINE_EDIFIED_LEAVES.get(),
            HexBlocks.CITRINE_EDIFIED_LEAVES.get());

        add(method_10512(class_3481.field_15471),
            HexBlocks.EDIFIED_PLANKS.get(), HexBlocks.EDIFIED_PANEL.get(), HexBlocks.EDIFIED_TILE.get());
        add(method_10512(HexTags.Blocks.EDIFIED_PLANKS),
            HexBlocks.EDIFIED_PLANKS.get(), HexBlocks.EDIFIED_PANEL.get(), HexBlocks.EDIFIED_TILE.get());
        add(method_10512(class_3481.field_15469),
            HexBlocks.EDIFIED_SLAB.get());
        add(method_10512(class_3481.field_15468),
            HexBlocks.EDIFIED_SLAB.get());
        add(method_10512(class_3481.field_15459),
            HexBlocks.EDIFIED_STAIRS.get());
        add(method_10512(class_3481.field_16584),
            HexBlocks.EDIFIED_FENCE.get());
        add(method_10512(class_3481.field_17619),
            HexBlocks.EDIFIED_FENCE.get());
        add(method_10512(class_3481.field_25147),
            HexBlocks.EDIFIED_FENCE_GATE.get());
        add(method_10512(class_3481.field_25148),
            HexBlocks.EDIFIED_FENCE_GATE.get());


        add(method_10512(class_3481.field_17619),
            HexBlocks.EDIFIED_FENCE.get());
        add(method_10512(class_3481.field_15502),
            HexBlocks.EDIFIED_STAIRS.get());
        add(method_10512(class_3481.field_15495),
            HexBlocks.EDIFIED_DOOR.get());
        add(method_10512(class_3481.field_15494),
            HexBlocks.EDIFIED_DOOR.get());
        add(method_10512(class_3481.field_15487),
            HexBlocks.EDIFIED_TRAPDOOR.get());
        add(method_10512(class_3481.field_15491),
            HexBlocks.EDIFIED_TRAPDOOR.get());
        add(method_10512(class_3481.field_24076),
            HexBlocks.EDIFIED_PRESSURE_PLATE.get());
        add(method_10512(class_3481.field_15477),
            HexBlocks.EDIFIED_PRESSURE_PLATE.get());
        add(method_10512(class_3481.field_15493),
            HexBlocks.EDIFIED_BUTTON.get());
        add(method_10512(class_3481.field_15499),
            HexBlocks.EDIFIED_BUTTON.get());

        add(method_10512(HexTags.Blocks.WATER_PLANTS),
            class_2246.field_9993, class_2246.field_10463, class_2246.field_10376, class_2246.field_10238);
        add(method_10512(HexTags.Blocks.CHEAP_TO_BREAK_BLOCK),
            HexBlocks.CONJURED_BLOCK.get(), HexBlocks.CONJURED_LIGHT.get());

        add(method_10512(HexTags.Blocks.SLATE_BLOCKS),
            HexBlocks.SLATE_BLOCK.get(), HexBlocks.SLATE_BRICKS.get(), HexBlocks.SLATE_BRICKS_SMALL.get(), HexBlocks.SLATE_TILES.get(), HexBlocks.SLATE_PILLAR.get());
        add(method_10512(HexTags.Blocks.AMETHYST_BLOCKS),
            class_2246.field_27159, HexBlocks.AMETHYST_BRICKS.get(), HexBlocks.AMETHYST_BRICKS_SMALL.get(), HexBlocks.AMETHYST_TILES.get(), HexBlocks.AMETHYST_PILLAR.get());
        add(method_10512(HexTags.Blocks.QUENCHED_ALLAY_BLOCKS),
            HexBlocks.QUENCHED_ALLAY.get(), HexBlocks.QUENCHED_ALLAY_BRICKS.get(), HexBlocks.QUENCHED_ALLAY_BRICKS_SMALL.get(), HexBlocks.QUENCHED_ALLAY_TILES.get());

        // this is a hack but fixes #532
        var createBrittle = class_6862.method_40092(class_7924.field_41254, class_2960.method_60655("create", "brittle"));
        method_10512(createBrittle).method_35923(class_7923.field_41175.method_10221(HexBlocks.SLATE.get()));
    }

    void add(class_2474.class_5124<class_2248> appender, class_2248... blocks) {
        for (class_2248 block : blocks) {
            appender.method_46835(class_7923.field_41175.method_29113(block).orElseThrow());
        }
    }
}
