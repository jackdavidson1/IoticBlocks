package at.petrak.hexcasting.datagen;

import at.petrak.hexcasting.api.HexAPI;
import at.petrak.hexcasting.common.lib.HexBlocks;
import at.petrak.hexcasting.common.lib.HexDataComponents;
import at.petrak.hexcasting.common.lib.HexItems;
import at.petrak.hexcasting.common.loot.HexLootHandler;
import at.petrak.hexcasting.xplat.IXplatAbstractions;
import at.petrak.paucal.api.datagen.PaucalLootTableSubProvider;
import net.minecraft.advancements.critereon.*;
import net.minecraft.class_104;
import net.minecraft.class_141;
import net.minecraft.class_182;
import net.minecraft.class_1887;
import net.minecraft.class_1893;
import net.minecraft.class_2035;
import net.minecraft.class_2073;
import net.minecraft.class_2096;
import net.minecraft.class_212;
import net.minecraft.class_219;
import net.minecraft.class_223;
import net.minecraft.class_2248;
import net.minecraft.class_2323;
import net.minecraft.class_2482;
import net.minecraft.class_2756;
import net.minecraft.class_2771;
import net.minecraft.class_3489;
import net.minecraft.class_44;
import net.minecraft.class_4559;
import net.minecraft.class_52;
import net.minecraft.class_5321;
import net.minecraft.class_55;
import net.minecraft.class_5662;
import net.minecraft.class_65;
import net.minecraft.class_7225;
import net.minecraft.class_77;
import net.minecraft.class_7924;
import net.minecraft.class_8551;
import net.minecraft.class_9317;
import net.minecraft.class_9356;
import net.minecraft.class_9361;
import net.minecraft.class_94;
import net.minecraft.world.level.storage.loot.predicates.*;
import java.util.List;
import java.util.Map;

public class HexLootTables extends PaucalLootTableSubProvider {
    private final class_7225.class_7874 registries;

    public HexLootTables(class_7225.class_7874 registries) {
        super(HexAPI.MOD_ID);
        this.registries = registries;
    }

    @Override
    protected void makeLootTables(Map<class_2248, class_52.class_53> blockTables,
        Map<class_5321<class_52>, class_52.class_53> lootTables) {
        dropSelf(blockTables, HexBlocks.IMPETUS_EMPTY.get(),
            HexBlocks.IMPETUS_RIGHTCLICK.get(), HexBlocks.IMPETUS_LOOK.get(), HexBlocks.IMPETUS_REDSTONE.get(),
            HexBlocks.EMPTY_DIRECTRIX.get(), HexBlocks.DIRECTRIX_REDSTONE.get(), HexBlocks.DIRECTRIX_BOOLEAN.get(),
            HexBlocks.AKASHIC_RECORD.get(), HexBlocks.AKASHIC_BOOKSHELF.get(), HexBlocks.AKASHIC_LIGATURE.get(),
            HexBlocks.SLATE_BLOCK.get(), HexBlocks.SLATE_TILES.get(), HexBlocks.SLATE_BRICKS.get(), HexBlocks.SLATE_BRICKS_SMALL.get(),
            HexBlocks.SLATE_PILLAR.get(), HexBlocks.AMETHYST_DUST_BLOCK.get(), HexBlocks.AMETHYST_TILES.get(), HexBlocks.AMETHYST_BRICKS.get(),
            HexBlocks.AMETHYST_BRICKS_SMALL.get(), HexBlocks.AMETHYST_PILLAR.get(), HexBlocks.SLATE_AMETHYST_TILES.get(),
            HexBlocks.SLATE_AMETHYST_BRICKS.get(), HexBlocks.SLATE_AMETHYST_BRICKS_SMALL.get(), HexBlocks.SLATE_AMETHYST_PILLAR.get(),
            HexBlocks.QUENCHED_ALLAY_TILES.get(), HexBlocks.QUENCHED_ALLAY_BRICKS.get(), HexBlocks.QUENCHED_ALLAY_BRICKS_SMALL.get(),
            HexBlocks.SCROLL_PAPER.get(), HexBlocks.ANCIENT_SCROLL_PAPER.get(), HexBlocks.SCROLL_PAPER_LANTERN.get(),
            HexBlocks.ANCIENT_SCROLL_PAPER_LANTERN.get(), HexBlocks.SCONCE.get(),
            HexBlocks.EDIFIED_LOG.get(), HexBlocks.EDIFIED_LOG_AMETHYST.get(), HexBlocks.EDIFIED_LOG_AVENTURINE.get(),
            HexBlocks.EDIFIED_LOG_CITRINE.get(), HexBlocks.EDIFIED_LOG_PURPLE.get(), HexBlocks.STRIPPED_EDIFIED_LOG.get(),
            HexBlocks.EDIFIED_WOOD.get(), HexBlocks.STRIPPED_EDIFIED_WOOD.get(),
            HexBlocks.EDIFIED_PLANKS.get(), HexBlocks.EDIFIED_TILE.get(), HexBlocks.EDIFIED_PANEL.get(),
            HexBlocks.EDIFIED_TRAPDOOR.get(), HexBlocks.EDIFIED_STAIRS.get(), HexBlocks.EDIFIED_FENCE.get(), HexBlocks.EDIFIED_FENCE_GATE.get(), HexBlocks.EDIFIED_PRESSURE_PLATE.get(),
            HexBlocks.EDIFIED_BUTTON.get());

        class_7225.class_7226<class_1887> enchRegistryLookup = this.registries.method_46762(class_7924.field_41265);

        makeSlabTable(blockTables, HexBlocks.EDIFIED_SLAB.get());

        makeLeafTable(blockTables, HexBlocks.AMETHYST_EDIFIED_LEAVES.get(), enchRegistryLookup);
        makeLeafTable(blockTables, HexBlocks.AVENTURINE_EDIFIED_LEAVES.get(), enchRegistryLookup);
        makeLeafTable(blockTables, HexBlocks.CITRINE_EDIFIED_LEAVES.get(), enchRegistryLookup);

        var slatePool = class_55.method_347()
            .method_352(class_44.method_32448(1))
            .method_351(class_77.method_411(HexBlocks.SLATE.get())
                .method_438(class_9317.method_57637(class_9317.class_9319.field_49436)
                        .method_58730(HexDataComponents.PATTERN.get())
                ));
        blockTables.put(HexBlocks.SLATE.get(), class_52.method_324().method_336(slatePool));

        var doorPool = dropThisPool(HexBlocks.EDIFIED_DOOR.get(), 1)
            .method_356(new class_212.class_213(HexBlocks.EDIFIED_DOOR.get()).method_22584(
                class_4559.class_4560.method_22523().method_22525(class_2323.field_10946, class_2756.field_12607)
            ));
        blockTables.put(HexBlocks.EDIFIED_DOOR.get(), class_52.method_324().method_336(doorPool));

        var silkTouchCond = class_223.method_945(
            class_2073.class_2074.method_8973().method_58179(
                    class_9361.field_49807,
                    class_9356.method_58173(
                            List.of(new class_2035(enchRegistryLookup.method_46747(class_1893.field_9099), class_2096.class_2100.method_9053(1)))
                    )
            ));
        var noSilkTouchCond = silkTouchCond.method_16780();
        var goodAtAmethystingCond = class_223.method_945(
            class_2073.class_2074.method_8973().method_8975(class_3489.field_29544)
        );

        var dustPoolWhenGood = class_55.method_347()
            .method_351(class_77.method_411(HexItems.AMETHYST_DUST.get()))
            .method_353(class_141.method_621(class_5662.method_32462(1, 4)))
            .method_353(class_94.method_455(enchRegistryLookup.method_46747(class_1893.field_9130)))
            .method_356(noSilkTouchCond).method_356(goodAtAmethystingCond);

        var dustPoolWhenBad = class_55.method_347()
            .method_351(class_77.method_411(HexItems.AMETHYST_DUST.get()))
            .method_353(class_141.method_621(class_5662.method_32462(0, 2)))
            .method_356(noSilkTouchCond).method_356(goodAtAmethystingCond.method_16780());

        var isThatAnMFingBrandonSandersonReference = class_55.method_347()
            .method_351(class_77.method_411(HexItems.CHARGED_AMETHYST.get()))
            .method_353(class_141.method_621(class_44.method_32448(1)))
            .method_356(noSilkTouchCond).method_356(goodAtAmethystingCond)
            .method_356(class_182.method_800(enchRegistryLookup.method_46747(class_1893.field_9130),
                0.25f, 0.35f, 0.5f, 0.75f, 1.0f));

        var isThatAnMFingBadBrandonSandersonReference = class_55.method_347()
            .method_351(class_77.method_411(HexItems.CHARGED_AMETHYST.get()))
            .method_353(class_141.method_621(class_44.method_32448(1)))
            .method_356(noSilkTouchCond).method_356(goodAtAmethystingCond.method_16780())
            .method_356(class_219.method_932(0.125f));

        HexAPI.LOGGER.info("Doing amethyst cluster injection shit");

        lootTables.put(HexLootHandler.TABLE_INJECT_AMETHYST_CLUSTER, class_52.method_324()
            .method_336(dustPoolWhenGood)
            .method_336(dustPoolWhenBad)
            .method_336(isThatAnMFingBrandonSandersonReference)
            .method_336(isThatAnMFingBadBrandonSandersonReference));

        HexAPI.LOGGER.info("Quenched bugged...?");

        // it looks like loot groups are bugged?
        // so instead we add some and then *increment* the amount, gated behind the cond
        var quenchedPool = class_55.method_347().method_351(class_65.method_386(
            class_77.method_411(HexBlocks.QUENCHED_ALLAY.get()).method_421(silkTouchCond),
            class_77.method_411(HexItems.QUENCHED_SHARD.get())
                .method_438(class_141.method_621(class_5662.method_32462(2f, 4f)))
                .method_438(class_141.method_35540(class_44.method_32448(1), true)
                    .method_524(class_182.method_800(enchRegistryLookup.method_46747(class_1893.field_9130),
                        0.25f, 0.5f, 0.75f, 1.0f)))
        ));
        blockTables.put(HexBlocks.QUENCHED_ALLAY.get(), class_52.method_324().method_336(quenchedPool));
    }

    private void makeLeafTable(Map<class_2248, class_52.class_53> lootTables, class_2248 block, class_7225.class_7226<class_1887> enchRegistryLookup) {
        var leafPool = dropThisPool(block, 1)
            .method_356(class_8551.method_51727(
                IXplatAbstractions.INSTANCE.isShearsCondition(),
                class_223.method_945(class_2073.class_2074.method_8973()
                        .method_58179(
                                class_9361.field_49807,
                                class_9356.method_58173(
                                        List.of(new class_2035(enchRegistryLookup.method_46747(class_1893.field_9099), class_2096.class_2100.method_9053(1)))
                                )
                        )
            )));
        lootTables.put(block, class_52.method_324().method_336(leafPool));
    }

    private void makeSlabTable(Map<class_2248, class_52.class_53> lootTables, class_2248 block) {
        var leafPool = dropThisPool(block, 1)
            .method_353(class_141.method_621(class_44.method_32448(2))
                .method_524(new class_212.class_213(block).method_22584(
                    class_4559.class_4560.method_22523().method_22525(class_2482.field_11501, class_2771.field_12682)
                )))
            .method_353(class_104.method_478());
        lootTables.put(block, class_52.method_324().method_336(leafPool));
    }
}
