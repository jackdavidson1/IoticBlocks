package at.petrak.hexcasting.fabric

import at.petrak.hexcasting.api.HexAPI.modLoc
import at.petrak.hexcasting.api.addldata.ADMediaHolder
import at.petrak.hexcasting.api.advancements.HexAdvancementTriggers
import at.petrak.hexcasting.api.casting.ActionRegistryEntry
import at.petrak.hexcasting.api.casting.iota.DoubleIota
import at.petrak.hexcasting.api.item.HexHolderItem
import at.petrak.hexcasting.api.item.IotaHolderItem
import at.petrak.hexcasting.api.item.MediaHolderItem
import at.petrak.hexcasting.api.item.PigmentItem
import at.petrak.hexcasting.api.item.VariantItem
import at.petrak.hexcasting.api.misc.MediaConstants
import at.petrak.hexcasting.api.mod.HexConfig
import at.petrak.hexcasting.api.mod.HexStatistics
import at.petrak.hexcasting.api.mod.HexTags
import at.petrak.hexcasting.api.utils.isOfTag
import at.petrak.hexcasting.common.blocks.behavior.HexComposting
import at.petrak.hexcasting.common.blocks.behavior.HexStrippables
import at.petrak.hexcasting.common.casting.PatternRegistryManifest
import at.petrak.hexcasting.common.casting.actions.spells.OpFlight
import at.petrak.hexcasting.common.casting.actions.spells.great.OpAltiora
import at.petrak.hexcasting.common.command.PatternResKeyArgument
import at.petrak.hexcasting.common.entities.HexEntities
import at.petrak.hexcasting.common.items.ItemJewelerHammer
import at.petrak.hexcasting.common.items.magic.ItemMediaBattery
import at.petrak.hexcasting.common.items.storage.ItemScroll
import at.petrak.hexcasting.common.lib.*
import at.petrak.hexcasting.common.lib.hex.*
import at.petrak.hexcasting.common.misc.AkashicTreeGrower
import at.petrak.hexcasting.common.misc.BrainsweepingEvents
import at.petrak.hexcasting.common.misc.PlayerPositionRecorder
import at.petrak.hexcasting.common.misc.RegisterMisc
import at.petrak.hexcasting.common.recipe.HexRecipeStuffRegistry
import at.petrak.hexcasting.common.lib.HexBrainsweepeeIngredients
import at.petrak.hexcasting.common.lib.HexStateIngredients
import at.petrak.hexcasting.fabric.cc.HexCardinalComponents
import at.petrak.hexcasting.fabric.cc.adimpl.*
import at.petrak.hexcasting.fabric.event.VillagerConversionCallback
import at.petrak.hexcasting.fabric.loot.FabricHexLootModJankery
import at.petrak.hexcasting.fabric.network.FabricPacketHandler
import at.petrak.hexcasting.fabric.recipe.FabricModConditionalIngredient
import at.petrak.hexcasting.fabric.recipe.FabricUnsealedIngredient
import at.petrak.hexcasting.fabric.storage.FabricImpetusStorage
import at.petrak.hexcasting.fabric.xplat.FabricXplatImpl
import at.petrak.hexcasting.interop.HexInterop
import at.petrak.hexcasting.xplat.IXplatAbstractions
import com.samsthenerd.inline.utils.cradles.EntTypeCradle
import net.fabricmc.api.ModInitializer
import net.fabricmc.fabric.api.command.v2.ArgumentTypeRegistry
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback
import net.fabricmc.fabric.api.entity.event.v1.EntityElytraEvents
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents
import net.fabricmc.fabric.api.event.player.AttackBlockCallback
import net.fabricmc.fabric.api.event.player.UseEntityCallback
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents
import net.fabricmc.fabric.api.loot.v3.LootTableEvents
import net.fabricmc.fabric.api.`object`.builder.v1.entity.FabricDefaultAttributeRegistry
import net.fabricmc.fabric.api.recipe.v1.ingredient.CustomIngredientSerializer
import net.fabricmc.fabric.api.registry.FabricBrewingRecipeRegistryBuilder
import net.fabricmc.fabric.api.registry.FlammableBlockRegistry
import net.minecraft.commands.synchronization.SingletonArgumentInfo
import net.minecraft.core.Registry
import net.minecraft.core.registries.BuiltInRegistries
import net.minecraft.resources.ResourceKey
import net.minecraft.resources.ResourceLocation
import net.minecraft.world.InteractionResult
import net.minecraft.world.entity.EntityType
import net.minecraft.world.entity.player.Player
import net.minecraft.world.item.Item
import net.minecraft.world.item.ItemStack
import net.minecraft.world.item.Items
import net.minecraft.world.level.block.Blocks
import net.minecraft.world.level.block.state.properties.BlockSetType
import net.minecraft.world.level.storage.loot.functions.SetItemCountFunction
import net.minecraft.world.level.storage.loot.providers.number.UniformGenerator
import java.util.function.BiConsumer
import java.util.function.Function

object FabricHexInitializer : ModInitializer {
    lateinit var CONFIG: FabricHexConfig

    override fun onInitialize() {
        this.CONFIG = FabricHexConfig.setup()
        // workaround for Inline EntTypeCradles not being available on server, related to https://github.com/SamsTheNerd/inline/issues/34
        EntTypeCradle.fromTypeId(ResourceLocation.fromNamespaceAndPath("minecraft", "pig")).get().getType();
        FabricPacketHandler.initPackets()
        FabricPacketHandler.init()

        initListeners()

        initRegistries()

        ArgumentTypeRegistry.registerArgumentType(
            modLoc("pattern"),
            PatternResKeyArgument::class.java,
            SingletonArgumentInfo.contextFree { PatternResKeyArgument.id() }
        )
        HexAdvancementTriggers.register()
        HexComposting.setup()
        HexStrippables.init()
        FabricImpetusStorage.registerStorage()

        LootTableEvents.MODIFY.register { key, tableBuilder, source, lookup ->
            if (Blocks.AMETHYST_CLUSTER.lootTable.equals(key)) {
                tableBuilder.modifyPools { pool ->
                    pool.apply(SetItemCountFunction.setCount(UniformGenerator.between(1.0f, 2.0f)))
                }
            }
        }

        HexInterop.init()
        RegisterMisc.register()
    }

    // this global is for both server and client because PatternRegistryManifest.processRegistry
    // doesn't have separate processing for each
    internal var patternRegistryIsProcessed: Boolean = false
    fun initListeners() {
        UseEntityCallback.EVENT.register(BrainsweepingEvents::interactWithBrainswept)
        VillagerConversionCallback.EVENT.register(BrainsweepingEvents::copyBrainsweepPostTransformation)
        AttackBlockCallback.EVENT.register { player, world, _, pos, _ ->
            // SUCCESS cancels further processing and, on the client, sends a packet to the server.
            // PASS falls back to further processing.
            // FAIL cancels further processing and does not send a packet to the server.
            if (ItemJewelerHammer.shouldFailToBreak(player, world.getBlockState(pos), pos)) {
                InteractionResult.SUCCESS // "success"
            } else {
                InteractionResult.PASS
            }
        }


        ServerLifecycleEvents.SERVER_STARTED.register { server ->
            if (!patternRegistryIsProcessed) {
                PatternRegistryManifest.processRegistry(server.overworld())
                patternRegistryIsProcessed = true
            }
        }

        ServerTickEvents.END_WORLD_TICK.register(PlayerPositionRecorder::updateAllPlayers)
        ServerTickEvents.END_WORLD_TICK.register(OpFlight::tickAllPlayers)
        ServerTickEvents.END_WORLD_TICK.register(OpAltiora::checkAllPlayers)

        CommandRegistrationCallback.EVENT.register { dp, _, _ -> HexCommands.register(dp) }

        LootTableEvents.MODIFY.register { key, builder, _, _ ->
            FabricHexLootModJankery.lootLoad(key, builder::withPool)
        }

        FabricBrewingRecipeRegistryBuilder.BUILD.register { builder -> HexPotions.addRecipes(builder) }

        EntityElytraEvents.CUSTOM.register { target, _ ->
            if (target is Player) {
                val altiora = IXplatAbstractions.INSTANCE.getAltiora(target)
                altiora != null
            } else {
                false
            }
        }

        ItemGroupEvents.modifyEntriesEvent(HexCreativeTabs.SCROLLS_KEY).register { r ->
            val keyList = ArrayList<ResourceKey<ActionRegistryEntry>>()
            val regi = FabricXplatImpl.INSTANCE.getActionRegistry()
            for (key in regi.registryKeySet()) if (isOfTag<ActionRegistryEntry>(
                    regi,
                    key,
                    HexTags.Actions.PER_WORLD_PATTERN
                )
            ) keyList.add(key)
            keyList.sortWith(Comparator.comparing<ResourceKey<ActionRegistryEntry>, ResourceLocation>(Function { obj: ResourceKey<ActionRegistryEntry> -> obj.location() }))
            for (key in keyList) {
                r.accept(
                    ItemScroll.withPerWorldPattern(
                        ItemStack(HexItems.SCROLL_LARGE.get()),
                        key
                    )
                )
            }
        }
        ItemGroupEvents.modifyEntriesEvent(HexCreativeTabs.HEX_KEY).register { r ->
            HexItems.registerItemsForCreativeTab(HexCreativeTabs.HEX_KEY, r)
            HexBlocks.registerBlocksForCreativeTab(HexCreativeTabs.HEX_KEY, r)
        }
    }

    private fun initRegistries() {
        HexBlockSetTypes.registerBlocks(BlockSetType::register)

        HexCreativeTabs.register()

        HexSounds.register()
        HexBlocks.register()
        HexBlockEntities.register()
        HexItems.register()
        // Registry.register(IngredientDeserializer.REGISTRY, FabricModConditionalIngredient.ID, FabricModConditionalIngredient.Deserializer.INSTANCE)
        CustomIngredientSerializer.register(FabricUnsealedIngredient.Serializer.INSTANCE);
        CustomIngredientSerializer.register(FabricModConditionalIngredient.Serializer.INSTANCE);

        HexEntities.register()
        HexAttributes.register()
        FabricDefaultAttributeRegistry.register(EntityType.PLAYER,
            Player.createAttributes()
                .add(HexAttributes.GRID_ZOOM)
                .add(HexAttributes.SCRY_SIGHT)
                .add(HexAttributes.FEEBLE_MIND)
                .add(HexAttributes.AMBIT_RADIUS)
                .add(HexAttributes.MEDIA_CONSUMPTION_MODIFIER)
                .add(HexAttributes.SENTINEL_RADIUS))
        HexMobEffects.register()
        HexPotions.register()
        HexDataComponents.register()

        HexRecipeStuffRegistry.register()

        HexParticles.register()

        HexLootFunctions.register()

        HexIotaTypes.register()
        HexActions.register()
        HexSpecialHandlers.register()
        HexArithmetics.register()
        HexContinuationTypes.register()
        HexEvalSounds.register()
        HexStateIngredients.register()
        HexBrainsweepeeIngredients.register()


        // Because of Java's lazy-loading of classes, can't use Kotlin static initialization for
        // any calls that will eventually touch FeatureUtils.register(), as the growers here do,
        // unless the class is called in this initialization step.
        AkashicTreeGrower.init()

        // Done with soft implements in forge
        butYouCouldBeFire()

        HexStatistics.register()

        fabricOnlyRegistration()
    }

    // sorry lex (not sorry)
    private fun fabricOnlyRegistration() {
        for (item in BuiltInRegistries.ITEM) {
            if (item is PigmentItem) {
                HexCardinalComponents.PIGMENT_ITEM_LOOKUP.registerForItems({
                    item, _ -> CCPigment.ItemBased(item);
                }, item)
            }
            if (item is MediaHolderItem) {
                HexCardinalComponents.MEDIA_HOLDER_LOOKUP.registerForItems({
                        item, _ -> CCMediaHolder.ItemBased(item);
                }, item)
            }
            if (item is IotaHolderItem) {
                HexCardinalComponents.IOTA_HOLDER_LOOKUP.registerForItems({
                    item, _ -> CCItemIotaHolder.ItemBased(item);
                }, item)
            }
            if (item is HexHolderItem) {
                HexCardinalComponents.HEX_HOLDER_LOOKUP.registerForItems({
                    item, _ -> CCHexHolder.ItemBased(item);
                }, item)
            }
            if (item is VariantItem) {
                HexCardinalComponents.VARIANT_ITEM_LOOKUP.registerForItems({
                    item, _ -> CCVariantItem.ItemBased(item);
                }, item)
            }
        }

        HexCardinalComponents.MEDIA_HOLDER_LOOKUP.registerForItems({
         stack, _ -> CCMediaHolder.Static({ HexConfig.common().dustMediaAmount() }, ADMediaHolder.AMETHYST_DUST_PRIORITY, stack)
        }, HexItems.AMETHYST_DUST.get())

        HexCardinalComponents.MEDIA_HOLDER_LOOKUP.registerForItems({
            stack, _ -> CCMediaHolder.Static({ HexConfig.common().shardMediaAmount() }, ADMediaHolder.AMETHYST_SHARD_PRIORITY, stack)
        }, Items.AMETHYST_SHARD)

        HexCardinalComponents.MEDIA_HOLDER_LOOKUP.registerForItems({
                stack, _ -> CCMediaHolder.Static({ HexConfig.common().chargedCrystalMediaAmount() }, ADMediaHolder.CHARGED_AMETHYST_PRIORITY, stack)
        }, HexItems.CHARGED_AMETHYST.get())

        HexCardinalComponents.MEDIA_HOLDER_LOOKUP.registerForItems({
                stack, _ -> CCMediaHolder.Static({ MediaConstants.QUENCHED_SHARD_UNIT }, ADMediaHolder.QUENCHED_SHARD_PRIORITY, stack)
        }, HexItems.QUENCHED_SHARD.get())

        HexCardinalComponents.MEDIA_HOLDER_LOOKUP.registerForItems({
                stack, _ -> CCMediaHolder.Static({ MediaConstants.QUENCHED_BLOCK_UNIT }, ADMediaHolder.QUENCHED_ALLAY_PRIORITY, stack)
        }, HexBlocks.QUENCHED_ALLAY.get().asItem())

        HexCardinalComponents.IOTA_HOLDER_LOOKUP.registerForItems({
            stack, _ -> CCItemIotaHolder.Static(stack) {
            return@Static DoubleIota(Math.PI)
        }
        }, Items.PUMPKIN_PIE)
    }

    private val itemsToAddToCreativeTab : MutableSet<Item> = mutableSetOf()

	private val boundForItem : BiConsumer<Item, ResourceLocation> = BiConsumer {
        t, id -> this.itemsToAddToCreativeTab.add(t)
        Registry.register(BuiltInRegistries.ITEM, id, t)
    }


    private fun butYouCouldBeFire() {
        val flameOn = FlammableBlockRegistry.getDefaultInstance()
        for (log in listOf(
            HexBlocks.EDIFIED_LOG.get(),
            HexBlocks.EDIFIED_LOG_AMETHYST.get(),
            HexBlocks.EDIFIED_LOG_AVENTURINE.get(),
            HexBlocks.EDIFIED_LOG_CITRINE.get(),
            HexBlocks.EDIFIED_LOG_PURPLE.get(),
            HexBlocks.STRIPPED_EDIFIED_LOG.get(),
            HexBlocks.EDIFIED_WOOD.get(),
            HexBlocks.STRIPPED_EDIFIED_LOG.get(),
        )) {
            flameOn.add(log, 5, 5)
        }
        for (wood in listOf(
            HexBlocks.EDIFIED_PLANKS.get(),
            HexBlocks.EDIFIED_PANEL.get(),
            HexBlocks.EDIFIED_TILE.get(),
            HexBlocks.EDIFIED_DOOR.get(),
            HexBlocks.EDIFIED_TRAPDOOR.get(),
            HexBlocks.EDIFIED_STAIRS.get(),
            HexBlocks.EDIFIED_SLAB.get(),
            HexBlocks.EDIFIED_FENCE.get(),
            HexBlocks.EDIFIED_FENCE_GATE.get(),
            HexBlocks.EDIFIED_SLAB.get(),
            HexBlocks.EDIFIED_BUTTON.get(),
            HexBlocks.EDIFIED_PRESSURE_PLATE.get(),
        )) {
            flameOn.add(wood, 20, 5)
        }
        for (papery in listOf(
            HexBlocks.SCROLL_PAPER.get(),
            HexBlocks.SCROLL_PAPER_LANTERN.get(),
            HexBlocks.ANCIENT_SCROLL_PAPER.get(),
            HexBlocks.ANCIENT_SCROLL_PAPER_LANTERN.get(),

            )) {
            flameOn.add(papery, 100, 60)
        }
        for (leaves in listOf(
            HexBlocks.AMETHYST_EDIFIED_LEAVES.get(),
            HexBlocks.AVENTURINE_EDIFIED_LEAVES.get(),
            HexBlocks.CITRINE_EDIFIED_LEAVES.get(),
        )) {
            flameOn.add(leaves, 60, 30)
        }
    }

    private fun <T> bind(registry: Registry<in T>): BiConsumer<T, ResourceLocation> =
        BiConsumer<T, ResourceLocation> { t, id -> Registry.register(registry, id, t) }
}
