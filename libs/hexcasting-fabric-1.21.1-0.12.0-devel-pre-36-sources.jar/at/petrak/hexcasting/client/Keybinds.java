package at.petrak.hexcasting.client;

import java.util.List;
import net.minecraft.class_304;
import net.minecraft.class_3675;

public class Keybinds {
    public static final String CATEGORY = "category.hexcasting.binds";

    public static class_304 spellbookPrev = new class_304(
            "key.hexcasting.spellbook_prev",
            class_3675.field_16237.method_1444(),
            CATEGORY
    );

    public static class_304 spellbookNext = new class_304(
            "key.hexcasting.spellbook_next",
            class_3675.field_16237.method_1444(),
            CATEGORY
    );

    public static List<class_304> ALL_BINDS = List.of(spellbookPrev, spellbookNext);

    public static void clientTickEnd() {
        // because of how mouse scrolling works (scrolling upward moves the page down), a positive
        // delta value makes the book flip backward while a negative one makes it flip forward

        while (spellbookPrev.method_1436()) {
            ShiftScrollListener.onScroll(1, false, false);
        }

        while (spellbookNext.method_1436()) {
            ShiftScrollListener.onScroll(-1, false, false);
        }
    }
}
