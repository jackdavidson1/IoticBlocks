package at.petrak.hexcasting.client;

import at.petrak.hexcasting.api.item.IotaHolderItem;
import at.petrak.hexcasting.api.item.MediaHolderItem;
import at.petrak.hexcasting.api.item.VariantItem;
import at.petrak.hexcasting.api.misc.MediaConstants;
import at.petrak.hexcasting.client.entity.WallScrollRenderer;
import at.petrak.hexcasting.client.render.GaslightingTracker;
import at.petrak.hexcasting.client.render.ScryingLensOverlays;
import at.petrak.hexcasting.client.render.be.BlockEntityAkashicBookshelfRenderer;
import at.petrak.hexcasting.client.render.be.BlockEntityQuenchedAllayRenderer;
import at.petrak.hexcasting.client.render.be.BlockEntitySlateRenderer;
import at.petrak.hexcasting.common.blocks.BlockQuenchedAllay;
import at.petrak.hexcasting.common.blocks.akashic.BlockAkashicBookshelf;
import at.petrak.hexcasting.common.blocks.akashic.BlockEntityAkashicBookshelf;
import at.petrak.hexcasting.common.entities.HexEntities;
import at.petrak.hexcasting.common.items.ItemStaff;
import at.petrak.hexcasting.common.items.magic.ItemMediaBattery;
import at.petrak.hexcasting.common.items.magic.ItemPackagedHex;
import at.petrak.hexcasting.common.items.storage.*;
import at.petrak.hexcasting.common.lib.HexBlockEntities;
import at.petrak.hexcasting.common.lib.HexBlocks;
import at.petrak.hexcasting.common.lib.HexDataComponents;
import at.petrak.hexcasting.common.lib.HexItems;
import at.petrak.hexcasting.xplat.IClientXplatAbstractions;
import org.jetbrains.annotations.NotNull;

import java.util.*;
import java.util.function.*;
import net.minecraft.class_1087;
import net.minecraft.class_1088;
import net.minecraft.class_1091;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1921;
import net.minecraft.class_2248;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2960;
import net.minecraft.class_322;
import net.minecraft.class_326;
import net.minecraft.class_3300;
import net.minecraft.class_5614;
import net.minecraft.class_7923;
import net.minecraft.class_9334;

import static at.petrak.hexcasting.api.HexAPI.modLoc;

public class RegisterClientStuff {
    public static Map<class_2960, List<class_1087>> QUENCHED_ALLAY_VARIANTS = new HashMap<>();
    private static final Map<BlockQuenchedAllay, Boolean> QUENCHED_ALLAY_TYPES = Map.of(
            HexBlocks.QUENCHED_ALLAY.get(), false,
            HexBlocks.QUENCHED_ALLAY_TILES.get(), true,
            HexBlocks.QUENCHED_ALLAY_BRICKS.get(), true,
            HexBlocks.QUENCHED_ALLAY_BRICKS_SMALL.get(), true);

    public static void init() {
        registerSealableDataHolderOverrides(HexItems.FOCUS.get(),
            stack -> stack.method_57826(HexDataComponents.IOTA_HOLDER_IOTA.get()),
            ItemFocus::isSealed);
        registerSealableDataHolderOverrides(HexItems.SPELLBOOK.get(),
            stack -> HexItems.SPELLBOOK.get().readIota(stack) != null,
            ItemSpellbook::isSealed);
        registerVariantOverrides(HexItems.FOCUS.get(), HexItems.FOCUS.get()::getVariant);
        registerVariantOverrides(HexItems.SPELLBOOK.get(), HexItems.SPELLBOOK.get()::getVariant);
        registerVariantOverrides(HexItems.ANCIENT_CYPHER.get(), HexItems.ANCIENT_CYPHER.get()::getVariant);
        registerVariantOverrides(HexItems.CYPHER.get(), HexItems.CYPHER.get()::getVariant);
        registerVariantOverrides(HexItems.TRINKET.get(), HexItems.TRINKET.get()::getVariant);
        registerVariantOverrides(HexItems.ARTIFACT.get(), HexItems.ARTIFACT.get()::getVariant);
        IClientXplatAbstractions.INSTANCE.registerItemProperty(HexItems.THOUGHT_KNOT.get(), ItemThoughtKnot.WRITTEN_PRED,
            (stack, level, holder, holderID) -> {
                if (stack.method_57826(HexDataComponents.IOTA_HOLDER_IOTA.get())) {
                    return 1;
                } else {
                    return 0;
                }
            });

        registerPackagedSpellOverrides(HexItems.ANCIENT_CYPHER.get());
        registerPackagedSpellOverrides(HexItems.CYPHER.get());
        registerPackagedSpellOverrides(HexItems.TRINKET.get());
        registerPackagedSpellOverrides(HexItems.ARTIFACT.get());

        var x = IClientXplatAbstractions.INSTANCE;
        x.registerItemProperty(HexItems.BATTERY.get(), ItemMediaBattery.MEDIA_PREDICATE,
            (stack, level, holder, holderID) -> {
                var item = (MediaHolderItem) stack.method_7909();
                return item.getMediaFullness(stack);
            });
        x.registerItemProperty(HexItems.BATTERY.get(), ItemMediaBattery.MAX_MEDIA_PREDICATE,
            (stack, level, holder, holderID) -> {
                var item = (ItemMediaBattery) stack.method_7909();
                var max = item.getMaxMedia(stack);
                return 1.049658f * (float) Math.log((float) max / MediaConstants.CRYSTAL_UNIT + 9.06152f) - 2.1436f;
            });

        registerScrollOverrides(HexItems.SCROLL_SMOL.get());
        registerScrollOverrides(HexItems.SCROLL_MEDIUM.get());
        registerScrollOverrides(HexItems.SCROLL_LARGE.get());

        x.registerItemProperty(HexItems.SLATE.get(), ItemSlate.WRITTEN_PRED,
            (stack, level, holder, holderID) -> ItemSlate.hasPattern(stack) ? 1f : 0f);

        registerWandOverrides(HexItems.STAFF_OAK.get());
        registerWandOverrides(HexItems.STAFF_BIRCH.get());
        registerWandOverrides(HexItems.STAFF_SPRUCE.get());
        registerWandOverrides(HexItems.STAFF_JUNGLE.get());
        registerWandOverrides(HexItems.STAFF_DARK_OAK.get());
        registerWandOverrides(HexItems.STAFF_ACACIA.get());
        registerWandOverrides(HexItems.STAFF_EDIFIED.get());
        // purposely skip quenched
        registerWandOverrides(HexItems.STAFF_MINDSPLICE.get());

        registerGaslight4(HexItems.STAFF_QUENCHED.get());
        registerGaslight4(HexBlocks.QUENCHED_ALLAY.get().method_8389());
        registerGaslight4(HexBlocks.QUENCHED_ALLAY_TILES.get().method_8389());
        registerGaslight4(HexBlocks.QUENCHED_ALLAY_BRICKS.get().method_8389());
        registerGaslight4(HexBlocks.QUENCHED_ALLAY_BRICKS_SMALL.get().method_8389());
        registerGaslight4(HexItems.QUENCHED_SHARD.get());

        x.setRenderLayer(HexBlocks.CONJURED_LIGHT.get(), class_1921.method_23581());
        x.setRenderLayer(HexBlocks.CONJURED_BLOCK.get(), class_1921.method_23581());
        x.setRenderLayer(HexBlocks.EDIFIED_DOOR.get(), class_1921.method_23581());
        x.setRenderLayer(HexBlocks.EDIFIED_TRAPDOOR.get(), class_1921.method_23581());
        x.setRenderLayer(HexBlocks.AKASHIC_BOOKSHELF.get(), class_1921.method_23581());
        x.setRenderLayer(HexBlocks.SCONCE.get(), class_1921.method_23581());

        x.setRenderLayer(HexBlocks.AMETHYST_EDIFIED_LEAVES.get(), class_1921.method_23579());
        x.setRenderLayer(HexBlocks.AVENTURINE_EDIFIED_LEAVES.get(), class_1921.method_23579());
        x.setRenderLayer(HexBlocks.CITRINE_EDIFIED_LEAVES.get(), class_1921.method_23579());

        x.setRenderLayer(HexBlocks.AKASHIC_RECORD.get(), class_1921.method_23583());
        x.setRenderLayer(HexBlocks.QUENCHED_ALLAY.get(), class_1921.method_23583());

        x.registerEntityRenderer(HexEntities.WALL_SCROLL.get(), WallScrollRenderer::new);

//        for (var tex : ResourceLocation.fromNamespaceAndPath[]{
//                PatternTooltipComponent.PRISTINE_BG,
//                PatternTooltipComponent.ANCIENT_BG,
//                PatternTooltipComponent.SLATE_BG
//        }) {
//            Minecraft.getInstance().getTextureManager().bindForSetup(tex);
//        }

        ScryingLensOverlays.addScryingLensStuff();
    }

    private static void registerGaslight4(class_1792 item) {
        IClientXplatAbstractions.INSTANCE.registerItemProperty(item,
            GaslightingTracker.GASLIGHTING_PRED, (stack, level, holder, holderID) ->
                Math.abs(GaslightingTracker.getGaslightingAmount() % 4));
    }

    public static void registerColorProviders(BiConsumer<class_326, class_1792> itemColorRegistry,
        BiConsumer<class_322, class_2248> blockColorRegistry) {
        itemColorRegistry.accept(makeIotaStorageColorizer(HexItems.FOCUS.get()::getColor), HexItems.FOCUS.get());
        itemColorRegistry.accept(makeIotaStorageColorizer(HexItems.SPELLBOOK.get()::getColor), HexItems.SPELLBOOK.get());
        itemColorRegistry.accept(makeIotaStorageColorizer(HexItems.THOUGHT_KNOT.get()::getColor), HexItems.THOUGHT_KNOT.get());

        blockColorRegistry.accept((bs, level, pos, idx) -> {
            if (!bs.method_11654(BlockAkashicBookshelf.HAS_BOOKS) || level == null || pos == null) {
                return 0xff_ffffff;
            }
            var tile = level.method_8321(pos);
            if (!(tile instanceof BlockEntityAkashicBookshelf beas)) {
                // this gets called for particles for some irritating reason
                return 0xff_ffffff;
            }
            var iota = beas.getIota();
            if (iota == null) {
                return 0xff_ffffff;
            }
            return iota.getType().color();
        }, HexBlocks.AKASHIC_BOOKSHELF.get());
    }

    /**
     * Helper function to colorize the layers of an item that stores an iota, in the manner of foci and spellbooks.
     * <br>
     * 0 = base; 1 = overlay
     */
    public static class_326 makeIotaStorageColorizer(ToIntFunction<class_1799> getColor) {
        return (stack, idx) -> {
            if (idx == 1) {
                return getColor.applyAsInt(stack);
            }
            return 0xff_ffffff;
        };
    }

    private static void registerSealableDataHolderOverrides(IotaHolderItem item, Predicate<class_1799> hasIota,
        Predicate<class_1799> isSealed) {
        IClientXplatAbstractions.INSTANCE.registerItemProperty((class_1792) item, ItemFocus.OVERLAY_PRED,
            (stack, level, holder, holderID) -> {
                if (!hasIota.test(stack) && !stack.method_57826(HexDataComponents.VISUAL_OVERRIDE.get())) {
                    return 0;
                }
                if (!isSealed.test(stack)) {
                    return 1;
                }
                return 2;
            });
    }

    private static void registerVariantOverrides(VariantItem item, Function<class_1799, Integer> variant) {
        IClientXplatAbstractions.INSTANCE.registerItemProperty((class_1792) item, ItemFocus.VARIANT_PRED,
                (stack, level, holder, holderID) -> variant.apply(stack));
    }

    private static void registerScrollOverrides(ItemScroll scroll) {
        IClientXplatAbstractions.INSTANCE.registerItemProperty(scroll, ItemScroll.ANCIENT_PREDICATE,
            (stack, level, holder, holderID) -> stack.method_57826(HexDataComponents.ACTION.get()) ? 1f : 0f);
    }

    private static void registerPackagedSpellOverrides(ItemPackagedHex item) {
        IClientXplatAbstractions.INSTANCE.registerItemProperty(item, ItemPackagedHex.HAS_PATTERNS_PRED,
            (stack, level, holder, holderID) ->
                item.hasHex(stack) ? 1f : 0f
        );
    }

    private static void registerWandOverrides(ItemStaff item) {
        IClientXplatAbstractions.INSTANCE.registerItemProperty(item, ItemStaff.FUNNY_LEVEL_PREDICATE,
            (stack, level, holder, holderID) -> {
                if (!stack.method_57826(class_9334.field_49631)) {
                    return 0;
                }
                var name = stack.method_7964().getString().toLowerCase(Locale.ROOT);
                if (name.contains("old")) {
                    return 1f;
                } else if (name.contains("cherry")) {
                    return 2f;
                } else {
                    return 0f;
                }
            });
    }

    public static void registerBlockEntityRenderers(@NotNull BlockEntityRendererRegisterererer registerer) {
        registerer.registerBlockEntityRenderer(HexBlockEntities.SLATE_TILE.get(), BlockEntitySlateRenderer::new);
        registerer.registerBlockEntityRenderer(HexBlockEntities.AKASHIC_BOOKSHELF_TILE.get(),
            BlockEntityAkashicBookshelfRenderer::new);
        registerer.registerBlockEntityRenderer(HexBlockEntities.QUENCHED_ALLAY_TILE.get(),
            BlockEntityQuenchedAllayRenderer::new);
        registerer.registerBlockEntityRenderer(HexBlockEntities.QUENCHED_ALLAY_TILES_TILE.get(),
                BlockEntityQuenchedAllayRenderer::new);
        registerer.registerBlockEntityRenderer(HexBlockEntities.QUENCHED_ALLAY_BRICKS_TILE.get(),
                BlockEntityQuenchedAllayRenderer::new);
        registerer.registerBlockEntityRenderer(HexBlockEntities.QUENCHED_ALLAY_BRICKS_SMALL_TILE.get(),
                BlockEntityQuenchedAllayRenderer::new);
    }

    @FunctionalInterface
    public interface BlockEntityRendererRegisterererer {
        <T extends class_2586> void registerBlockEntityRenderer(class_2591<T> type,
            class_5614<? super T> berp);
    }

    public static void onModelRegister(class_3300 recMan, Consumer<class_1091> extraModels) {
        for (var type : QUENCHED_ALLAY_TYPES.entrySet()) {
            var blockLoc = class_7923.field_41175.method_10221(type.getKey());
            var locStart = "block/";
            if (type.getValue())
                locStart += "deco/";

            for (int i = 0; i < BlockQuenchedAllay.VARIANTS; i++) {
                extraModels.accept(new class_1091(modLoc( locStart + blockLoc.method_12832() + "_" + i), IClientXplatAbstractions.INSTANCE.getModelLocVariant()));
            }
        }
    }

    @FunctionalInterface
    public interface FabricModelContext {
        void add(class_2960 id);
    }

    public static void onModelRegister(FabricModelContext context) {
        for (var type : QUENCHED_ALLAY_TYPES.entrySet()) {
            var blockLoc = class_7923.field_41175.method_10221(type.getKey());
            var locStart = "block/";
            if (type.getValue())
                locStart += "deco/";

            for (int i = 0; i < BlockQuenchedAllay.VARIANTS; i++) {
                context.add(modLoc( locStart + blockLoc.method_12832() + "_" + i));
            }
        }
    }

    public static void onModelBake(class_1088 loader, Map<class_1091, class_1087> map) {
        for (var type : QUENCHED_ALLAY_TYPES.entrySet()) {
            var blockLoc = class_7923.field_41175.method_10221(type.getKey());
            var locStart = "block/";
            if (type.getValue())
                locStart += "deco/";

            var list = new ArrayList<class_1087>();
            for (int i = 0; i < BlockQuenchedAllay.VARIANTS; i++) {
                var variantLoc = new class_1091(modLoc(locStart + blockLoc.method_12832() + "_" + i), IClientXplatAbstractions.INSTANCE.getModelLocVariant());
                var model = map.get(variantLoc);
                list.add(model);
            }
            QUENCHED_ALLAY_VARIANTS.put(blockLoc, list);
        }
    }
}
