package at.petrak.hexcasting.common.command;

import at.petrak.hexcasting.api.casting.ActionRegistryEntry;
import at.petrak.hexcasting.api.casting.iota.PatternIota;
import at.petrak.hexcasting.api.casting.math.HexPattern;
import at.petrak.hexcasting.api.mod.HexTags;
import at.petrak.hexcasting.api.utils.HexUtils;
import at.petrak.hexcasting.common.casting.PatternRegistryManifest;
import at.petrak.hexcasting.common.lib.HexDataComponents;
import at.petrak.hexcasting.common.lib.HexItems;
import at.petrak.hexcasting.server.ScrungledPatternsSave;
import at.petrak.hexcasting.xplat.IXplatAbstractions;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import java.util.Collection;
import java.util.List;
import net.minecraft.class_1799;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2186;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_5321;

public class ListPerWorldPatternsCommand {
    public static void add(LiteralArgumentBuilder<class_2168> cmd) {
        cmd.then(class_2170.method_9247("perWorldPatterns")
            .requires(dp -> dp.method_9259(class_2170.field_31839))
            .then(class_2170.method_9247("list")
                .executes(ctx -> list(ctx.getSource())))
            .then(class_2170.method_9247("give")
                .then(class_2170.method_9244("patternName", PatternResKeyArgument.id())
                    .executes(ctx ->
                        giveOne(ctx.getSource(),
                            getDefaultTarget(ctx.getSource()),
                                PatternResKeyArgument.getPatternKey(ctx, "patternName"),
                                PatternResKeyArgument.getPattern(ctx, "patternName")))
                    .then(class_2170.method_9244("targets", class_2186.method_9308())
                        .executes(ctx ->
                            giveOne(ctx.getSource(),
                                class_2186.method_9312(ctx, "targets"),
                                    PatternResKeyArgument.getPatternKey(ctx, "patternName"),
                                    PatternResKeyArgument.getPattern(ctx, "patternName"))))))
            .then(class_2170.method_9247("giveAll")
                .executes(ctx ->
                    giveAll(ctx.getSource(),
                        getDefaultTarget(ctx.getSource())))
                .then(class_2170.method_9244("targets", class_2186.method_9308())
                    .executes(ctx ->
                        giveAll(ctx.getSource(),
                            class_2186.method_9312(ctx, "targets")))))
        );
    }

    private static Collection<class_3222> getDefaultTarget(class_2168 source) {
        if (source.method_9228() instanceof class_3222 player) {
            return List.of(player);
        }
        return List.of();
    }

    private static int list(class_2168 source) {

        var keys = IXplatAbstractions.INSTANCE.getActionRegistry().method_42021();
        var listing = keys
            .stream()
            .sorted((a, b) -> compareResLoc(a.method_29177(), b.method_29177()))
            .toList();

        var ow = source.method_9225().method_8503().method_30002();
        source.method_9226(() -> class_2561.method_43471("command.hexcasting.pats.listing"), false);
        for (var key : listing) {
            var pat = PatternRegistryManifest.getCanonicalStrokesPerWorld(key, ow);

            source.method_9226(() -> class_2561.method_43470(key.method_29177().toString())
                .method_27693(": ")
                .method_10852(new PatternIota(pat).display()), false);
        }

        return keys.size();
    }

    private static int giveAll(class_2168 source, Collection<class_3222> targets) {
        if (!targets.isEmpty()) {
            var ow = source.method_9225().method_8503().method_30002();
            var save = ScrungledPatternsSave.open(ow);
            class_2378<ActionRegistryEntry> regi = IXplatAbstractions.INSTANCE.getActionRegistry();

            int count = 0;
            for (var entry : regi.method_29722()) {
                var key = entry.getKey();
                if (HexUtils.isOfTag(regi, key, HexTags.Actions.PER_WORLD_PATTERN)) {
                    var found = save.lookupReverse(key);
                    var signature = found.getFirst();
                    var startDir = found.getSecond().canonicalStartDir();
                    var pat = HexPattern.fromAnglesUnchecked(signature, startDir);

                    var stack = new class_1799(HexItems.SCROLL_LARGE.get());
                    stack.method_57379(HexDataComponents.ACTION.get(), key);
                    stack.method_57379(HexDataComponents.PATTERN.get(), pat);

                    for (var player : targets) {
                        var stackEntity = player.method_7328(stack, false);
                        if (stackEntity != null) {
                            stackEntity.method_6975();
                            stackEntity.method_6981(player);
                        }

                        count++;
                    }
                }
            }

            int finalCount = count;
            source.method_9226(() ->
                class_2561.method_43469("command.hexcasting.pats.all",
                    finalCount,
                    targets.size() == 1 ? targets.iterator().next().method_5476() : targets.size()),
                true);
            return count;
        } else {
            return 0;
        }
    }

    private static int giveOne(class_2168 source, Collection<class_3222> targets,
                               class_5321<ActionRegistryEntry> actionKey, HexPattern pat) {
        if (!targets.isEmpty()) {
            var stack = new class_1799(HexItems.SCROLL_LARGE.get());
            stack.method_57379(HexDataComponents.ACTION.get(), actionKey);
            stack.method_57379(HexDataComponents.PATTERN.get(), pat);

            source.method_9226(() ->
                class_2561.method_43469(
                    "command.hexcasting.pats.specific.success",
                    stack.method_7954(),
                        actionKey.method_29177().toString(),
                    targets.size() == 1 ? targets.iterator().next().method_5476() : targets.size()),
                true);

            for (var player : targets) {
                var stackEntity = player.method_7328(stack, false);
                if (stackEntity != null) {
                    stackEntity.method_6975();
                    stackEntity.method_6981(player);
                }
            }

            return targets.size();
        } else {
            return 0;
        }
    }

    private static int compareResLoc(class_2960 a, class_2960 b) {
        var ns = a.method_12836().compareTo(b.method_12836());
        if (ns != 0) {
            return ns;
        }
        return a.method_12832().compareTo(b.method_12832());
    }
}
