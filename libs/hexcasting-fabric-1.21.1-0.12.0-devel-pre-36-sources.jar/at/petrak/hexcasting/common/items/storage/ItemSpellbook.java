package at.petrak.hexcasting.common.items.storage;

import at.petrak.hexcasting.api.casting.iota.Iota;
import at.petrak.hexcasting.api.item.IotaHolderItem;
import at.petrak.hexcasting.api.item.VariantItem;
import at.petrak.hexcasting.common.lib.HexDataComponents;
import org.jetbrains.annotations.Nullable;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.stream.Stream;
import net.minecraft.class_124;
import net.minecraft.class_1297;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1937;
import net.minecraft.class_2561;
import net.minecraft.class_3532;
import net.minecraft.class_9334;

import static at.petrak.hexcasting.common.items.storage.ItemFocus.NUM_VARIANTS;

public class ItemSpellbook extends class_1792 implements IotaHolderItem, VariantItem {
    public static final int MAX_PAGES = 64;

    public ItemSpellbook(class_1793 properties) {
        super(properties);
    }

    @Override
    public void method_7851(class_1799 stack, class_9635 context, List<class_2561> tooltip, class_1836 isAdvanced) {
        boolean sealed = isSealed(stack);
        boolean empty = false;
        if (stack.method_57826(HexDataComponents.SELECTED_SPELLBOOK_PAGE.get())) {
            var pageIdx = stack.method_57824(HexDataComponents.SELECTED_SPELLBOOK_PAGE.get());
            int highest = highestPage(stack);
            if (highest != 0) {
                if (sealed) {
                    tooltip.add(class_2561.method_43469("hexcasting.tooltip.spellbook.page.sealed",
                            class_2561.method_43470(String.valueOf(pageIdx)).method_27692(class_124.field_1068),
                            class_2561.method_43470(String.valueOf(highest)).method_27692(class_124.field_1068),
                            class_2561.method_43471("hexcasting.tooltip.spellbook.sealed").method_27692(class_124.field_1065))
                        .method_27692(class_124.field_1080));
                } else {
                    tooltip.add(class_2561.method_43469("hexcasting.tooltip.spellbook.page",
                            class_2561.method_43470(String.valueOf(pageIdx)).method_27692(class_124.field_1068),
                            class_2561.method_43470(String.valueOf(highest)).method_27692(class_124.field_1068))
                        .method_27692(class_124.field_1080));
                }
            } else {
                empty = true;
            }
        } else {
            empty = true;
        }

        if (empty) {
            boolean overridden = stack.method_57826(HexDataComponents.VISUAL_OVERRIDE.get());
            if (sealed) {
                if (overridden) {
                    tooltip.add(class_2561.method_43471("hexcasting.tooltip.spellbook.sealed").method_27692(
                        class_124.field_1065));
                } else {
                    tooltip.add(class_2561.method_43469("hexcasting.tooltip.spellbook.empty.sealed",
                            class_2561.method_43471("hexcasting.tooltip.spellbook.sealed").method_27692(class_124.field_1065))
                        .method_27692(class_124.field_1080));
                }
            } else if (!overridden) {
                tooltip.add(
                    class_2561.method_43471("hexcasting.tooltip.spellbook.empty").method_27692(class_124.field_1080));
            }
        }

        IotaHolderItem.appendHoverText(this, stack, tooltip, isAdvanced);

        super.method_7851(stack, context, tooltip, isAdvanced);
    }

    @Override
    public void method_7888(class_1799 stack, class_1937 level, class_1297 pEntity, int pSlotId, boolean pIsSelected) {
        int index = getPage(stack, 0);
        stack.method_57379(HexDataComponents.SELECTED_SPELLBOOK_PAGE.get(), index);

        int shiftedIdx = Math.max(1, index);
        String nameKey = String.valueOf(shiftedIdx);

        var customName = stack.method_57824(class_9334.field_49631);
        var savedNames = stack.method_57824(HexDataComponents.SPELLBOOK_PAGE_NAMES.get());

        if(customName != null) {
            if(savedNames != null) {
                if(!savedNames.containsKey(nameKey) || !savedNames.get(nameKey).equals(customName)) {
                    var mutNames = new HashMap<>(savedNames);
                    mutNames.put(nameKey, customName);
                    stack.method_57379(HexDataComponents.SPELLBOOK_PAGE_NAMES.get(), mutNames);
                }
            } else {
                var mutNames = new HashMap<String, class_2561>();
                mutNames.put(nameKey, customName);
                stack.method_57379(HexDataComponents.SPELLBOOK_PAGE_NAMES.get(), mutNames);
            }
        } else if(savedNames != null) {
            var mutNames = new HashMap<>(savedNames);
            mutNames.remove(nameKey);
            if(mutNames.isEmpty()) {
                stack.method_57381(HexDataComponents.SPELLBOOK_PAGE_NAMES.get());
            } else {
                stack.method_57379(HexDataComponents.SPELLBOOK_PAGE_NAMES.get(), mutNames);
            }
        }
    }

    public static boolean arePagesEmpty(class_1799 stack) {
        var pages = stack.method_57824(HexDataComponents.SPELLBOOK_PAGES.get());
        return pages == null || pages.isEmpty();
    }

    @Override
    public @Nullable Iota readIota(class_1799 stack) {
        int idx = getPage(stack, 1);
        var key = String.valueOf(idx);
        var pages = stack.method_57824(HexDataComponents.SPELLBOOK_PAGES.get());
        if (pages != null && pages.containsKey(key)) {
            return pages.get(key);
        } else {
            return null;
        }
    }

    @Override
    public boolean writeable(class_1799 stack) {
        return !isSealed(stack);
    }

    @Override
    public boolean canWrite(class_1799 stack, Iota datum) {
        return datum == null || !isSealed(stack);
    }

    @Override
    public void writeDatum(class_1799 stack, Iota datum) {
        if (datum != null && isSealed(stack)) {
            return;
        }

        int idx = getPage(stack, 1);
        var key = String.valueOf(idx);

        var pages = stack.method_57824(HexDataComponents.SPELLBOOK_PAGES.get());

        if (pages != null) {
            var pagesMut = new HashMap<>(pages);

            if (datum == null) {
                pagesMut.remove(key);
                var seals = stack.method_57824(HexDataComponents.SPELLBOOK_PAGE_SEALS.get());
                if(seals != null) {
                    var sealsMut = new HashMap<>(seals);

                    sealsMut.remove(key);

                    if(sealsMut.isEmpty()) {
                        stack.method_57381(HexDataComponents.SPELLBOOK_PAGE_SEALS.get());
                    } else {
                        stack.method_57379(HexDataComponents.SPELLBOOK_PAGE_SEALS.get(), sealsMut);
                    }
                }
            } else {
                pagesMut.put(key, datum);
            }

            if (pagesMut.isEmpty()) {
                stack.method_57381(HexDataComponents.SPELLBOOK_PAGES.get());
            } else {
                stack.method_57379(HexDataComponents.SPELLBOOK_PAGES.get(), pagesMut);
            }
        } else if (datum != null) {
            var map = new HashMap<String, Iota>();
            map.put(key, datum);
            stack.method_57379(HexDataComponents.SPELLBOOK_PAGES.get(), map);
        } else {
            var seals = stack.method_57824(HexDataComponents.SPELLBOOK_PAGE_SEALS.get());
            if(seals != null) {
                var sealsMut = new HashMap<>(seals);
                sealsMut.remove(key);

                if(sealsMut.isEmpty()) {
                    stack.method_57381(HexDataComponents.SPELLBOOK_PAGE_SEALS.get());
                } else {
                    stack.method_57379(HexDataComponents.SPELLBOOK_PAGE_SEALS.get(), sealsMut);
                }
            }
        }
    }

    public static int getPage(class_1799 stack, int ifEmpty) {
        if (arePagesEmpty(stack)) {
            return ifEmpty;
        } else if (stack.method_57826(HexDataComponents.SELECTED_SPELLBOOK_PAGE.get())) {
            var index = stack.method_57824(HexDataComponents.SELECTED_SPELLBOOK_PAGE.get());
            if(index == null)
                return 1;
            if (index == 0) {
                index = 1;
            }
            return index;
        } else {
            return 1;
        }
    }

    public static void setSealed(class_1799 stack, boolean sealed) {
        int index = getPage(stack, 1);

        String nameKey = String.valueOf(index);

        var seals = stack.method_57824(HexDataComponents.SPELLBOOK_PAGE_SEALS.get());

        var sealsMut = seals != null ? new HashMap<>(seals) : new HashMap<String, Boolean>();

        if (!sealed) {
            sealsMut.remove(nameKey);
        } else {
            sealsMut.put(nameKey, true);
        }

        if (sealsMut.isEmpty()) {
            stack.method_57381(HexDataComponents.SPELLBOOK_PAGE_SEALS.get());
        } else {
            stack.method_57379(HexDataComponents.SPELLBOOK_PAGE_SEALS.get(), sealsMut);
        }
    }

    public static boolean isSealed(class_1799 stack) {
        int index = getPage(stack, 1);

        String nameKey = String.valueOf(index);
        var seals = stack.method_57824(HexDataComponents.SPELLBOOK_PAGE_SEALS.get());
        if(seals == null)
            return false;
        var v = seals.get(nameKey);
        return v != null && v;
    }

    public static int highestPage(class_1799 stack) {
        var pages = stack.method_57824(HexDataComponents.SPELLBOOK_PAGES.get());
        if (pages == null) {
            return 0;
        }
        return pages.keySet().stream().flatMap(s -> {
            try {
                return Stream.of(Integer.parseInt(s));
            } catch (NumberFormatException e) {
                return Stream.empty();
            }
        }).max(Integer::compare).orElse(0);
    }

    public static int rotatePageIdx(class_1799 stack, boolean increase, class_1937 level) {
        int idx = getPage(stack, 0);
        if (idx != 0) {
            idx += increase ? 1 : -1;
            idx = Math.max(1, idx);
        }
        idx = class_3532.method_15340(idx, 0, MAX_PAGES);
        stack.method_57379(HexDataComponents.SELECTED_SPELLBOOK_PAGE.get(), idx);

        var names = stack.method_57825(HexDataComponents.SPELLBOOK_PAGE_NAMES.get(), Collections.<String, class_2561>emptyMap());
        int shiftedIdx = Math.max(1, idx);
        String nameKey = String.valueOf(shiftedIdx);
        class_2561 name = names.get(nameKey);
        if (name != null) {
            stack.method_57379(class_9334.field_49631, name);
        } else {
            stack.method_57381(class_9334.field_49631);
        }

        return idx;
    }

    @Override
    public int numVariants() {
        return NUM_VARIANTS;
    }

    @Override
    public void setVariant(class_1799 stack, int variant) {
        if (!isSealed(stack))
            stack.method_57379(HexDataComponents.ITEM_VARIANT.get(), clampVariant(variant));
    }
}
