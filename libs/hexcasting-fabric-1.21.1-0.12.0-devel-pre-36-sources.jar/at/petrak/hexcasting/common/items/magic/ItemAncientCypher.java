package at.petrak.hexcasting.common.items.magic;

import at.petrak.hexcasting.common.lib.HexDataComponents;
import java.util.List;
import net.minecraft.class_124;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_2561;

public class ItemAncientCypher extends ItemCypher {
    public static final String TAG_HEX_NAME = "hex_name";

    public ItemAncientCypher(class_1793 pProperties) {
        super(pProperties);
    }

    @Override
    public void clearHex(class_1799 stack) {
        super.clearHex(stack);
        stack.method_57381(HexDataComponents.HEX_NAME.get());
    }

    @Override
    public class_2561 method_7864(class_1799 stack) {
        var descID = this.method_7866(stack);
        var hexName = stack.method_57824(HexDataComponents.HEX_NAME.get());
        if (hexName != null) {
            return class_2561.method_43469(descID + ".preset", class_2561.method_43471(hexName));
        } else {
            return class_2561.method_43471(descID);
        }
    }

    @Override
    public void method_7851(class_1799 stack, class_9635 context, List<class_2561> tooltipComponents, class_1836 tooltipFlag) {
        // display media fullness as usual
        super.method_7851(stack, context, tooltipComponents, tooltipFlag);

        var patterns = stack.method_57824(HexDataComponents.HEX_HOLDER_PATTERNS.get());

        // also show contained spell
        if(patterns != null) {
            var storedHex = class_2561.method_43471("hexcasting.tooltip.stored_hex");

            for(var iota : patterns) {
                storedHex.method_10852(iota.display().method_27662().method_27692(class_124.field_1064));
            }

            tooltipComponents.add(storedHex);
        }
    }
}
