package at.petrak.hexcasting.common.items.magic;

import at.petrak.hexcasting.api.casting.circles.BlockEntityAbstractImpetus;
import at.petrak.hexcasting.api.item.MediaHolderItem;
import at.petrak.hexcasting.api.misc.DiscoveryHandlers;
import at.petrak.hexcasting.api.misc.MediaConstants;
import at.petrak.hexcasting.common.items.ItemLoreFragment;
import at.petrak.hexcasting.common.lib.HexDataComponents;
import at.petrak.hexcasting.common.lib.HexItems;
import at.petrak.hexcasting.common.lib.HexSounds;
import javax.annotation.Nullable;
import net.minecraft.class_124;
import net.minecraft.class_1269;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_156;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1838;
import net.minecraft.class_1937;
import net.minecraft.class_2477;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3419;
import net.minecraft.class_3532;
import net.minecraft.class_5250;
import net.minecraft.class_5251;
import net.minecraft.class_8781;
import net.minecraft.class_9331;
import net.minecraft.class_9334;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;

import static at.petrak.hexcasting.api.HexAPI.modLoc;

public class ItemCreativeUnlocker extends class_1792 implements MediaHolderItem {

    public static final String DISPLAY_MEDIA = "media";
    public static final String DISPLAY_PATTERNS = "patterns";

    static {
        DiscoveryHandlers.addDebugItemDiscoverer((player, type) -> {
            for (class_1799 item : player.method_31548().field_7547) {
                if (isDebug(item, type)) {
                    return item;
                }
            }

            // Technically possible with commands!
            for (class_1799 item : player.method_31548().field_7548) {
                if (isDebug(item, type)) {
                    return item;
                }
            }

            for (class_1799 item : player.method_31548().field_7544) {
                if (isDebug(item, type)) {
                    return item;
                }
            }
            return class_1799.field_8037;
        });
    }

    public static boolean isDebug(class_1799 stack) {
        return isDebug(stack, null);
    }

    public static boolean isDebug(class_1799 stack, String flag) {
        if (!stack.method_31574(HexItems.CREATIVE_UNLOCKER.get()) || !stack.method_57826(class_9334.field_49631)) {
            return false;
        }
        var keywords = Arrays.asList(stack.method_7964().getString().toLowerCase(Locale.ROOT).split(" "));
        if (!keywords.contains("debug")) {
            return false;
        }
        return flag == null || keywords.contains(flag);
    }

    public static class_2561 infiniteMedia(class_1937 level) {

        String prefix = "item.hexcasting.creative_unlocker.";

        String emphasis = class_2477.method_10517().method_48307(prefix + "for_emphasis");
        class_5250 emphasized = class_2561.method_43473();
        for (int i = 0; i < emphasis.length(); i++) {
            emphasized.method_10852(rainbow(class_2561.method_43470("" + emphasis.charAt(i)), i, level));
        }

        return emphasized;
    }

    public static final String TAG_EXTRACTIONS = "extractions";
    public static final String TAG_INSERTIONS = "insertions";

    public ItemCreativeUnlocker(class_1793 properties) {
        super(properties);
    }

    @Override
    public long getMedia(class_1799 stack) {
        return Long.MAX_VALUE;
    }

    @Override
    public long getMaxMedia(class_1799 stack) {
        return Long.MAX_VALUE;
    }

    @Override
    public void setMedia(class_1799 stack, long media) {
        // NO-OP
    }

    @Override
    public boolean canProvideMedia(class_1799 stack) {
        return true;
    }

    @Override
    public boolean canRecharge(class_1799 stack) {
        return true;
    }

    public static void addToLongArray(class_1799 stack, class_9331<List<Long>> type, long n) {
        var list = stack.method_57825(type, new ArrayList<Long>());
        list.add(n);
        stack.method_57379(type, list);
    }

    @Override
    public long withdrawMedia(class_1799 stack, long cost, boolean simulate) {
        // In case it's withdrawn through other means
        if (!simulate && isDebug(stack, DISPLAY_MEDIA)) {
            addToLongArray(stack, HexDataComponents.MEDIA_EXTRACTIONS.get(), cost);
        }

        return cost < 0 ? getMedia(stack) : cost;
    }

    @Override
    public long insertMedia(class_1799 stack, long amount, boolean simulate) {
        // In case it's inserted through other means
        if (!simulate && isDebug(stack, DISPLAY_MEDIA)) {
            addToLongArray(stack, HexDataComponents.MEDIA_INSERTIONS.get(), amount);
        }

        return amount < 0 ? getMaxMedia(stack) : amount;
    }

    @Override
    public boolean method_7886(class_1799 stack) {
        return super.method_7886(stack) || isDebug(stack);
    }

    @Override
    public void method_7888(class_1799 stack, class_1937 level, class_1297 entity, int slot, boolean selected) {
        if (isDebug(stack, DISPLAY_MEDIA) && !level.field_9236) {
            debugDisplay(stack, HexDataComponents.MEDIA_EXTRACTIONS.get(), "withdrawn", "all_media", entity);
            debugDisplay(stack, HexDataComponents.MEDIA_INSERTIONS.get(), "inserted", "infinite_media", entity);
        }
    }

    private void debugDisplay(class_1799 stack, class_9331<List<Long>> type, String langKey, String allKey, class_1297 entity) {
        var list = stack.method_57824(type);
        if (list != null) {
            stack.method_57381(type);
            for (long i : list) {
                if (i < 0) {
                    entity.method_43496(class_2561.method_43469("hexcasting.debug.media_" + langKey,
                            stack.method_7954(),
                            class_2561.method_43471("hexcasting.debug." + allKey).method_27692(class_124.field_1080))
                        .method_27692(class_124.field_1076));
                } else {
                    entity.method_43496(class_2561.method_43469("hexcasting.debug.media_" + langKey + ".with_dust",
                            stack.method_7954(),
                            class_2561.method_43470("" + i).method_27692(class_124.field_1068),
                            class_2561.method_43470(String.format("%.2f", i * 1.0 / MediaConstants.DUST_UNIT)).method_27692(
                                class_124.field_1068))
                        .method_27692(class_124.field_1076));
                }
            }
        }
    }

    @Override
    public class_1269 method_7884(class_1838 context) {
        class_2586 be = context.method_8045().method_8321(context.method_8037());
        if (be instanceof BlockEntityAbstractImpetus impetus) {
            impetus.setInfiniteMedia();
            context.method_8045().method_8396(null, context.method_8037(), HexSounds.SPELL_CIRCLE_FIND_BLOCK.comp_349(),
                class_3419.field_15248, 1f, 1f);
            return class_1269.method_29236(context.method_8045().method_8608());
        }
        return class_1269.field_5811;
    }

    @Override
    public class_1799 method_7861(class_1799 stack, class_1937 level, class_1309 consumer) {
        if (level instanceof class_3218 slevel && consumer instanceof class_3222 player) {
            var names = new ArrayList<>(ItemLoreFragment.NAMES);
            names.add(0, modLoc("root"));
            for (var name : names) {
                var rootAdv = slevel.method_8503().method_3851().method_53646().method_716(name);
                if (rootAdv != null) {
                    var children = new ArrayList<class_8781>();
                    children.add(rootAdv);
                    collectChildrenRecursively(rootAdv, children);

                    var adman = player.method_14236();



                    for (var kid : children) {
                        var progress = adman.method_12882(kid.method_53649());
                        if (!progress.method_740()) {
                            for (String crit : progress.method_731()) {
                                adman.method_12878(kid.method_53649(), crit);
                            }
                        }
                    }
                }
            }
        }

        class_1799 copy = stack.method_7972();
        super.method_7861(stack, level, consumer);
        return copy;
    }

    private static class_5250 rainbow(class_5250 component, int shift, @Nullable class_1937 level) {
        return component.method_27694((s) -> s.method_27703(
            class_5251.method_27717(class_3532.method_15369((level != null ? (level.method_8510() + shift) : ((float) class_156.method_658() / 50)) * 2 % 360 / 360F, 1F, 1F))));
    }

    @Override
    public void method_7851(class_1799 stack, class_9635 context, List<class_2561> tooltipComponents,
        class_1836 isAdvanced) {
        class_2561 emphasized = infiniteMedia(null);

        class_5250 modName = class_2561.method_43471("item.hexcasting.creative_unlocker.mod_name").method_27694(
            (s) -> s.method_27703(ItemMediaHolder.HEX_COLOR));

        tooltipComponents.add(
            class_2561.method_43469("hexcasting.spelldata.onitem", emphasized).method_27692(class_124.field_1080));
        tooltipComponents.add(class_2561.method_43469("item.hexcasting.creative_unlocker.tooltip", modName).method_27692(class_124.field_1080));
    }

    private static void collectChildrenRecursively(class_8781 root, List<class_8781> out) {
        for (class_8781 kiddo : root.method_53653()) {
            out.add(kiddo);
            collectChildrenRecursively(kiddo, out);
        }
    }
}
