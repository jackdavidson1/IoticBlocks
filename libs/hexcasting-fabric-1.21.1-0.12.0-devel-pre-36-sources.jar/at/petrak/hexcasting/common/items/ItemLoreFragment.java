package at.petrak.hexcasting.common.items;

import at.petrak.hexcasting.common.lib.HexSounds;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1657;
import net.minecraft.class_174;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_3419;
import net.minecraft.class_3468;
import net.minecraft.class_8779;

import static at.petrak.hexcasting.api.HexAPI.modLoc;

public class ItemLoreFragment extends class_1792 {
    public static final List<class_2960> NAMES = List.of(new class_2960[]{
        modLoc("lore/cardamom1"),
        modLoc("lore/cardamom2"),
        modLoc("lore/cardamom3"),
        modLoc("lore/cardamom4"),
        modLoc("lore/cardamom5"),
        modLoc("lore/experiment1"),
        modLoc("lore/experiment2"),
        modLoc("lore/inventory"),
    });

    public static final String CRITEREON_KEY = "grant";

    public ItemLoreFragment(class_1793 properties) {
        super(properties);
    }

    @Override
    public class_1271<class_1799> method_7836(class_1937 level, class_1657 player, class_1268 usedHand) {
        player.method_5783(HexSounds.READ_LORE_FRAGMENT.comp_349(), 1f, 1f);

        var handStack = player.method_5998(usedHand);
        if (!(player instanceof class_3222 splayer)) {
            handStack.method_7934(1);
            return class_1271.method_22427(handStack);
        }

        class_8779 unfoundLore = null;
        var shuffled = new ArrayList<>(NAMES);
        Collections.shuffle(shuffled);
        for (var advID : shuffled) {
            var adv = splayer.field_13995.method_3851().method_12896(advID);
            if (adv == null) {
                continue; // uh oh
            }

            if (!splayer.method_14236().method_12882(adv).method_740()) {
                unfoundLore = adv;
                break;
            }
        }

        if (unfoundLore == null) {
            splayer.method_7353(class_2561.method_43471("item.hexcasting.lore_fragment.all"), true);
            splayer.method_7255(20);
            level.method_60511(null, player.method_19538().field_1352, player.method_19538().field_1351, player.method_19538().field_1350,
                HexSounds.READ_LORE_FRAGMENT, class_3419.field_15248, 1f, 1f);
        } else {
            // et voila!
            splayer.method_14236().method_12878(unfoundLore, CRITEREON_KEY);
        }

        class_174.field_1198.method_8821(splayer, handStack);
        splayer.method_7259(class_3468.field_15372.method_14956(this));
        handStack.method_7934(1);

        return class_1271.method_22427(handStack);
    }
}
