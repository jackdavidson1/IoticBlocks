package at.petrak.hexcasting.common.blocks.akashic;

import at.petrak.hexcasting.annotations.SoftImplement;
import at.petrak.hexcasting.api.casting.iota.PatternIota;
import at.petrak.hexcasting.common.items.storage.ItemScroll;
import at.petrak.hexcasting.common.lib.HexSounds;
import at.petrak.hexcasting.xplat.IForgeLikeBlock;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2343;
import net.minecraft.class_2350;
import net.minecraft.class_2415;
import net.minecraft.class_2470;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_2746;
import net.minecraft.class_2753;
import net.minecraft.class_3419;
import net.minecraft.class_3965;
import net.minecraft.class_4538;
import net.minecraft.class_9062;
import org.jetbrains.annotations.Nullable;

public class BlockAkashicBookshelf extends class_2248 implements AkashicFloodfiller, class_2343, IForgeLikeBlock {
    public static final class_2753 FACING = class_2741.field_12481;
    public static final class_2746 HAS_BOOKS = class_2746.method_11825("has_books");

    public BlockAkashicBookshelf(class_2251 p_49795_) {
        super(p_49795_);
        this.method_9590(this.method_9595().method_11664()
            .method_11657(FACING, class_2350.field_11043)
            .method_11657(HAS_BOOKS, false));
    }

    @Override
    protected class_9062 method_55765(class_1799 stack, class_2680 state, class_1937 level, class_2338 pos, class_1657 player, class_1268 hand, class_3965 hitResult) {
        if (level.method_8321(pos) instanceof BlockEntityAkashicBookshelf shelf) {
            if (stack.method_7909() instanceof ItemScroll scroll) {
                if (!level.method_8608()) {
                    scroll.writeDatum(stack, new PatternIota(shelf.getPattern()));
                }
                level.method_8396(player, pos, HexSounds.SCROLL_SCRIBBLE.comp_349(), class_3419.field_15245, 1f, 1f);
                return class_9062.method_55644(level.field_9236);
            }
        }

        return stack.method_7960() && hand == class_1268.field_5808
                ? class_9062.field_47732
                : class_9062.field_47731;
    }

    @Override
    protected class_1269 method_55766(class_2680 state, class_1937 level, class_2338 pos, class_1657 player, class_3965 hitResult) {
        if (level.method_8321(pos) instanceof BlockEntityAkashicBookshelf shelf) {
            if (player.method_21751()) {
                if (!level.method_8608()) {
                    shelf.clearIota();
                }

                level.method_8396(player, pos, HexSounds.SCROLL_SCRIBBLE.comp_349(), class_3419.field_15245,
                        1f, 0.8f);
                return class_1269.method_29236(level.field_9236);
            }
        }

        return class_1269.field_5811;
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(FACING, HAS_BOOKS);
    }

    @Override
    public class_2680 method_9605(class_1750 ctx) {
        return this.method_9564().method_11657(FACING, ctx.method_8042().method_10153());
    }

    @SoftImplement("forge")
    public float getEnchantPowerBonus(class_2680 state, class_4538 level, class_2338 pos) {
        return hasEnchantPowerBonus(state, level, pos) ? 1 : 0;
    }

    @Override
    public boolean hasEnchantPowerBonus(class_2680 state, class_4538 level, class_2338 pos) {
        return true;
    }

    @Override
    public boolean method_9498(class_2680 pState) {
        return true;
    }

    @Override
    public int method_9572(class_2680 pState, class_1937 pLevel, class_2338 pPos) {
        return pState.method_11654(HAS_BOOKS) ? 15 : 0; // TODO have an iota -> comparator value mapping?
    }

    @Nullable
    @Override
    public class_2586 method_10123(class_2338 pPos, class_2680 pState) {
        return new BlockEntityAkashicBookshelf(pPos, pState);
    }

    public class_2680 method_9598(class_2680 pState, class_2470 pRot) {
        return pState.method_11657(FACING, pRot.method_10503(pState.method_11654(FACING)));
    }

    public class_2680 method_9569(class_2680 pState, class_2415 pMirror) {
        return pState.method_26186(pMirror.method_10345(pState.method_11654(FACING)));
    }

    @Override
    public class_1269 use(class_2680 pState, class_1937 pLevel, class_2338 pPos, class_1657 pPlayer, class_1268 pHand, class_3965 pHit) {
        return null;
    }
}
