package at.petrak.hexcasting.common.blocks.behavior;

import at.petrak.hexcasting.common.lib.HexBlocks;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_1935;
import net.minecraft.class_3962;

public final class HexComposting {

    public static void setup() {
        compost(HexBlocks.AMETHYST_EDIFIED_LEAVES.get(), 0.3F);
        compost(HexBlocks.AVENTURINE_EDIFIED_LEAVES.get(), 0.3F);
        compost(HexBlocks.CITRINE_EDIFIED_LEAVES.get(), 0.3F);
    }

    private static void compost(class_1935 itemLike, float chance) {
        class_1792 item = itemLike.method_8389();

        if (item != class_1802.field_8162) {
            class_3962.field_17566.put(item, chance);
        }
    }
}
