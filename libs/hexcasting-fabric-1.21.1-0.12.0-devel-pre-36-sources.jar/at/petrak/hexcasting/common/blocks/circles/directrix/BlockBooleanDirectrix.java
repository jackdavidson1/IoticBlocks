package at.petrak.hexcasting.common.blocks.circles.directrix;

import at.petrak.hexcasting.api.block.circle.BlockCircleComponent;
import at.petrak.hexcasting.api.casting.eval.env.CircleCastEnv;
import at.petrak.hexcasting.api.casting.eval.vm.CastingImage;
import at.petrak.hexcasting.api.casting.iota.BooleanIota;
import at.petrak.hexcasting.api.casting.mishaps.circle.MishapBoolDirectrixEmptyStack;
import at.petrak.hexcasting.api.casting.mishaps.circle.MishapBoolDirectrixNotBool;
import at.petrak.hexcasting.api.utils.TreeList;
import java.util.ArrayList;
import java.util.EnumSet;
import java.util.List;
import java.util.Locale;
import net.minecraft.class_1750;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2415;
import net.minecraft.class_2470;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_2753;
import net.minecraft.class_2754;
import net.minecraft.class_3218;
import net.minecraft.class_3542;

// When pops a true, outputs to FACING, when pops a false, outputs to the opposite
public class BlockBooleanDirectrix extends BlockCircleComponent {
    public static final class_2753 FACING = class_2741.field_12525;
    public static final class_2754<State> STATE = class_2754.method_11850("state", State.class);

    public BlockBooleanDirectrix(class_2251 properties) {
        super(properties);
        this.method_9590(this.field_10647.method_11664()
            .method_11657(ENERGIZED, false)
            .method_11657(STATE, State.NEITHER)
            .method_11657(FACING, class_2350.field_11043));
    }

    @Override
    public ControlFlow acceptControlFlow(CastingImage imageIn, CircleCastEnv env, class_2350 enterDir, class_2338 pos,
        class_2680 bs, class_3218 world) {
        var stack = imageIn.getStack();
        if (stack.isEmpty()) {
            this.fakeThrowMishap(pos, bs, imageIn, env,
                new MishapBoolDirectrixEmptyStack(pos));
            return new ControlFlow.Stop();
        }
        var last = stack.last();

        if (!(last instanceof BooleanIota biota)) {
            this.fakeThrowMishap(pos, bs, imageIn, env,
                new MishapBoolDirectrixNotBool(last, pos));
            return new ControlFlow.Stop();
        }

        world.method_8501(pos, bs.method_11657(STATE, biota.getBool() ? State.TRUE : State.FALSE));

        var outputDir = biota.getBool()
            ? bs.method_11654(FACING).method_10153()
            : bs.method_11654(FACING);
        var imageOut = imageIn.copy(stack.init(), imageIn.getParenCount(), imageIn.getParenthesized(),
            imageIn.getEscapeNext(), imageIn.getSimulateNext(), imageIn.getOpsConsumed(), imageIn.getUserData());

        return new ControlFlow.Continue(imageOut, List.of(this.exitPositionFromDirection(pos, outputDir)));
    }

    @Override
    public boolean canEnterFromDirection(class_2350 enterDir, class_2338 pos, class_2680 bs, class_3218 world) {
        // No entering from either of the output faces
        return enterDir != bs.method_11654(FACING).method_10153() && enterDir != bs.method_11654(FACING);
    }

    @Override
    public EnumSet<class_2350> possibleExitDirections(class_2338 pos, class_2680 bs, class_1937 world) {
        return EnumSet.of(bs.method_11654(FACING), bs.method_11654(FACING).method_10153());
    }

    @Override
    public class_2350 normalDir(class_2338 pos, class_2680 bs, class_1937 world, int recursionLeft) {
        return normalDirOfOther(pos.method_10093(bs.method_11654(FACING)), world, recursionLeft);
    }

    @Override
    public float particleHeight(class_2338 pos, class_2680 bs, class_1937 world) {
        return 0.5f;
    }

    @Override
    public class_2680 endEnergized(class_2338 pos, class_2680 bs, class_1937 world) {
        var newState = bs.method_11657(ENERGIZED, false).method_11657(STATE, State.NEITHER);
        world.method_8501(pos, newState);
        return newState;
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        super.method_9515(builder);
        builder.method_11667(STATE, FACING);
    }


    @Override
    public class_2680 method_9605(class_1750 pContext) {
        return BlockCircleComponent.placeStateDirAndSneak(this.method_9564(), pContext);
    }

    @Override
    public class_2680 method_9598(class_2680 pState, class_2470 pRot) {
        return pState.method_11657(FACING, pRot.method_10503(pState.method_11654(FACING)));
    }

    @Override
    public class_2680 method_9569(class_2680 pState, class_2415 pMirror) {
        return pState.method_26186(pMirror.method_10345(pState.method_11654(FACING)));
    }

    public enum State implements class_3542 {
        // Freshly started
        NEITHER,
        // Popped a true
        TRUE,
        // Popped a false
        FALSE,
        ;

        @Override
        public String method_15434() {
            return this.name().toLowerCase(Locale.ROOT);
        }
    }
}
