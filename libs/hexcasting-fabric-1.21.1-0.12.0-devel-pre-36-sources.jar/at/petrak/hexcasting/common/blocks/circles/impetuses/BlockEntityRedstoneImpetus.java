package at.petrak.hexcasting.common.blocks.circles.impetuses;

import at.petrak.hexcasting.api.HexAPI;
import at.petrak.hexcasting.api.casting.circles.BlockEntityAbstractImpetus;
import at.petrak.hexcasting.common.lib.HexBlockEntities;
import com.mojang.authlib.GameProfile;
import com.mojang.datafixers.util.Pair;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.UUID;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2487;
import net.minecraft.class_2509;
import net.minecraft.class_2520;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_5699;
import net.minecraft.class_7225;
import net.minecraft.class_9296;
import net.minecraft.class_9334;

public class BlockEntityRedstoneImpetus extends BlockEntityAbstractImpetus {
    public static final String TAG_STORED_PLAYER = "stored_player";
    public static final String TAG_STORED_PLAYER_PROFILE = "stored_player_profile";

    private GameProfile storedPlayerProfile = null;
    private UUID storedPlayer = null;

    private class_9296 cachedDisplayProfile = null;
    private class_1799 cachedDisplayStack = null;

    public BlockEntityRedstoneImpetus(class_2338 pWorldPosition, class_2680 pBlockState) {
        super(HexBlockEntities.IMPETUS_REDSTONE_TILE.get(), pWorldPosition, pBlockState);
    }

    protected @Nullable GameProfile getPlayerName() {
        if (this.field_11863 instanceof class_3218) {
            class_1657 player = getStoredPlayer();
            if (player != null) {
                return player.method_7334();
            }
        }

        return this.storedPlayerProfile;
    }

    public void setPlayer(GameProfile profile, UUID player) {
        this.storedPlayerProfile = profile;
        this.storedPlayer = player;
        this.method_5431();
    }

    public void clearPlayer() {
        this.storedPlayerProfile = null;
        this.storedPlayer = null;
    }

    //TODO port: test player profiles
    public void updatePlayerProfile() {
        class_3222 player = getStoredPlayer();
        if (player != null) {
            GameProfile newProfile = player.method_7334();
            if (!newProfile.equals(this.storedPlayerProfile)) {
                this.storedPlayerProfile = newProfile;
                this.method_5431();
            }
        }
    }

    // just feels wrong to use the protected method
    @Nullable
    public class_3222 getStoredPlayer() {
        if (this.storedPlayer == null) {
            return null;
        }
        if (!(this.field_11863 instanceof class_3218 slevel)) {
            HexAPI.LOGGER.error("Called getStoredPlayer on the client");
            return null;
        }
        var e = slevel.method_14190(this.storedPlayer);
        if (e instanceof class_3222 player) {
            return player;
        } else {
            // if owner is offline then getEntity will return null
            // if e is somehow neither null nor a player, something is very wrong
            if (e != null) {
                HexAPI.LOGGER.error("Entity {} stored in a cleric impetus wasn't a player somehow", e);
            }
            return null;
        }
    }

    public void applyScryingLensOverlay(List<Pair<class_1799, class_2561>> lines,
        class_2680 state, class_2338 pos, class_1657 observer,
        class_1937 world,
        class_2350 hitFace) {
        super.applyScryingLensOverlay(lines, state, pos, observer, world, hitFace);

        var plProfile = this.getPlayerName();
        if (plProfile != null) {
            var resolvableProfile = new class_9296(plProfile);
            if (!plProfile.equals(resolvableProfile) || cachedDisplayStack == null) {
                cachedDisplayProfile = resolvableProfile;
                var head = new class_1799(class_1802.field_8575);
                head.method_57379(class_9334.field_49617, resolvableProfile);
                head.method_7909().method_7860(head);
                cachedDisplayStack = head;
            }
            lines.add(new Pair<>(cachedDisplayStack,
                class_2561.method_43469("hexcasting.tooltip.lens.impetus.redstone.bound", plProfile.getName())));
        } else {
            lines.add(new Pair<>(new class_1799(class_1802.field_8077),
                class_2561.method_43471("hexcasting.tooltip.lens.impetus.redstone.bound.none")));
        }
    }

    @Override
    protected void saveModData(class_2487 tag, class_7225.class_7874 registries) {
        super.saveModData(tag, registries);
        if (this.storedPlayer != null) {
            tag.method_25927(TAG_STORED_PLAYER, this.storedPlayer);
        }
        if (this.storedPlayerProfile != null) {
            tag.method_10566(TAG_STORED_PLAYER_PROFILE, class_5699.field_40726.encodeStart(class_2509.field_11560, storedPlayerProfile).getOrThrow());
        }
    }

    @Override
    protected void loadModData(class_2487 tag, class_7225.class_7874 registries) {
        super.loadModData(tag, registries);
        if (tag.method_10573(TAG_STORED_PLAYER, class_2520.field_33261)) {
            this.storedPlayer = tag.method_25926(TAG_STORED_PLAYER);
        } else {
            this.storedPlayer = null;
        }
        if (tag.method_10573(TAG_STORED_PLAYER_PROFILE, class_2520.field_33260)) {
            this.storedPlayerProfile = class_5699.field_40726.parse(class_2509.field_11560, tag.method_10562(TAG_STORED_PLAYER_PROFILE)).getOrThrow();
        } else {
            this.storedPlayerProfile = null;
        }
    }
}
