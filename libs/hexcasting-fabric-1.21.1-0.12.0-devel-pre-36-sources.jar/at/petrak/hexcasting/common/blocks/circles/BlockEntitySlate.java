package at.petrak.hexcasting.common.blocks.circles;

import at.petrak.hexcasting.api.block.HexBlockEntity;
import at.petrak.hexcasting.api.casting.math.HexPattern;
import at.petrak.hexcasting.common.lib.HexBlockEntities;
import at.petrak.hexcasting.common.lib.HexDataComponents;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2509;
import net.minecraft.class_2520;
import net.minecraft.class_2680;
import net.minecraft.class_7225;
import net.minecraft.class_9323;
import org.jetbrains.annotations.Nullable;

public class BlockEntitySlate extends HexBlockEntity {
    public static final String TAG_PATTERN = "pattern";

    @Nullable
    public HexPattern pattern;

    public BlockEntitySlate(class_2338 pos, class_2680 state) {
        super(HexBlockEntities.SLATE_TILE.get(), pos, state);
    }

    @Override
    protected void method_57567(class_9323.class_9324 components) {
        super.method_57567(components);
        if (this.pattern != null) {
            components.method_57840(HexDataComponents.PATTERN.get(), this.pattern);
        }
    }

    @Override
    protected void method_57568(class_9473 componentInput) {
        super.method_57568(componentInput);
        var pat = componentInput.method_58694(HexDataComponents.PATTERN.get());
        if (pat != null) {
            this.pattern = pat;
        }
    }

    @Override
    protected void saveModData(class_2487 tag, class_7225.class_7874 registries) {
        if (this.pattern != null) {
            tag.method_10566(TAG_PATTERN, HexPattern.CODEC.encodeStart(class_2509.field_11560, pattern).getOrThrow());
        } else {
            tag.method_10566(TAG_PATTERN, new class_2487());
        }
    }

    @Override
    protected void loadModData(class_2487 tag, class_7225.class_7874 registries) {
        if (tag.method_10573(TAG_PATTERN, class_2520.field_33260)) {
            class_2520 patternTag = tag.method_10580(TAG_PATTERN);
            this.pattern = HexPattern.CODEC.parse(class_2509.field_11560, patternTag).result().orElse(null);
        } else {
            this.pattern = null;
        }
    }

}
