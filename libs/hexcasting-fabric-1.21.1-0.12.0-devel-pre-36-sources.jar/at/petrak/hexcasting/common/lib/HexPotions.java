package at.petrak.hexcasting.common.lib;

import at.petrak.hexcasting.xplat.IXplatAbstractions;
import at.petrak.hexcasting.xplat.IXplatRegister;
import net.minecraft.class_1293;
import net.minecraft.class_1802;
import net.minecraft.class_1842;
import net.minecraft.class_1845;
import net.minecraft.class_1847;
import net.minecraft.class_6880;
import net.minecraft.class_7924;

public class HexPotions {
    private static final IXplatRegister<class_1842> REGISTER = IXplatAbstractions.INSTANCE.createRegistar(class_7924.field_41215);

    public static void register() {
        REGISTER.registerAll();
    }

    public static final class_6880<class_1842> ENLARGE_GRID = REGISTER.registerHolder("enlarge_grid", () ->
        new class_1842("enlarge_grid", new class_1293(HexMobEffects.ENLARGE_GRID, 3600)));
    public static final class_6880<class_1842> ENLARGE_GRID_LONG = REGISTER.registerHolder("enlarge_grid_long", () ->
        new class_1842("enlarge_grid_long", new class_1293(HexMobEffects.ENLARGE_GRID, 9600)));
    public static final class_6880<class_1842> ENLARGE_GRID_STRONG = REGISTER.registerHolder("enlarge_grid_strong", () ->
        new class_1842("enlarge_grid_strong", new class_1293(HexMobEffects.ENLARGE_GRID, 1800, 1)));

    public static final class_6880<class_1842> SHRINK_GRID = REGISTER.registerHolder("shrink_grid", () ->
        new class_1842("shrink_grid", new class_1293(HexMobEffects.SHRINK_GRID, 3600)));
    public static final class_6880<class_1842> SHRINK_GRID_LONG = REGISTER.registerHolder("shrink_grid_long", () ->
        new class_1842("shrink_grid_long", new class_1293(HexMobEffects.SHRINK_GRID, 9600)));
    public static final class_6880<class_1842> SHRINK_GRID_STRONG = REGISTER.registerHolder("shrink_grid_strong", () ->
        new class_1842("shrink_grid_strong", new class_1293(HexMobEffects.SHRINK_GRID, 1800, 1)));

    public static void addRecipes(class_1845.class_9665 builder) {
        builder.method_59705(class_1847.field_8999, HexItems.AMETHYST_DUST.get(), ENLARGE_GRID);
        builder.method_59705(ENLARGE_GRID, class_1802.field_8725, ENLARGE_GRID_LONG);
        builder.method_59705(ENLARGE_GRID, class_1802.field_8601, ENLARGE_GRID_STRONG);

        builder.method_59705(ENLARGE_GRID, class_1802.field_8711, SHRINK_GRID);
        builder.method_59705(ENLARGE_GRID_LONG, class_1802.field_8711, SHRINK_GRID_LONG);
        builder.method_59705(ENLARGE_GRID_STRONG, class_1802.field_8711, SHRINK_GRID_STRONG);

        builder.method_59705(SHRINK_GRID, class_1802.field_8725, SHRINK_GRID_LONG);
        builder.method_59705(SHRINK_GRID, class_1802.field_8601, SHRINK_GRID_STRONG);
    }
}
