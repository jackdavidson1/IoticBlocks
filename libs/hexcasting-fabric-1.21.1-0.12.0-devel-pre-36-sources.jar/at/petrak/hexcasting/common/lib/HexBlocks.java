package at.petrak.hexcasting.common.lib;

import at.petrak.hexcasting.api.block.circle.BlockAbstractImpetus;
import at.petrak.hexcasting.common.blocks.BlockConjured;
import at.petrak.hexcasting.common.blocks.BlockConjuredLight;
import at.petrak.hexcasting.common.blocks.BlockFlammable;
import at.petrak.hexcasting.common.blocks.BlockQuenchedAllay;
import at.petrak.hexcasting.common.blocks.akashic.BlockAkashicBookshelf;
import at.petrak.hexcasting.common.blocks.akashic.BlockAkashicLigature;
import at.petrak.hexcasting.common.blocks.akashic.BlockAkashicRecord;
import at.petrak.hexcasting.common.blocks.circles.BlockEmptyImpetus;
import at.petrak.hexcasting.common.blocks.circles.BlockSlate;
import at.petrak.hexcasting.common.blocks.circles.directrix.BlockBooleanDirectrix;
import at.petrak.hexcasting.common.blocks.circles.directrix.BlockEmptyDirectrix;
import at.petrak.hexcasting.common.blocks.circles.directrix.BlockRedstoneDirectrix;
import at.petrak.hexcasting.common.blocks.circles.impetuses.BlockLookingImpetus;
import at.petrak.hexcasting.common.blocks.circles.impetuses.BlockRedstoneImpetus;
import at.petrak.hexcasting.common.blocks.circles.impetuses.BlockRightClickImpetus;
import at.petrak.hexcasting.common.blocks.decoration.*;
import at.petrak.hexcasting.xplat.IXplatAbstractions;
import at.petrak.hexcasting.xplat.IXplatRegister;
import net.minecraft.class_1299;
import net.minecraft.class_1747;
import net.minecraft.class_1761;
import net.minecraft.class_1792;
import net.minecraft.class_1814;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2269;
import net.minecraft.class_2323;
import net.minecraft.class_2349;
import net.minecraft.class_2354;
import net.minecraft.class_2440;
import net.minecraft.class_2465;
import net.minecraft.class_2482;
import net.minecraft.class_2498;
import net.minecraft.class_2510;
import net.minecraft.class_2533;
import net.minecraft.class_3619;
import net.minecraft.class_3620;
import net.minecraft.class_4970;
import net.minecraft.class_5321;
import net.minecraft.class_5541;
import net.minecraft.class_7924;
import net.minecraft.class_8805;
import net.minecraft.class_8812;
import net.minecraft.world.level.block.*;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Supplier;

public class HexBlocks {
    private static final IXplatRegister<class_2248> REGISTER_BLOCKS = IXplatAbstractions.INSTANCE.createRegistar(class_7924.field_41254);
    private static final IXplatRegister<class_1792> REGISTER_BLOCK_ITEMS = IXplatAbstractions.INSTANCE.createRegistar(class_7924.field_41197);
    private static final Map<class_5321<class_1761>, List<Supplier<class_2248>>> BLOCK_TABS = new LinkedHashMap<>();

    public static void register() {
        REGISTER_BLOCKS.registerAll();
        REGISTER_BLOCK_ITEMS.registerAll();
    }

    public static void registerBlocksForCreativeTab(class_5321<class_1761> tabKey, class_1761.class_7704 r) {
        for (Supplier<class_2248> blockSupplier : BLOCK_TABS.getOrDefault(tabKey, List.of())) {
            r.method_45421(blockSupplier.get());
        }
    }


    private static class_4970.class_2251 slateish() {
        return class_4970.class_2251
            .method_9630(class_2246.field_28896)
            .method_9629(4f, 4f);
    }

    private static class_4970.class_2251 papery(class_3620 color) {
        return class_4970.class_2251
            .method_9637()
            .method_31710(color)
            .method_9626(class_2498.field_11535)
            .method_9618()
            .method_50013()
            .method_50012(class_3619.field_15971);
    }

    private static class_4970.class_2251 akashicWoodyHard() {
        return woodyHard(class_3620.field_16014);
    }

    private static class_4970.class_2251 woodyHard(class_3620 color) {
        return class_4970.class_2251
            .method_9630(class_2246.field_10431)
            .method_31710(color)
            .method_9626(class_2498.field_11547)
            .method_9629(3f, 4f);
    }

    private static class_4970.class_2251 edifiedWoody() {
        return woody(class_3620.field_16014);
    }

    private static class_4970.class_2251 woody(class_3620 color) {
        return class_4970.class_2251
            .method_9630(class_2246.field_10431)
            .method_31710(color)
            .method_9626(class_2498.field_11547)
            .method_9632(2f);
    }

    private static class_4970.class_2251 leaves(class_3620 color) {
        return class_4970.class_2251
            .method_9630(class_2246.field_10503)
            .method_9632(0.2F)
            .method_9640()
            .method_9626(class_2498.field_11535)
            .method_22488()
            .method_26235((bs, level, pos, type) -> type == class_1299.field_6081 || type == class_1299.field_6104)
            .method_26243(HexBlocks::never)
            .method_26245(HexBlocks::never);
    }

    // we have to make it emit light because otherwise it occludes itself and is always dark
    private static class_4970.class_2251 quenched() {
        return class_4970.class_2251
            .method_9630(class_2246.field_27159)
            .method_9631($ -> 4)
            .method_22488();
    }

    // we give these faux items so Patchi can have an item to view with
    public static final Supplier<class_2248> CONJURED_LIGHT = blockItem("conjured_light", () ->
        new BlockConjuredLight(
            class_4970.class_2251.method_9637()
                .method_31710(class_3620.field_16008)
                .method_9626(class_2498.field_27197)
                .method_9631((state) -> 15)
                .method_42327()
                .method_26235(HexBlocks::never)
                .method_9618()
                .method_50012(class_3619.field_15971)
                .method_9634()
                .method_26243(HexBlocks::never)
                .method_26245(HexBlocks::never)),
        new class_1792.class_1793());
    public static final Supplier<class_2248> CONJURED_BLOCK = blockItem("conjured_block", () ->
        new BlockConjured(
            class_4970.class_2251.method_9637()
                .method_31710(class_3620.field_16008)
                .method_9626(class_2498.field_27197)
                .method_9631((state) -> 2)
                .method_42327()
                .method_26235(HexBlocks::never)
                .method_9618()
                .method_22488()
                .method_26243(HexBlocks::never)
                .method_26245(HexBlocks::never)),
        new class_1792.class_1793());

    // "no" item because we add it manually
    public static final Supplier<BlockSlate> SLATE = blockNoItem("slate", () ->
        new BlockSlate(slateish()
            .method_50012(class_3619.field_15971)));

    public static final Supplier<BlockEmptyImpetus> IMPETUS_EMPTY = blockItem("impetus/empty", () ->
        new BlockEmptyImpetus(slateish()
            .method_50012(class_3619.field_15972)));
    public static final Supplier<BlockRightClickImpetus> IMPETUS_RIGHTCLICK = blockItem("impetus/rightclick", () ->
        new BlockRightClickImpetus(slateish()
            .method_50012(class_3619.field_15972)
            .method_9631(bs -> bs.method_11654(BlockAbstractImpetus.ENERGIZED) ? 15 : 0)),
        HexItems.props().method_7894(class_1814.field_8907));
    public static final Supplier<BlockLookingImpetus> IMPETUS_LOOK = blockItem("impetus/look", () ->
        new BlockLookingImpetus(slateish()
            .method_50012(class_3619.field_15972)
            .method_9631(bs -> bs.method_11654(BlockAbstractImpetus.ENERGIZED) ? 15 : 0)),
        HexItems.props().method_7894(class_1814.field_8907));
    public static final Supplier<BlockRedstoneImpetus> IMPETUS_REDSTONE = blockItem("impetus/redstone", () ->
        new BlockRedstoneImpetus(slateish()
            .method_50012(class_3619.field_15972)
            .method_9631(bs -> bs.method_11654(BlockAbstractImpetus.ENERGIZED) ? 15 : 0)),
        HexItems.props().method_7894(class_1814.field_8907));


    public static final Supplier<BlockEmptyDirectrix> EMPTY_DIRECTRIX = blockItem("directrix/empty", () ->
        new BlockEmptyDirectrix(slateish()
            .method_50012(class_3619.field_15972)));
    public static final Supplier<BlockRedstoneDirectrix> DIRECTRIX_REDSTONE = blockItem("directrix/redstone", () ->
        new BlockRedstoneDirectrix(slateish()
            .method_50012(class_3619.field_15972)),
        HexItems.props().method_7894(class_1814.field_8907));
    public static final Supplier<BlockBooleanDirectrix> DIRECTRIX_BOOLEAN = blockItem("directrix/boolean", () ->
        new BlockBooleanDirectrix(slateish()
            .method_50012(class_3619.field_15972)),
        HexItems.props().method_7894(class_1814.field_8907));

    public static final Supplier<BlockAkashicRecord> AKASHIC_RECORD = blockItem("akashic_record", () ->
        new BlockAkashicRecord(akashicWoodyHard().method_9631(bs -> 15)),
        HexItems.props().method_7894(class_1814.field_8903)
    );
    public static final Supplier<BlockAkashicBookshelf> AKASHIC_BOOKSHELF = blockItem("akashic_bookshelf", () ->
        new BlockAkashicBookshelf(akashicWoodyHard()
            .method_9631(bs -> (bs.method_11654(BlockAkashicBookshelf.HAS_BOOKS)) ? 4 : 0)));
    public static final Supplier<BlockAkashicLigature> AKASHIC_LIGATURE = blockItem("akashic_ligature", () ->
        new BlockAkashicLigature(akashicWoodyHard().method_9631(bs -> 4)));

    public static final Supplier<BlockQuenchedAllay> QUENCHED_ALLAY = blockItem("quenched_allay", () ->
        new BlockQuenchedAllay(quenched()), 
        HexItems.props().method_7894(class_1814.field_8907)
    );

    // Decoration?!
    public static final Supplier<BlockQuenchedAllay> QUENCHED_ALLAY_TILES = blockItem("quenched_allay_tiles", () -> new BlockQuenchedAllay(quenched()));
    public static final Supplier<BlockQuenchedAllay> QUENCHED_ALLAY_BRICKS = blockItem("quenched_allay_bricks", () -> new BlockQuenchedAllay(quenched()));
    public static final Supplier<BlockQuenchedAllay> QUENCHED_ALLAY_BRICKS_SMALL = blockItem("quenched_allay_bricks_small", () -> new BlockQuenchedAllay(quenched()));
    public static final Supplier<class_2248> SLATE_BLOCK = blockItem("slate_block", () -> new class_2248(slateish().method_9629(2f, 4f)));
    public static final Supplier<class_2248> SLATE_TILES = blockItem("slate_tiles", () -> new class_2248(slateish().method_9629(2f, 4f)));
    public static final Supplier<class_2248> SLATE_BRICKS = blockItem("slate_bricks", () -> new class_2248(slateish().method_9629(2f, 4f)));
    public static final Supplier<class_2248> SLATE_BRICKS_SMALL = blockItem("slate_bricks_small", () -> new class_2248(slateish().method_9629(2f, 4f)));
    public static final Supplier<class_2465> SLATE_PILLAR = blockItem("slate_pillar", () -> new class_2465(slateish().method_9629(2f, 4f)));
    public static final Supplier<class_8812> AMETHYST_DUST_BLOCK = blockItem("amethyst_dust_block", () ->
        new class_8812(new class_8805(0xb38ef3_ff), class_4970.class_2251.method_9630(class_2246.field_10102).method_31710(class_3620.field_16014)
            .method_9632(0.5f).method_9626(class_2498.field_11526)));
    public static final Supplier<class_5541> AMETHYST_TILES = blockItem("amethyst_tiles", () ->
        new class_5541(class_4970.class_2251.method_9630(class_2246.field_27159)));
    public static final Supplier<class_5541> AMETHYST_BRICKS = blockItem("amethyst_bricks", () ->
            new class_5541(class_4970.class_2251.method_9630(class_2246.field_27159)));
    public static final Supplier<class_5541> AMETHYST_BRICKS_SMALL = blockItem("amethyst_bricks_small", () ->
            new class_5541(class_4970.class_2251.method_9630(class_2246.field_27159)));
    public static final Supplier<BlockAmethystDirectional> AMETHYST_PILLAR = blockItem("amethyst_pillar", () ->
            new BlockAmethystDirectional(class_4970.class_2251.method_9630(class_2246.field_27159)));
    public static final Supplier<class_2248> SLATE_AMETHYST_TILES = blockItem("slate_amethyst_tiles", () -> new class_2248(slateish().method_9629(2f, 4f)));
    public static final Supplier<class_2248> SLATE_AMETHYST_BRICKS = blockItem("slate_amethyst_bricks", () -> new class_2248(slateish().method_9629(2f, 4f)));
    public static final Supplier<class_2248> SLATE_AMETHYST_BRICKS_SMALL = blockItem("slate_amethyst_bricks_small", () -> new class_2248(slateish().method_9629(2f, 4f)));
    public static final Supplier<class_2465> SLATE_AMETHYST_PILLAR = blockItem("slate_amethyst_pillar", () ->
            new class_2465(slateish().method_9629(2f, 4f)));
    public static final Supplier<class_2248> SCROLL_PAPER = blockItem("scroll_paper", () ->
        new BlockFlammable(papery(class_3620.field_16003), 100, 60));
    public static final Supplier<class_2248> ANCIENT_SCROLL_PAPER = blockItem("ancient_scroll_paper", () ->
        new BlockFlammable(papery(class_3620.field_15981), 100, 60));
    public static final Supplier<class_2248> SCROLL_PAPER_LANTERN = blockItem("scroll_paper_lantern", () ->
        new BlockFlammable(papery(class_3620.field_16003).method_9631($ -> 15), 100, 60));
    public static final Supplier<class_2248> ANCIENT_SCROLL_PAPER_LANTERN = blockItem(
        "ancient_scroll_paper_lantern", () ->
        new BlockFlammable(papery(class_3620.field_15981).method_9631($ -> 12), 100, 60));
    public static final Supplier<BlockSconce> SCONCE = blockItem("amethyst_sconce", () ->
        new BlockSconce(class_4970.class_2251.method_9637()
            .method_31710(class_3620.field_16014)
            .method_9626(class_2498.field_27197)
            .method_9632(1f)
            .method_9631($ -> 15))
        );

    public static final Supplier<BlockAkashicLog> EDIFIED_LOG = blockItem("edified_log", () ->
        new BlockAkashicLog(edifiedWoody()));
    public static final Supplier<BlockAkashicLog> EDIFIED_LOG_AMETHYST = blockItem("edified_log_amethyst", () ->
            new BlockAkashicLog(edifiedWoody()));
    public static final Supplier<BlockAkashicLog> EDIFIED_LOG_AVENTURINE = blockItem("edified_log_aventurine", () ->
            new BlockAkashicLog(edifiedWoody()));
    public static final Supplier<BlockAkashicLog> EDIFIED_LOG_CITRINE = blockItem("edified_log_citrine", () ->
            new BlockAkashicLog(edifiedWoody()));
    public static final Supplier<BlockAkashicLog> EDIFIED_LOG_PURPLE = blockItem("edified_log_purple", () ->
            new BlockAkashicLog(edifiedWoody()));
    public static final Supplier<BlockAkashicLog> STRIPPED_EDIFIED_LOG = blockItem("stripped_edified_log", () ->
        new BlockAkashicLog(edifiedWoody()));
    public static final Supplier<BlockAkashicLog> EDIFIED_WOOD = blockItem("edified_wood", () ->
        new BlockAkashicLog(edifiedWoody()));
    public static final Supplier<BlockAkashicLog> STRIPPED_EDIFIED_WOOD = blockItem("stripped_edified_wood", () ->
        new BlockAkashicLog(edifiedWoody()));
    public static final Supplier<class_2248> EDIFIED_PLANKS = blockItem("edified_planks", () ->
        new BlockFlammable(edifiedWoody(), 20, 5));
    public static final Supplier<class_2248> EDIFIED_PANEL = blockItem("edified_panel", () ->
        new BlockFlammable(edifiedWoody(), 20, 5));
    public static final Supplier<class_2248> EDIFIED_TILE = blockItem("edified_tile", () ->
        new BlockFlammable(edifiedWoody(), 20, 5));
    public static final Supplier<class_2323> EDIFIED_DOOR = blockItem("edified_door", () ->
        new BlockHexDoor(edifiedWoody().method_22488()));
    public static final Supplier<class_2533> EDIFIED_TRAPDOOR = blockItem("edified_trapdoor", () ->
        new BlockHexTrapdoor(edifiedWoody().method_22488()));
    public static final Supplier<class_2510> EDIFIED_STAIRS = blockItem("edified_stairs", () ->
        new BlockHexStairs(EDIFIED_PLANKS.get().method_9564(), edifiedWoody().method_22488()));

    public static final Supplier<class_2354> EDIFIED_FENCE = blockItem("edified_fence", () ->
            new BlockHexFence(edifiedWoody().method_22488()));
    public static final Supplier<class_2349> EDIFIED_FENCE_GATE = blockItem("edified_fence_gate", () ->
            new BlockHexFenceGate(edifiedWoody().method_22488()));

    public static final Supplier<class_2482> EDIFIED_SLAB = blockItem("edified_slab", () ->
        new BlockHexSlab(edifiedWoody().method_22488()));
    public static final Supplier<class_2269> EDIFIED_BUTTON = blockItem("edified_button", () ->
        new BlockHexWoodButton(edifiedWoody().method_22488().method_9634()));
    public static final Supplier<class_2440> EDIFIED_PRESSURE_PLATE = blockItem("edified_pressure_plate", () ->
        new BlockHexPressurePlate(edifiedWoody().method_22488().method_9634()));
    public static final Supplier<BlockAkashicLeaves> AMETHYST_EDIFIED_LEAVES = blockItem("amethyst_edified_leaves", () ->
        new BlockAkashicLeaves(leaves(class_3620.field_16014)));
    public static final Supplier<BlockAkashicLeaves> AVENTURINE_EDIFIED_LEAVES = blockItem("aventurine_edified_leaves", () ->
        new BlockAkashicLeaves(leaves(class_3620.field_15984)));
    public static final Supplier<BlockAkashicLeaves> CITRINE_EDIFIED_LEAVES = blockItem("citrine_edified_leaves", () ->
        new BlockAkashicLeaves(leaves(class_3620.field_16010)));

    private static boolean never(Object... args) {
        return false;
    }

    private static <T extends class_2248> Supplier<T> blockNoItem(String name, Supplier<T> blockSupplier) {
        return REGISTER_BLOCKS.register(name, blockSupplier);
    }
    private static <T extends class_2248> Supplier<T> blockItem(String name, Supplier<T> blockSupplier) {
        return blockItem(name, blockSupplier, HexItems.props(), HexCreativeTabs.HEX_KEY);
    }

    private static <T extends class_2248> Supplier<T> blockItem(String name, Supplier<T> blockSupplier, @Nullable class_5321<class_1761> tabKey) {
        return blockItem(name, blockSupplier, HexItems.props(), tabKey);
    }
    private static <T extends class_2248> Supplier<T> blockItem(String name, Supplier<T> blockSupplier, class_1792.class_1793 props) {
        return blockItem(name, blockSupplier, props, HexCreativeTabs.HEX_KEY);
    }

    private static <T extends class_2248> Supplier<T> blockItem(String name, Supplier<T> blockSupplier, class_1792.class_1793 props, @Nullable class_5321<class_1761> tabKey) {
        Supplier<T> supplier = blockNoItem(name, blockSupplier);
        REGISTER_BLOCK_ITEMS.register(name, () -> new class_1747(supplier.get(), props));
        if (tabKey != null) {
            BLOCK_TABS.computeIfAbsent(tabKey, t -> new ArrayList<>()).add(supplier::get);
        }
        return supplier;
    }
}


