package at.petrak.hexcasting.common.lib;

import at.petrak.hexcasting.xplat.IXplatAbstractions;
import at.petrak.hexcasting.xplat.IXplatRegister;
import net.minecraft.class_3414;
import net.minecraft.class_6880;
import net.minecraft.class_7924;

import static at.petrak.hexcasting.api.HexAPI.modLoc;

public class HexSounds {
    private static final IXplatRegister<class_3414> REGISTER = IXplatAbstractions.INSTANCE.createRegistar(class_7924.field_41225);

    public static void register() {
        REGISTER.registerAll();
    }

    public static final class_6880<class_3414> START_PATTERN = REGISTER.registerHolder("casting.pattern.start", () ->
        class_3414.method_47908(modLoc("casting.pattern.start")));
    public static final class_6880<class_3414> ADD_TO_PATTERN = REGISTER.registerHolder("casting.pattern.add_segment", () ->
        class_3414.method_47908(modLoc("casting.pattern.add_segment")));

    public static final class_6880<class_3414> CASTING_AMBIANCE = REGISTER.registerHolder("casting.ambiance", () ->
        class_3414.method_47908(modLoc("casting.ambiance")));

    public static final class_6880<class_3414> CAST_NORMAL = REGISTER.registerHolder("casting.cast.normal", () ->
        class_3414.method_47908(modLoc("casting.cast.normal")));
    public static final class_6880<class_3414> CAST_SPELL = REGISTER.registerHolder("casting.cast.spell", () ->
        class_3414.method_47908(modLoc("casting.cast.spell")));
    public static final class_6880<class_3414> CAST_HERMES = REGISTER.registerHolder("casting.cast.hermes", () ->
        class_3414.method_47908(modLoc("casting.cast.hermes")));
    public static final class_6880<class_3414> CAST_THOTH = REGISTER.registerHolder("casting.cast.thoth", () ->
        class_3414.method_47908(modLoc("casting.cast.thoth")));
    public static final class_6880<class_3414> CAST_FAILURE = REGISTER.registerHolder("casting.cast.fail", () ->
        class_3414.method_47908(modLoc("casting.cast.fail")));

    public static final class_6880<class_3414> ABACUS = REGISTER.registerHolder("abacus", () ->
        class_3414.method_47908(modLoc("abacus")));
    public static final class_6880<class_3414> ABACUS_SHAKE = REGISTER.registerHolder("abacus.shake", () ->
        class_3414.method_47908(modLoc("abacus.shake")));

    public static final class_6880<class_3414> STAFF_RESET = REGISTER.registerHolder("staff.reset", () ->
        class_3414.method_47908(modLoc("staff.reset")));

    public static final class_6880<class_3414> SPELL_CIRCLE_FIND_BLOCK = REGISTER.registerHolder("spellcircle.find_block", () ->
        class_3414.method_47908(modLoc("spellcircle.find_block")));
    public static final class_6880<class_3414> SPELL_CIRCLE_FAIL = REGISTER.registerHolder("spellcircle.fail", () ->
        class_3414.method_47908(modLoc("spellcircle.fail")));

    public static final class_6880<class_3414> SCROLL_DUST = REGISTER.registerHolder("scroll.dust", () ->
        class_3414.method_47908(modLoc("scroll.dust")));
    public static final class_6880<class_3414> SCROLL_SCRIBBLE = REGISTER.registerHolder("scroll.scribble", () ->
        class_3414.method_47908(modLoc("scroll.scribble")));

    public static final class_6880<class_3414> IMPETUS_LOOK_TICK = REGISTER.registerHolder("impetus.fletcher.tick", () ->
        class_3414.method_47908(modLoc("impetus.fletcher.tick")));
    public static final class_6880<class_3414> IMPETUS_REDSTONE_DING = REGISTER.registerHolder("impetus.redstone.register", () ->
        class_3414.method_47908(modLoc("impetus.redstone.register")));
    public static final class_6880<class_3414> IMPETUS_REDSTONE_CLEAR = REGISTER.registerHolder("impetus.redstone.clear", () ->
        class_3414.method_47908(modLoc("impetus.redstone.clear")));

    public static final class_6880<class_3414> READ_LORE_FRAGMENT = REGISTER.registerHolder("lore_fragment.read", () ->
        class_3414.method_47908(modLoc("lore_fragment.read")));

    public static final class_6880<class_3414> FLIGHT_AMBIENCE = REGISTER.registerHolder("flight.ambience", () ->
        class_3414.method_47908(modLoc("flight.ambience")));
    public static final class_6880<class_3414> FLIGHT_FINISH = REGISTER.registerHolder("flight.finish", () ->
        class_3414.method_47908(modLoc("flight.finish")));
}
