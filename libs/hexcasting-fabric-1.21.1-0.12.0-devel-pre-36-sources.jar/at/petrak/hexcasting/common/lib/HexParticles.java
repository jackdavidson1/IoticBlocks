package at.petrak.hexcasting.common.lib;

import at.petrak.hexcasting.client.particles.ConjureParticle;
import at.petrak.hexcasting.common.particles.ConjureParticleOptions;
import at.petrak.hexcasting.xplat.IXplatAbstractions;
import at.petrak.hexcasting.xplat.IXplatRegister;
import java.util.function.Function;
import java.util.function.Supplier;
import net.minecraft.class_2394;
import net.minecraft.class_2396;
import net.minecraft.class_4002;
import net.minecraft.class_707;
import net.minecraft.class_7924;

public class HexParticles {
    private static final IXplatRegister<class_2396<?>> REGISTER = IXplatAbstractions.INSTANCE.createRegistar(class_7924.field_41210);

    public static void register() {
        REGISTER.registerAll();
    }

    public static final Supplier<ConjureParticleOptions.Type> CONJURE_PARTICLE = REGISTER.register(
        "conjure_particle", () -> new ConjureParticleOptions.Type(false));

    public static class FactoryHandler {
        public interface Consumer {
            <T extends class_2394> void register(class_2396<T> type,
                Function<class_4002, class_707<T>> constructor);
        }

        public static void registerFactories(Consumer consumer) {
            consumer.register(CONJURE_PARTICLE.get(), ConjureParticle.Provider::new);
        }
    }
}
