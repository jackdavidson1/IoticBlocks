package at.petrak.hexcasting.common.lib;

import at.petrak.hexcasting.common.loot.AddHexToAncientCypherFunc;
import at.petrak.hexcasting.common.loot.AddPerWorldPatternToScrollFunc;
import at.petrak.hexcasting.common.loot.AmethystReducerFunc;
import at.petrak.hexcasting.xplat.IXplatAbstractions;
import at.petrak.hexcasting.xplat.IXplatRegister;
import java.util.function.Supplier;
import net.minecraft.class_120;
import net.minecraft.class_5339;
import net.minecraft.class_7924;

public class HexLootFunctions {
    private static final IXplatRegister<class_5339<?>> REGISTER = IXplatAbstractions.INSTANCE.createRegistar(class_7924.field_41199);

    public static void register() {
        REGISTER.registerAll();
    }

    public static final Supplier<class_5339<? extends class_120>> PATTERN_SCROLL = REGISTER.register("pattern_scroll",
            () -> new class_5339<>(AddPerWorldPatternToScrollFunc.CODEC));
    public static final Supplier<class_5339<? extends class_120>> HEX_CYPHER = REGISTER.register("hex_cypher",
            () -> new class_5339<>(AddHexToAncientCypherFunc.CODEC));
    public static final Supplier<class_5339<? extends class_120>> AMETHYST_SHARD_REDUCER = REGISTER.register("amethyst_shard_reducer",
            () -> new class_5339<>(AmethystReducerFunc.CODEC));
}
