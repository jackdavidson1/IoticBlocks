package at.petrak.hexcasting.common.lib;

import at.petrak.hexcasting.common.recipe.ingredient.state.*;
import at.petrak.hexcasting.xplat.IXplatAbstractions;
import at.petrak.hexcasting.xplat.IXplatRegister;
import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import java.util.List;
import java.util.Random;
import java.util.function.Supplier;
import net.minecraft.class_1799;
import net.minecraft.class_2248;
import net.minecraft.class_2680;
import net.minecraft.class_6862;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public class HexStateIngredients {
    private static final IXplatRegister<StateIngredientType<?>> REGISTER = IXplatAbstractions.INSTANCE.createRegistar(HexRegistries.STATE_INGREDIENT);

    public static void register() {
        REGISTER.registerAll();
    }

    public static final Codec<StateIngredient> TYPED_CODEC = Codec.lazyInitialized(() -> IXplatAbstractions.INSTANCE
            .getStateIngredientRegistry()
            .method_39673()
            .dispatch("type", StateIngredient::getType, StateIngredientType::codec));
    public static final class_9139<class_9129, StateIngredient> TYPED_STREAM_CODEC = class_9135
            .method_56365(HexRegistries.STATE_INGREDIENT)
            .method_56440(StateIngredient::getType, StateIngredientType::streamCodec);

    public static final Supplier<StateIngredientType<StateIngredientBlock>> BLOCK_TYPE = REGISTER.register("block", StateIngredientBlock.Type::new);
    public static final Supplier<StateIngredientType<StateIngredientBlockState>> BLOCK_STATE = REGISTER.register("state", StateIngredientBlockState.Type::new);
    public static final Supplier<StateIngredientType<StateIngredientBlocks>> BLOCKS = REGISTER.register("blocks", StateIngredientBlocks.Type::new);
    public static final Supplier<StateIngredientType<StateIngredientTag>> TAG = REGISTER.register("tag", StateIngredientTag.Type::new);
    public static final Supplier<StateIngredientType<StateIngredientTagExcluding>> TAG_EXCLUDING = REGISTER.register("tag_excluding", StateIngredientTagExcluding.Type::new);

    public static final Supplier<StateIngredientType<? extends StateIngredient>> NONE_TYPE = REGISTER.register("none", () -> new StateIngredientType<>() {
        @Override
        public MapCodec<StateIngredient> codec() {
            return MapCodec.unit(NONE);
        }

        @Override
        public class_9139<class_9129, StateIngredient> streamCodec() {
            return class_9139.method_56431(NONE);
        }
    });

    public static final StateIngredient NONE = new StateIngredient() {
        @Override
        public boolean test(class_2680 state) {
            return true;
        }

        @Override
        public class_2680 pick(Random random) {
            throw new UnsupportedOperationException("Should never try to pick from NONE state ingredient");
        }

        @Override
        public StateIngredientType<?> getType() {
            return NONE_TYPE.get();
        }

        @Override
        public List<class_1799> getDisplayedStacks() {
            return List.of();
        }

        @Override
        public List<class_2680> getDisplayed() {
            return List.of();
        }
    };

    public static StateIngredient of(class_2248 block) {
        return new StateIngredientBlock(block);
    }

    public static StateIngredient of(class_2680 state) {
        return new StateIngredientBlockState(state);
    }

    public static StateIngredient of(class_6862<class_2248> tag) {
        return new StateIngredientTag(tag);
    }
}
