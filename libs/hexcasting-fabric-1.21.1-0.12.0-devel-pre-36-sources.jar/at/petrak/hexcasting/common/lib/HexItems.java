package at.petrak.hexcasting.common.lib;

import at.petrak.hexcasting.api.casting.ActionRegistryEntry;
import at.petrak.hexcasting.api.misc.MediaConstants;
import at.petrak.hexcasting.api.mod.HexTags;
import at.petrak.hexcasting.api.utils.HexUtils;
import at.petrak.hexcasting.common.items.ItemJewelerHammer;
import at.petrak.hexcasting.common.items.ItemLens;
import at.petrak.hexcasting.common.items.ItemLoreFragment;
import at.petrak.hexcasting.common.items.ItemStaff;
import at.petrak.hexcasting.common.items.magic.*;
import at.petrak.hexcasting.common.items.pigment.*;
import at.petrak.hexcasting.common.items.storage.*;
import at.petrak.hexcasting.xplat.IXplatAbstractions;
import at.petrak.hexcasting.xplat.IXplatRegister;
import com.google.common.base.Suppliers;
import net.minecraft.class_1304;
import net.minecraft.class_1322;
import net.minecraft.class_156;
import net.minecraft.class_1761;
import net.minecraft.class_1767;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1814;
import net.minecraft.class_1834;
import net.minecraft.class_2378;
import net.minecraft.class_4174;
import net.minecraft.class_5134;
import net.minecraft.class_5321;
import net.minecraft.class_7924;
import net.minecraft.class_9274;
import net.minecraft.class_9285;
import net.minecraft.world.item.*;
import org.jetbrains.annotations.Nullable;

import java.util.*;
import java.util.function.Supplier;

import static at.petrak.hexcasting.api.HexAPI.modLoc;

// https://github.com/VazkiiMods/Botania/blob/2c4f7fdf9ebf0c0afa1406dfe1322841133d75fa/Common/src/main/java/vazkii/botania/common/item/ModItems.java
public class HexItems {
    private static final IXplatRegister<class_1792> REGISTER = IXplatAbstractions.INSTANCE.createRegistar(class_7924.field_41197);

    public static void register() {
        REGISTER.registerAll();
    }

    public static void registerItemsForCreativeTab(class_5321<class_1761> tabKey, class_1761.class_7704 r) {
        if (tabKey == HexCreativeTabs.SCROLLS_KEY)
            generateScrollEntries(r);
        for (var item : ITEM_TABS.getOrDefault(tabKey, Collections.emptyList())) {
            item.register(r);
        }
    }

    private static final Map<class_5321<class_1761>, List<TabEntry>> ITEM_TABS = new LinkedHashMap<>();

    public static final Supplier<class_1792> AMETHYST_DUST = make("amethyst_dust", () -> new class_1792(props()));
    public static final Supplier<class_1792> CHARGED_AMETHYST = make("charged_amethyst", () -> new class_1792(props()));

    public static final Supplier<class_1792> QUENCHED_SHARD = make("quenched_allay_shard", () -> new class_1792(props().method_7894(class_1814.field_8907)));

    public static final Supplier<ItemStaff> STAFF_OAK = make("staff/oak", () -> new ItemStaff(unstackable()));
    public static final Supplier<ItemStaff> STAFF_SPRUCE = make("staff/spruce", () -> new ItemStaff(unstackable()));
    public static final Supplier<ItemStaff> STAFF_BIRCH = make("staff/birch", () -> new ItemStaff(unstackable()));
    public static final Supplier<ItemStaff> STAFF_JUNGLE = make("staff/jungle", () -> new ItemStaff(unstackable()));
    public static final Supplier<ItemStaff> STAFF_ACACIA = make("staff/acacia", () -> new ItemStaff(unstackable()));
    public static final Supplier<ItemStaff> STAFF_DARK_OAK = make("staff/dark_oak", () -> new ItemStaff(unstackable()));
    public static final Supplier<ItemStaff> STAFF_CRIMSON = make("staff/crimson", () -> new ItemStaff(unstackable()));
    public static final Supplier<ItemStaff> STAFF_WARPED = make("staff/warped", () -> new ItemStaff(unstackable()));
    public static final Supplier<ItemStaff> STAFF_MANGROVE = make("staff/mangrove", () -> new ItemStaff(unstackable()));
    public static final Supplier<ItemStaff> STAFF_CHERRY = make("staff/cherry", () -> new ItemStaff(unstackable()));
    public static final Supplier<ItemStaff> STAFF_BAMBOO = make("staff/bamboo", () -> new ItemStaff(unstackable()));
    public static final Supplier<ItemStaff> STAFF_EDIFIED = make("staff/edified", () -> new ItemStaff(unstackable()));
    public static final Supplier<ItemStaff> STAFF_QUENCHED = make("staff/quenched", () -> new ItemStaff(unstackable().method_7894(class_1814.field_8907)));
    // mindsplice staffaratus
    public static final Supplier<ItemStaff> STAFF_MINDSPLICE = make("staff/mindsplice", () -> new ItemStaff(unstackable().method_7894(class_1814.field_8907)));

    public static final Supplier<ItemLens> SCRYING_LENS = make("lens", () -> new ItemLens(
            IXplatAbstractions.INSTANCE.addEquipSlotFabric(class_1304.field_6169)
                    .method_7889(1).method_57348(ItemLens.MODIFIERS)));

    public static final Supplier<ItemAbacus> ABACUS = make("abacus", () -> new ItemAbacus(unstackable()));
    public static final Supplier<ItemThoughtKnot> THOUGHT_KNOT = make("thought_knot", () -> new ItemThoughtKnot(unstackable()));
    public static final Supplier<ItemFocus> FOCUS = make("focus", () -> new ItemFocus(unstackable()));
    public static final Supplier<ItemSpellbook> SPELLBOOK = make("spellbook", () -> new ItemSpellbook(unstackable()));

    public static final Supplier<ItemCypher> ANCIENT_CYPHER = make("ancient_cypher", () -> new ItemAncientCypher(unstackable()));
    public static final Supplier<ItemCypher> CYPHER = make("cypher", () -> new ItemCypher(unstackable()));
    public static final Supplier<ItemTrinket> TRINKET = make("trinket", () -> new ItemTrinket(unstackable().method_7894(class_1814.field_8907)));
    public static final Supplier<ItemArtifact> ARTIFACT = make("artifact", () -> new ItemArtifact(unstackable().method_7894(class_1814.field_8903)));

    public static final Supplier<ItemJewelerHammer> JEWELER_HAMMER = make("jeweler_hammer", () ->
            new ItemJewelerHammer(class_1834.field_8923, props()
                    .method_7889(1)
                    .method_7895(class_1834.field_8930.method_8025())
                    .method_57348(class_9285.method_57480()
                            .method_57487(class_5134.field_23723, new class_1322(
                                    modLoc("jeweler_hammer_speed"),
                                    -2.8,
                                    class_1322.class_1323.field_6328
                            ), class_9274.field_49216)
                            .method_57486()
                    )
            )
    );

    public static final Supplier<ItemScroll> SCROLL_SMOL = make("scroll_small", () -> new ItemScroll(props(), 1));
    public static final Supplier<ItemScroll> SCROLL_MEDIUM = make("scroll_medium", () -> new ItemScroll(props(), 2));
    public static final Supplier<ItemScroll> SCROLL_LARGE = make("scroll", () -> new ItemScroll(props(), 3));

    public static final Supplier<ItemSlate> SLATE = make("slate", () -> new ItemSlate(HexBlocks.SLATE.get(), props()));

    public static final Supplier<ItemMediaBattery> BATTERY = make("battery", () ->
            new ItemMediaBattery(unstackable()), null);

    public static final Supplier<class_1799> BATTERY_DUST_STACK = addToTab(() -> ItemMediaBattery.withMedia(
            new class_1799(HexItems.BATTERY.get()),
            MediaConstants.DUST_UNIT * 64,
            MediaConstants.DUST_UNIT * 64), HexCreativeTabs.HEX_KEY);
    public static final Supplier<class_1799> BATTERY_SHARD_STACK = addToTab(() -> ItemMediaBattery.withMedia(
            new class_1799(HexItems.BATTERY.get()),
            MediaConstants.SHARD_UNIT * 64,
            MediaConstants.SHARD_UNIT * 64), HexCreativeTabs.HEX_KEY);
    public static final Supplier<class_1799> BATTERY_CRYSTAL_STACK = addToTab(() -> ItemMediaBattery.withMedia(
            new class_1799(HexItems.BATTERY.get()),
            MediaConstants.CRYSTAL_UNIT * 64,
            MediaConstants.CRYSTAL_UNIT * 64), HexCreativeTabs.HEX_KEY);
    public static final Supplier<class_1799> BATTERY_QUENCHED_SHARD_STACK = addToTab(() -> ItemMediaBattery.withMedia(
            new class_1799(HexItems.BATTERY.get()),
            MediaConstants.QUENCHED_SHARD_UNIT * 64,
            MediaConstants.QUENCHED_SHARD_UNIT * 64), HexCreativeTabs.HEX_KEY);
    public static final Supplier<class_1799> BATTERY_QUENCHED_BLOCK_STACK = addToTab(() -> ItemMediaBattery.withMedia(
            new class_1799(HexItems.BATTERY.get()),
            MediaConstants.QUENCHED_BLOCK_UNIT * 64,
            MediaConstants.QUENCHED_BLOCK_UNIT * 64), HexCreativeTabs.HEX_KEY);

    public static final EnumMap<class_1767, Supplier<ItemDyePigment>> DYE_PIGMENTS = class_156.method_656(() -> {
        var out = new EnumMap<class_1767, Supplier<ItemDyePigment>>(class_1767.class);
        for (var dye : class_1767.values()) {
            out.put(dye, make("dye_colorizer_" + dye.method_7792(), () -> new ItemDyePigment(dye, unstackable())));
        }
        return out;
    });
    public static final EnumMap<ItemPridePigment.Type, Supplier<ItemPridePigment>> PRIDE_PIGMENTS = class_156.method_656(() -> {
        var out = new EnumMap<ItemPridePigment.Type, Supplier<ItemPridePigment>>(ItemPridePigment.Type.class);
        for (var politicsInMyVidya : ItemPridePigment.Type.values()) {
            out.put(politicsInMyVidya, make("pride_colorizer_" + politicsInMyVidya.getName(), () ->
                    new ItemPridePigment(politicsInMyVidya, unstackable())));
        }
        return out;
    });

    public static final Supplier<class_1792> UUID_PIGMENT = make("uuid_colorizer", () -> new ItemUUIDPigment(unstackable()));
    public static final Supplier<class_1792> DEFAULT_PIGMENT = make("default_colorizer", () ->
        new ItemAmethystPigment(unstackable()));
    public static final Supplier<class_1792> ANCIENT_PIGMENT = make("ancient_colorizer", () ->
        new ItemAmethystAndCopperPigment(unstackable()));

    // BUFF SANDVICH
    public static final Supplier<class_1792> SUBMARINE_SANDWICH = make("sub_sandwich", () ->
            new class_1792(props().method_19265(new class_4174.class_4175().method_19238(14).method_19237(1.2f).method_19242())));

    public static final Supplier<ItemLoreFragment> LORE_FRAGMENT = make("lore_fragment", () ->
            new ItemLoreFragment(unstackable()
                    .method_7894(class_1814.field_8903)));

    public static final Supplier<ItemCreativeUnlocker> CREATIVE_UNLOCKER = make("creative_unlocker", () ->
            new ItemCreativeUnlocker(unstackable()
                    .method_7894(class_1814.field_8904)
                    .method_19265(new class_4174.class_4175().method_19238(20).method_19237(1f).method_19240().method_19242())));

    //

    public static class_1792.class_1793 props() {
        return new class_1792.class_1793();
    }

    public static class_1792.class_1793 unstackable() {
        return props().method_7889(1);
    }

    private static void generateScrollEntries(class_1761.class_7704 r) {
        var keyList = new ArrayList<class_5321<ActionRegistryEntry>>();
        class_2378<ActionRegistryEntry> regi = IXplatAbstractions.INSTANCE.getActionRegistry();
        for (var key : regi.method_42021())
            if (HexUtils.isOfTag(regi, key, HexTags.Actions.PER_WORLD_PATTERN))
                keyList.add(key);
        keyList.sort(Comparator.comparing(class_5321::method_29177));
        for (var key : keyList) {
            r.method_45420(ItemScroll.withPerWorldPattern(
                    new class_1799(HexItems.SCROLL_LARGE.get()),
                    key
            ));
        }
    }

    private static <T extends class_1792> Supplier<T> make(String id, Supplier<T> itemSupplier, @Nullable class_5321<class_1761> tabKey) {
        Supplier<T> supplier = REGISTER.register(id, itemSupplier);
        if (tabKey != null) {
            ITEM_TABS.computeIfAbsent(tabKey, t -> new ArrayList<>()).add(new TabEntry.ItemEntry(supplier::get));
        }
        return supplier;
    }

    private static <T extends class_1792> Supplier<T> make(String id, Supplier<T> itemSupplier) {
        return make(id, itemSupplier, HexCreativeTabs.HEX_KEY);
    }

    private static Supplier<class_1799> addToTab(Supplier<class_1799> stack, class_5321<class_1761> tabKey) {
        var memoised = Suppliers.memoize(stack::get);
        ITEM_TABS.computeIfAbsent(tabKey, t -> new ArrayList<>()).add(new TabEntry.StackEntry(memoised));
        return memoised;
    }

    private static abstract class TabEntry {
        abstract void register(class_1761.class_7704 r);

        static class ItemEntry extends TabEntry {
            private final Supplier<class_1792> item;

            ItemEntry(Supplier<class_1792> item) {
                this.item = item;
            }

            @Override
            void register(class_1761.class_7704 r) {
                r.method_45421(item.get());
            }
        }

        static class StackEntry extends TabEntry {
            private final Supplier<class_1799> stack;

            StackEntry(Supplier<class_1799> stack) {
                this.stack = stack;
            }

            @Override
            void register(class_1761.class_7704 r) {
                r.method_45420(stack.get());
            }
        }
    }
}
