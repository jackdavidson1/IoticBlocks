package at.petrak.hexcasting.common.lib;

import at.petrak.hexcasting.xplat.IXplatAbstractions;
import at.petrak.hexcasting.xplat.IXplatRegister;
import net.minecraft.class_1761;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_5321;
import net.minecraft.class_6880;
import net.minecraft.class_7923;
import net.minecraft.class_7924;

import static at.petrak.hexcasting.api.HexAPI.modLoc;

public class HexCreativeTabs {
    private static final IXplatRegister<class_1761> REGISTER = IXplatAbstractions.INSTANCE.createRegistar(class_7924.field_44688);

    public static void register() {
        REGISTER.registerAll();
    }

    public static final class_6880<class_1761> HEX = REGISTER.registerHolder("hexcasting", () ->
            class_1761.method_47307(class_1761.class_7915.field_41049, 0)
                    .method_47320(() -> new class_1799(HexItems.SPELLBOOK.get()))
                    .method_47321(class_2561.method_43471("itemGroup.hexcasting.hexcasting"))
                    .method_47324());

    public static final class_5321<class_1761> HEX_KEY = class_5321.method_29179(class_7923.field_44687.method_30517(), modLoc("hexcasting"));

    public static final class_6880<class_1761> SCROLLS = REGISTER.registerHolder("scrolls", () ->
            class_1761.method_47307(class_1761.class_7915.field_41049, 0)
                    .method_47320(() -> new class_1799(HexItems.SCROLL_LARGE.get()))
                    .method_47321(class_2561.method_43471("itemGroup.hexcasting.scrolls"))
                    .method_47324());

    public static final class_5321<class_1761> SCROLLS_KEY = class_5321.method_29179(class_7923.field_44687.method_30517(), modLoc("scrolls"));
}
