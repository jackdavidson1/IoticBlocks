package at.petrak.hexcasting.common.entities;

import at.petrak.hexcasting.api.HexAPI;
import at.petrak.hexcasting.xplat.IXplatAbstractions;
import at.petrak.hexcasting.xplat.IXplatRegister;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.function.BiConsumer;
import java.util.function.Supplier;
import net.minecraft.class_1299;
import net.minecraft.class_1311;
import net.minecraft.class_7924;

import static at.petrak.hexcasting.api.HexAPI.modLoc;

public class HexEntities {
    private static final IXplatRegister<class_1299<?>> REGISTER = IXplatAbstractions.INSTANCE.createRegistar(class_7924.field_41266);

    public static void register() {
        REGISTER.registerAll();
    }

    public static final Supplier<class_1299<EntityWallScroll>> WALL_SCROLL = REGISTER.register("wall_scroll", () ->
        class_1299.class_1300.<EntityWallScroll>method_5903(EntityWallScroll::new, class_1311.field_17715)
            .method_17687(0.5f, 0.5f).method_27299(10).method_27300(Integer.MAX_VALUE)
            .method_5905(HexAPI.MOD_ID + ":wall_scroll"));
}
