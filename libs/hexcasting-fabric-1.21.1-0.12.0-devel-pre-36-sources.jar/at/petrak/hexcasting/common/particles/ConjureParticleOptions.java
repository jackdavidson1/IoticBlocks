package at.petrak.hexcasting.common.particles;

import at.petrak.hexcasting.common.lib.HexParticles;
import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.class_2394;
import net.minecraft.class_2396;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public record ConjureParticleOptions(int color) implements class_2394 {
    @Override
    public class_2396<?> method_10295() {
        return HexParticles.CONJURE_PARTICLE.get();
    }

    public static class Type extends class_2396<ConjureParticleOptions> {
        public Type(boolean pOverrideLimiter) {
            super(pOverrideLimiter);
        }

        public static final MapCodec<ConjureParticleOptions> CODEC = RecordCodecBuilder.mapCodec(
            instance -> instance.group(
                    Codec.INT.fieldOf("color")
                        .forGetter((ConjureParticleOptions o) -> o.color)
                )
                .apply(instance, ConjureParticleOptions::new)
        );
        public static final class_9139<class_9129, ConjureParticleOptions> STREAM_CODEC =
                class_9139.method_56434(
                        class_9135.field_48550, ConjureParticleOptions::color,
                        ConjureParticleOptions::new
                );

        @Override
        public MapCodec<ConjureParticleOptions> method_29138() {
            return CODEC;
        }

        @Override
        public class_9139<? super class_9129, ConjureParticleOptions> method_56179() {
            return STREAM_CODEC;
        }
    }
}
