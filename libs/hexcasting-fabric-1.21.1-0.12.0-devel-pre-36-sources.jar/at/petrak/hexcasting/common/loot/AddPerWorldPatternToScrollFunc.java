package at.petrak.hexcasting.common.loot;

import at.petrak.hexcasting.api.HexAPI;
import at.petrak.hexcasting.api.casting.ActionRegistryEntry;
import at.petrak.hexcasting.api.mod.HexTags;
import at.petrak.hexcasting.api.utils.HexUtils;
import at.petrak.hexcasting.common.casting.PatternRegistryManifest;
import at.petrak.hexcasting.common.lib.HexDataComponents;
import at.petrak.hexcasting.common.lib.HexLootFunctions;
import at.petrak.hexcasting.xplat.IXplatAbstractions;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_120;
import net.minecraft.class_1799;
import net.minecraft.class_2378;
import net.minecraft.class_3218;
import net.minecraft.class_47;
import net.minecraft.class_5321;
import net.minecraft.class_5339;
import net.minecraft.class_5341;
import net.minecraft.class_5819;

/**
 * Slap a random per-world pattern on the scroll.
 * <p>
 * The function itself is only used on Fabric but the behavior {@link AddPerWorldPatternToScrollFunc#doStatic}
 * is used on both sides
 */
public class AddPerWorldPatternToScrollFunc extends class_120 {
    public static final MapCodec<AddPerWorldPatternToScrollFunc> CODEC = RecordCodecBuilder.mapCodec(
            p_344674_ -> method_53344(p_344674_)
                    .apply(p_344674_, AddPerWorldPatternToScrollFunc::new)
    );

    public AddPerWorldPatternToScrollFunc(List<class_5341> lootItemConditions) {
        super(lootItemConditions);
    }

    /**
     * This doesn't actually have any params so extract behaviour out for the benefit of forge
     */
    public static class_1799 doStatic(class_1799 stack, class_5819 rand, class_3218 overworld) {
        var perWorldKeys = new ArrayList<class_5321<ActionRegistryEntry>>();
        class_2378<ActionRegistryEntry> regi = IXplatAbstractions.INSTANCE.getActionRegistry();
        for (var key : regi.method_42021()) {
            if (HexUtils.isOfTag(regi, key, HexTags.Actions.PER_WORLD_PATTERN)) {
                perWorldKeys.add(key);
            }
        }
        var patternKey = perWorldKeys.get(rand.method_43048(perWorldKeys.size()));
        var patternID = patternKey.method_29177().toString();
        var pat = PatternRegistryManifest.getCanonicalStrokesPerWorld(patternKey, overworld);

        if (pat == null) {
            HexAPI.LOGGER.error("No per-world pattern found for action " + patternID + " while generating loot scroll! " +
                    "Try running '/hexcasting recalcPatterns' to generate the patterns for this world.");
            stack.method_57379(HexDataComponents.RECALC_WARNING.get(), patternKey);
            return stack;
        }

        stack.method_57379(HexDataComponents.ACTION.get(), patternKey);
        stack.method_57379(HexDataComponents.PATTERN.get(), pat);
        return stack;
    }

    @Override
    protected class_1799 method_522(class_1799 stack, class_47 ctx) {
        return doStatic(stack, ctx.method_294(), ctx.method_299().method_8503().method_30002());
    }

    @Override
    public class_5339<? extends class_120> method_29321() {
        return HexLootFunctions.PATTERN_SCROLL.get();
    }
}
