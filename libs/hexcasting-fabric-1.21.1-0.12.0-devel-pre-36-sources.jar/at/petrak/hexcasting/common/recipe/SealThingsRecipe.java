package at.petrak.hexcasting.common.recipe;

import at.petrak.hexcasting.api.mod.HexTags;
import at.petrak.hexcasting.common.items.storage.ItemFocus;
import at.petrak.hexcasting.common.items.storage.ItemSpellbook;
import at.petrak.hexcasting.common.lib.HexDataComponents;
import at.petrak.hexcasting.common.lib.HexItems;
import net.minecraft.class_1799;
import net.minecraft.class_1852;
import net.minecraft.class_1865;
import net.minecraft.class_1866;
import net.minecraft.class_1937;
import net.minecraft.class_3542;
import net.minecraft.class_7225;
import net.minecraft.class_7710;
import net.minecraft.class_9694;
import net.minecraft.world.item.crafting.*;
import org.jetbrains.annotations.NotNull;

import java.util.Locale;

public class SealThingsRecipe extends class_1852 {
    public final Sealee sealee;

    public static final class_1866<SealThingsRecipe> FOCUS_SERIALIZER =
        new class_1866<>(SealThingsRecipe::focus);
    public static final class_1866<SealThingsRecipe> SPELLBOOK_SERIALIZER =
        new class_1866<>(SealThingsRecipe::spellbook);

    public SealThingsRecipe(class_7710 category, Sealee sealee) {
        super(category);
        this.sealee = sealee;
    }


    @Override
    public boolean method_8113(int width, int height) {
        return width * height >= 2;
    }

    @Override
    public boolean matches(class_9694 container, class_1937 level) {
        boolean foundComb = false;
        boolean foundSealee = false;

        for (int i = 0; i < container.method_59983(); i++) {
            var stack = container.method_59984(i);
            if (this.sealee.isCorrectSealee(stack)) {
                if (foundSealee) return false;
                foundSealee = true;
            } else if (stack.method_31573(HexTags.Items.SEAL_MATERIALS)) {
                if (foundComb) return false;
                foundComb = true;
            }
        }

        return foundComb && foundSealee;
    }

    @Override
    public @NotNull class_1799 assemble(class_9694 inv, class_7225.class_7226.@NotNull class_7874 registryProvider) {
        class_1799 sealee = class_1799.field_8037;

        for (int i = 0; i < inv.method_59983(); i++) {
            var stack = inv.method_59984(i);
            if (this.sealee.isCorrectSealee(stack)) {
                sealee = stack.method_7972();
                break;
            }
        }

        if (!sealee.method_7960()) {
            this.sealee.seal(sealee);
            sealee.method_7939(1);
        }

        return sealee;
    }

    @Override
    public @NotNull class_1865<?> method_8119() {
        return switch (this.sealee) {
            case FOCUS -> FOCUS_SERIALIZER;
            case SPELLBOOK -> SPELLBOOK_SERIALIZER;
        };
    }

    public static SealThingsRecipe focus(class_7710 category) {
        return new SealThingsRecipe(category, Sealee.FOCUS);
    }

    public static SealThingsRecipe spellbook(class_7710 category) {
        return new SealThingsRecipe(category, Sealee.SPELLBOOK);
    }

    public enum Sealee implements class_3542 {
        FOCUS,
        SPELLBOOK;

        @Override
        public String method_15434() {
            return this.name().toLowerCase(Locale.ROOT);
        }

        public boolean isCorrectSealee(class_1799 stack) {
            return switch (this) {
                case FOCUS -> stack.method_31574(HexItems.FOCUS.get())
                    && stack.method_57826(HexDataComponents.IOTA_HOLDER_IOTA.get())
                    && !ItemFocus.isSealed(stack);
                case SPELLBOOK -> stack.method_31574(HexItems.SPELLBOOK.get())
                    && HexItems.SPELLBOOK.get().readIota(stack) != null
                    && !ItemSpellbook.isSealed(stack);
            };
        }

        public void seal(class_1799 stack) {
            switch (this) {
                case FOCUS -> {
                    ItemFocus.seal(stack);
                }
                case SPELLBOOK -> {
                    ItemSpellbook.setSealed(stack, true);
                }
            }
        }
    }
}

