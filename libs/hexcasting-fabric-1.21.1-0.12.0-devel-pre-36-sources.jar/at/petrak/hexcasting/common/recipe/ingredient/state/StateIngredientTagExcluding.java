package at.petrak.hexcasting.common.recipe.ingredient.state;

import at.petrak.hexcasting.common.lib.HexStateIngredients;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import org.jetbrains.annotations.NotNull;

import java.util.Collection;
import java.util.List;
import java.util.Random;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2248;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_6862;
import net.minecraft.class_7924;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public class StateIngredientTagExcluding extends StateIngredientTag {
    private final List<StateIngredient> excludes;

    public StateIngredientTagExcluding(class_6862<class_2248> tag, Collection<StateIngredient> excludes) {
        super(tag);
        this.excludes = List.copyOf(excludes);
    }

    @Override
    public StateIngredientType<?> getType() {
        return HexStateIngredients.TAG_EXCLUDING.get();
    }

    @Override
    public boolean test(class_2680 state) {
        if (!super.test(state)) {
            return false;
        }
        return isNotExcluded(state);
    }

    @Override
    public class_2680 pick(Random random) {
        List<class_2248> blocks = getBlocks();
        if (blocks.isEmpty()) {
            return null;
        }
        return blocks.get(random.nextInt(blocks.size())).method_9564();
    }

    private boolean isNotExcluded(class_2680 state) {
        for (StateIngredient exclude : excludes) {
            if (exclude.test(state)) {
                return false;
            }
        }
        return true;
    }

    @Override
    public boolean equals(Object o) {
        return super.equals(o) && this.excludes.equals(((StateIngredientTagExcluding) o).excludes);
    }

    @Override
    public int hashCode() {
        return super.hashCode();
    }

    @Override
    public List<class_1799> getDisplayedStacks() {
        return getBlocks().stream()
            .filter(b -> b.method_8389() != class_1802.field_8162)
            .map(class_1799::new)
            .toList();
    }

    @NotNull
    @Override
    protected List<class_2248> getBlocks() {
        return super.getBlocks().stream()
            .filter(b -> isNotExcluded(b.method_9564()))
            .toList();
    }

    @Override
    public List<class_2680> getDisplayed() {
        return super.getDisplayed().stream()
            .filter(this::isNotExcluded)
            .toList();
    }

    public List<StateIngredient> getExcludes() {
        return excludes;
    }

    public static class Type implements StateIngredientType<StateIngredientTagExcluding> {
        public static final MapCodec<StateIngredientTagExcluding> CODEC = RecordCodecBuilder.mapCodec(instance -> instance.group(
                class_6862.method_40093(class_7924.field_41254).fieldOf("tag").forGetter(StateIngredientTagExcluding::getTag),
                HexStateIngredients.TYPED_CODEC.listOf().fieldOf("excludes").forGetter(StateIngredientTagExcluding::getExcludes)
        ).apply(instance, StateIngredientTagExcluding::new));
        public static final class_9139<class_9129, StateIngredientTagExcluding> STREAM_CODEC = class_9139.method_56435(
                class_2960.field_48267.method_56432(id -> class_6862.method_40092(class_7924.field_41254, id), class_6862::comp_327), StateIngredientTagExcluding::getTag,
                HexStateIngredients.TYPED_STREAM_CODEC.method_56433(class_9135.method_56363()), StateIngredientTagExcluding::getExcludes,
                StateIngredientTagExcluding::new
        );

        @Override
        public MapCodec<StateIngredientTagExcluding> codec() {
            return CODEC;
        }

        @Override
        public class_9139<class_9129, StateIngredientTagExcluding> streamCodec() {
            return STREAM_CODEC;
        }
    }
}