package at.petrak.hexcasting.common.recipe.ingredient.brainsweep;

import at.petrak.hexcasting.common.lib.HexBrainsweepeeIngredients;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import net.minecraft.class_1074;
import net.minecraft.class_124;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1937;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_6862;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

public class EntityTagIngredient extends BrainsweepeeIngredient {
    public final class_6862<class_1299<?>> entityTypeTag;

    public EntityTagIngredient(class_6862<class_1299<?>> tag) {
        this.entityTypeTag = tag;
    }

    @Override
    public BrainsweepeeIngredientType<?> getType() {
        return HexBrainsweepeeIngredients.TAG.get();
    }

    public class_6862<class_1299<?>> getTag() {
        return entityTypeTag;
    }

    @Override
    public boolean test(class_1297 entity, class_3218 level) {
        return entity.method_5864().method_20210(this.entityTypeTag);
    }

    private static String tagKey(class_2960 tagLoc) {
        return "tag."
            + tagLoc.method_12836()
            + "."
            + tagLoc.method_12832().replace('/', '.');
    }

    @Override
    public class_2561 getName() {
        String key = tagKey(this.entityTypeTag.comp_327());
        boolean moddersDidAGoodJob = class_1074.method_4663(key);
        return moddersDidAGoodJob
            ? class_2561.method_43471(key)
            : class_2561.method_43470("#" + this.entityTypeTag.comp_327());
    }

    @Override
    public List<class_2561> getTooltip(boolean advanced) {
        class_2960 loc = this.entityTypeTag.comp_327();
        String key = tagKey(loc);
        boolean moddersDidAGoodJob = class_1074.method_4663(key);

        var out = new ArrayList<class_2561>();
        out.add(moddersDidAGoodJob
            ? class_2561.method_43471(key)
            : class_2561.method_43470("#" + loc));
        if (advanced && moddersDidAGoodJob) {
            // Print it anyways
            out.add(class_2561.method_43470("#" + loc).method_27692(class_124.field_1063));
        }

        out.add(BrainsweepeeIngredient.getModNameComponent(loc.method_12836()));

        return out;
    }

    @Override
    public String getSomeKindOfReasonableIDForEmi() {
        var resloc = this.entityTypeTag.comp_327();
        return resloc.method_12836()
                + "//"
                + resloc.method_12832();
    }

    public List<class_1297> exampleEntities(class_1937 level) {
        var someEntityTysHolder = class_7923.field_41177.method_40266(this.entityTypeTag);
        if (someEntityTysHolder.isEmpty()) return List.of();
        var someEntityTys = someEntityTysHolder.get();

        return someEntityTys.method_40239()
                .map(someTy -> getCachedExampleEntity(someTy.comp_349(), level))
                .toList();
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        EntityTagIngredient that = (EntityTagIngredient) o;
        return Objects.equals(entityTypeTag, that.entityTypeTag);
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(this.entityTypeTag);
    }


    public static class Type implements BrainsweepeeIngredientType<EntityTagIngredient> {
        public static final MapCodec<EntityTagIngredient> CODEC = RecordCodecBuilder.mapCodec(instance -> instance.group(
                class_6862.method_40093(class_7924.field_41266).fieldOf("tag").forGetter(EntityTagIngredient::getTag)
        ).apply(instance, EntityTagIngredient::new));
        public static final class_9139<class_9129, EntityTagIngredient> STREAM_CODEC = class_9139.method_56434(
                class_2960.field_48267.method_56432(id -> class_6862.method_40092(class_7924.field_41266, id), class_6862::comp_327), EntityTagIngredient::getTag,
                EntityTagIngredient::new
        );

        @Override
        public MapCodec<EntityTagIngredient> codec() {
            return CODEC;
        }

        @Override
        public class_9139<class_9129, EntityTagIngredient> streamCodec() {
            return STREAM_CODEC;
        }
    }
}
