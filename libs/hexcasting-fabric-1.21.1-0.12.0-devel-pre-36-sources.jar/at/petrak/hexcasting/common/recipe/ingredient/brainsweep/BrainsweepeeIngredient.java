package at.petrak.hexcasting.common.recipe.ingredient.brainsweep;

import at.petrak.hexcasting.xplat.IXplatAbstractions;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
import net.minecraft.class_124;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1937;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import org.jetbrains.annotations.Nullable;

// Partially based on:
// https://github.com/SlimeKnights/Mantle/blob/1.18.2/src/main/java/slimeknights/mantle/recipe/ingredient/EntityIngredient.java
// Licensed under MIT
//
// .equals must make sense
public abstract class BrainsweepeeIngredient {

    public abstract BrainsweepeeIngredientType<?> getType();

    public abstract boolean test(class_1297 entity, class_3218 level);

    public abstract class_2561 getName();

    public abstract List<class_2561> getTooltip(boolean advanced);

    public abstract String getSomeKindOfReasonableIDForEmi();

    /**
     * For the benefit of showing to the client, return a list of example entities.
     * <p>
     * Can return empty list in case someone did something stupid with a recipe
     */
    public abstract List<class_1297> exampleEntities(class_1937 level);

    public static class_2561 getModNameComponent(String namespace) {
        String mod = IXplatAbstractions.INSTANCE.getModName(namespace);
        return class_2561.method_43470(mod).method_27695(class_124.field_1078, class_124.field_1056);
    }

    private static Map<class_1299<?>, class_1297> cachedExampleEntity = new HashMap<>();
    protected static class_1297 getCachedExampleEntity(class_1299<?> type, class_1937 level) {
        // don't cache for server levels (if any) to prevent wrong side
        if (!level.field_9236) {
            return type.method_5883(level);
        }
        return cachedExampleEntity.computeIfAbsent(type, t -> t.method_5883(level));
    }
}
