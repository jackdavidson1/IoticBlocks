package at.petrak.hexcasting.common.recipe;

import at.petrak.hexcasting.api.HexAPI;
import at.petrak.hexcasting.xplat.IXplatAbstractions;
import at.petrak.hexcasting.xplat.IXplatRegister;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.function.BiConsumer;
import java.util.function.Supplier;
import net.minecraft.class_1865;
import net.minecraft.class_3956;
import net.minecraft.class_7924;

import static at.petrak.hexcasting.api.HexAPI.modLoc;

public class HexRecipeStuffRegistry {
    private static final IXplatRegister<class_1865<?>> REGISTER_SERIALIZER = IXplatAbstractions.INSTANCE.createRegistar(class_7924.field_41216);
    private static final IXplatRegister<class_3956<?>> REGISTER_RECIPE_TYPE = IXplatAbstractions.INSTANCE.createRegistar(class_7924.field_41217);

    public static void register() {
        REGISTER_SERIALIZER.registerAll();
        REGISTER_RECIPE_TYPE.registerAll();
    }

    public static final Supplier<class_1865<?>> BRAINSWEEP = REGISTER_SERIALIZER.register("brainsweep", BrainsweepRecipe.Serializer::new);
    public static final Supplier<class_1865<SealThingsRecipe>> SEAL_FOCUS = REGISTER_SERIALIZER.register(
        "seal_focus", () -> SealThingsRecipe.FOCUS_SERIALIZER);
    public static final Supplier<class_1865<SealThingsRecipe>> SEAL_SPELLBOOK = REGISTER_SERIALIZER.register(
        "seal_spellbook", () -> SealThingsRecipe.SPELLBOOK_SERIALIZER);

    public static Supplier<class_3956<BrainsweepRecipe>> BRAINSWEEP_TYPE = REGISTER_RECIPE_TYPE.register("brainsweep", () ->
            new class_3956<BrainsweepRecipe>() {
                @Override
                public String toString() {
                    return HexAPI.MOD_ID + ":" + "brainsweep";
                }
            });
}
