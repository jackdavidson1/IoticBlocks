package at.petrak.hexcasting.common.recipe;

import at.petrak.hexcasting.common.items.storage.ItemSpellbook;
import at.petrak.hexcasting.common.lib.HexDataComponents;
import at.petrak.hexcasting.common.lib.HexItems;
import at.petrak.hexcasting.xplat.IXplatAbstractions;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1856;
import net.minecraft.class_1865;
import net.minecraft.class_1866;
import net.minecraft.class_1867;
import net.minecraft.class_2371;
import net.minecraft.class_7225;
import net.minecraft.class_7710;
import net.minecraft.class_9694;
import net.minecraft.world.item.crafting.*;
import org.jetbrains.annotations.NotNull;

import java.util.Optional;

public class SealSpellbookRecipe extends class_1867 {
    public static final class_1866<SealSpellbookRecipe> SERIALIZER =
        new class_1866<>(SealSpellbookRecipe::new);

    private static class_1799 getSealedStack() {
        class_1799 output = new class_1799(HexItems.SPELLBOOK.get());
        ItemSpellbook.setSealed(output, true);
        output.method_57379(HexDataComponents.VISUAL_OVERRIDE.get(), Optional.empty());
        return output;
    }

    private static class_2371<class_1856> createIngredients() {
        class_2371<class_1856> ingredients = class_2371.method_37434(2);
        ingredients.add(IXplatAbstractions.INSTANCE.getUnsealedIngredient(new class_1799(HexItems.SPELLBOOK.get())));
        ingredients.add(class_1856.method_8091(class_1802.field_20414));
        return ingredients;
    }

    public SealSpellbookRecipe(class_7710 category) {
        super("", category, getSealedStack(), createIngredients());
    }

    @Override
    public @NotNull class_1799 method_17729(class_9694 inv, class_7225.class_7226.@NotNull class_7874 registryProvider) {
        class_1799 out = class_1799.field_8037;

        for (int i = 0; i < inv.method_59983(); i++) {
            var stack = inv.method_59984(i);
            if (stack.method_31574(HexItems.SPELLBOOK.get())) {
                out = stack.method_7972();
                break;
            }
        }

        if (!out.method_7960()) {
            ItemSpellbook.setSealed(out, true);
            out.method_7939(1);
        }

        return out;
    }

    @Override
    public @NotNull class_1865<?> method_8119() {
        return SERIALIZER;
    }
}

