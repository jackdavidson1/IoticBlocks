package at.petrak.hexcasting.api.advancements;

import at.petrak.hexcasting.xplat.IXplatAbstractions;
import at.petrak.hexcasting.xplat.IXplatRegister;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.function.BiConsumer;
import java.util.function.Supplier;
import net.minecraft.class_179;
import net.minecraft.class_7924;

import static at.petrak.hexcasting.api.HexAPI.modLoc;

public class HexAdvancementTriggers {
    private static final IXplatRegister<class_179<?>> REGISTER = IXplatAbstractions.INSTANCE.createRegistar(class_7924.field_47498);

    public static void register() {
        REGISTER.registerAll();
    }

    public static final Supplier<OvercastTrigger> OVERCAST_TRIGGER = REGISTER.register("overcast", OvercastTrigger::new);
    public static final Supplier<SpendMediaTrigger> SPEND_MEDIA_TRIGGER = REGISTER.register("spend_media", SpendMediaTrigger::new);
    public static final Supplier<FailToCastGreatSpellTrigger> FAIL_GREAT_SPELL_TRIGGER = REGISTER.register("fail_to_cast_great_spell", FailToCastGreatSpellTrigger::new);
}
