package at.petrak.hexcasting.api.addldata;

import at.petrak.hexcasting.api.casting.iota.Iota;
import at.petrak.hexcasting.common.entities.EntityWallScroll;
import at.petrak.hexcasting.xplat.IXplatAbstractions;
import org.jetbrains.annotations.Nullable;

import java.util.function.Consumer;
import java.util.function.Supplier;
import net.minecraft.class_1533;
import net.minecraft.class_1542;
import net.minecraft.class_1799;

public abstract class ItemDelegatingEntityIotaHolder implements ADIotaHolder {
    private final Supplier<class_1799> stackSupplier;

    private final Consumer<class_1799> save;

    public ItemDelegatingEntityIotaHolder(Supplier<class_1799> stackSupplier, Consumer<class_1799> save) {
        this.stackSupplier = stackSupplier;
        this.save = save;
    }

    @Override
    public boolean writeable() {
        var delegate = IXplatAbstractions.INSTANCE.findDataHolder(this.stackSupplier.get());
        return delegate != null && delegate.writeable();
    }

    @Override
    public boolean writeIota(@Nullable Iota datum, boolean simulate) {
        var stacc = this.stackSupplier.get();
        var delegate = IXplatAbstractions.INSTANCE.findDataHolder(stacc);
        var success = delegate != null && delegate.writeIota(datum, simulate);
        if (success && !simulate) {
            this.save.accept(stacc);
        }
        return success;
    }

    @Override
    public @Nullable Iota readIota() {
        var delegate = IXplatAbstractions.INSTANCE.findDataHolder(this.stackSupplier.get());
        return delegate == null ? null : delegate.readIota();
    }

    @Override
    public @Nullable Iota emptyIota() {
        var delegate = IXplatAbstractions.INSTANCE.findDataHolder(this.stackSupplier.get());
        return delegate == null ? null : delegate.emptyIota();
    }

    public static class ToItemEntity extends ItemDelegatingEntityIotaHolder {
        public ToItemEntity(class_1542 entity) {
            super(entity::method_6983, stack -> {
                // https://github.com/VazkiiMods/Botania/blob/e6d095ff5010074b45408d6cce8ee1e328af3383/Xplat/src/main/java/vazkii/botania/common/helper/EntityHelper.java#L16
                entity.method_6979(class_1799.field_8037);
                entity.method_6979(stack);
                entity.method_35190();
            });
        }
    }

    public static class ToItemFrame extends ItemDelegatingEntityIotaHolder {
        public ToItemFrame(class_1533 entity) {
            super(entity::method_6940, entity::method_6935);
        }
    }

    public static class ToWallScroll extends ItemDelegatingEntityIotaHolder {
        public ToWallScroll(EntityWallScroll entity) {
            super(() -> entity.scroll.method_7972(), stack -> {
            });
        }

        @Override
        public boolean writeIota(@Nullable Iota datum, boolean simulate) {
            return false;
        }

        @Override
        public boolean writeable() {
            return false;
        }
    }
}
