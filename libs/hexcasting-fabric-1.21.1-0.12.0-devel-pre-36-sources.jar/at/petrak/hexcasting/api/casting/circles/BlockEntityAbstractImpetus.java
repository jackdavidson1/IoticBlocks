package at.petrak.hexcasting.api.casting.circles;

import at.petrak.hexcasting.api.block.HexBlockEntity;
import at.petrak.hexcasting.api.block.circle.BlockCircleComponent;
import at.petrak.hexcasting.api.misc.MediaConstants;
import at.petrak.hexcasting.api.pigment.FrozenPigment;
import at.petrak.hexcasting.api.utils.MediaHelper;
import at.petrak.hexcasting.common.items.magic.ItemCreativeUnlocker;
import at.petrak.hexcasting.common.lib.HexItems;
import com.mojang.datafixers.util.Pair;
import org.jetbrains.annotations.Contract;
import org.jetbrains.annotations.Nullable;

import java.text.DecimalFormat;
import java.util.List;
import net.minecraft.class_124;
import net.minecraft.class_1278;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2487;
import net.minecraft.class_2509;
import net.minecraft.class_2520;
import net.minecraft.class_2561;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3481;
import net.minecraft.class_3532;
import net.minecraft.class_7225;

/**
 * Default impl for an impetus, not tecnically necessary but I'm exposing it for ease of use
 * <p>
 * This does assume a great deal so you might have to re-implement a lot of this yourself if you
 * wanna do something wild and new
 */
public abstract class BlockEntityAbstractImpetus extends HexBlockEntity implements class_1278 {
    private static final DecimalFormat DUST_AMOUNT = new DecimalFormat("###,###.##");
    private static final long MAX_CAPACITY = 9_000_000_000_000_000_000L;

    public static final String
        TAG_EXECUTION_STATE = "executor",
        TAG_MEDIA = "media",
        TAG_ERROR_MSG = "errorMsg",
        TAG_ERROR_DISPLAY = "errorDisplay",
        TAG_PIGMENT = "pigment";

    // We might try to load the executor in loadModData when the level doesn't exist yet,
    // so save the tag and load it lazy
    @Nullable class_2487 lazyExecutionState;
    @Nullable
    protected CircleExecutionState executionState;

    protected long media = 0;

    // these are null together
    @Nullable
    protected class_2561 displayMsg = null;
    @Nullable
    protected class_1799 displayItem = null;
    @Nullable
    protected FrozenPigment pigment = null;


    public BlockEntityAbstractImpetus(class_2591<?> pType, class_2338 pWorldPosition, class_2680 pBlockState) {
        super(pType, pWorldPosition, pBlockState);
    }

    public class_2350 getStartDirection() {
        return this.method_11010().method_11654(class_2741.field_12525);
    }

    @Nullable
    public class_2561 getDisplayMsg() {
        return displayMsg;
    }

    public void clearDisplay() {
        this.displayMsg = null;
        this.displayItem = null;
        this.sync();
    }

    public void postDisplay(class_2561 error, class_1799 display) {
        this.displayMsg = error;
        this.displayItem = display;
        this.sync();
    }

    public void postMishap(class_2561 mishapDisplay) {
        this.postDisplay(mishapDisplay, new class_1799(class_1802.field_8731));
    }

    public void postPrint(class_2561 printDisplay) {
        this.postDisplay(printDisplay, new class_1799(class_1802.field_8529));
    }

    // Pull this out because we may need to call it both on startup and halfway thru
    public void postNoExits(class_2338 pos) {
        this.postDisplay(
            class_2561.method_43469("hexcasting.tooltip.circle.no_exit",
                class_2561.method_43470(pos.method_23854()).method_27692(class_124.field_1061)),
            new class_1799(class_1802.field_8788));
    }

    //region execution

    public void tickExecution() {
        if (this.field_11863 == null)
            return;

        this.method_5431();

        var state = this.getExecutionState();
        if (state == null) {
            return;
        }

        var shouldContinue = state.tick(this);

        if (!shouldContinue) {
            this.endExecution();
            this.executionState = null;
        } else
            this.field_11863.method_39279(this.method_11016(), this.method_11010().method_26204(), state.getTickSpeed());
    }

    public void endExecution() {
        if (this.executionState == null)
            return;

        this.executionState.endExecution(this);
    }

    /**
     * ONLY CALL THIS WHEN YOU KNOW THE WORLD EXISTS AND ON THE SERVER, lazy-loads it
     */
    public @Nullable CircleExecutionState getExecutionState() {
        if (this.field_11863 == null) {
            throw new IllegalStateException("didn't you read the doc comment, don't call this if the level is null");
        }

        if (this.executionState != null)
            return this.executionState;

        if (this.lazyExecutionState != null)
            this.executionState = CircleExecutionState.load(this.lazyExecutionState, (class_3218) this.field_11863);

        return this.executionState;
    }

    public void startExecution(@Nullable class_3222 player) {
        if (this.field_11863 == null)
            return; // TODO: error here?
        if (this.field_11863.field_9236)
            return; // TODO: error here?

        if (this.executionState != null) {
            return;
        }
        var result = CircleExecutionState.createNew(this, player);
        if (result.isErr()) {
            var errPos = result.unwrapErr();
            if (errPos == null) {
                ICircleComponent.sfx(this.method_11016(), this.method_11010(), this.field_11863, null, false);
                this.postNoExits(this.method_11016());
            } else {
                ICircleComponent.sfx(errPos, this.field_11863.method_8320(errPos), this.field_11863, null, false);
                this.postDisplay(class_2561.method_43469("hexcasting.tooltip.circle.no_closure",
                        class_2561.method_43470(errPos.method_23854()).method_27692(class_124.field_1061)),
                    new class_1799(class_1802.field_8719));
            }

            return;
        }
        this.executionState = result.unwrap();

        this.clearDisplay();
        var serverLevel = (class_3218) this.field_11863;
        serverLevel.method_39279(this.method_11016(), this.method_11010().method_26204(),
            this.executionState.getTickSpeed());
        serverLevel.method_8501(this.method_11016(),
            this.method_11010().method_11657(BlockCircleComponent.ENERGIZED, true));
        ICircleComponent.sfx(this.method_11016(), this.method_11010(), this.field_11863, this, true);
    }

    //endregion

    //region media handling

    public long getMedia() {
        return this.media;
    }

    public void setMedia(long media) {
        this.media = media;
        sync();
    }

    public long extractMediaFromInsertedItem(class_1799 stack, boolean simulate) {
        if (this.media < 0) {
            return 0;
        }
        return MediaHelper.extractMedia(stack, remainingMediaCapacity(), true, simulate);
    }

    public void insertMedia(class_1799 stack) {
        if (getMedia() >= 0 && !stack.method_7960() && stack.method_7909() == HexItems.CREATIVE_UNLOCKER.get()) {
            setInfiniteMedia();
            stack.method_7934(1);
        } else {
            var mediamount = extractMediaFromInsertedItem(stack, false);
            if (mediamount > 0) {
                this.media = Math.min(mediamount + media, MAX_CAPACITY);
                this.sync();
            }
        }
    }

    public void setInfiniteMedia() {
        this.media = -1;
        this.sync();
    }

    public long remainingMediaCapacity() {
        if (this.media < 0) {
            return 0;
        }
        return Math.max(0, MAX_CAPACITY - this.media);
    }

    //endregion


    public FrozenPigment getPigment() {
        if (pigment != null)
            return pigment;
        if (executionState != null && executionState.casterPigment != null)
            return executionState.casterPigment;
        return FrozenPigment.DEFAULT.get();
    }

    public @Nullable FrozenPigment setPigment(@Nullable FrozenPigment pigment) {
        this.pigment = pigment;
        return this.pigment;
    }

    @Override
    protected void saveModData(class_2487 tag, class_7225.class_7874 registries) {
        if (this.executionState != null) {
            tag.method_10566(TAG_EXECUTION_STATE, this.executionState.save());
        }

        tag.method_10544(TAG_MEDIA, this.media);

        if (this.displayMsg != null && this.displayItem != null) {
            tag.method_10582(TAG_ERROR_MSG, class_2561.class_2562.method_10867(this.displayMsg, registries));
            tag.method_10566(TAG_ERROR_DISPLAY, this.displayItem.method_57376(registries, new class_2487()));
        }
        if (this.pigment != null)
            tag.method_10566(TAG_PIGMENT, FrozenPigment.CODEC.encodeStart(class_2509.field_11560, pigment).getOrThrow());
    }

    @Override
    protected void loadModData(class_2487 tag, class_7225.class_7874 registries) {
        this.executionState = null;
        if (tag.method_10573(TAG_EXECUTION_STATE, class_2520.field_33260)) {
            this.lazyExecutionState = tag.method_10562(TAG_EXECUTION_STATE);
        } else {
            this.lazyExecutionState = null;
        }

        if (tag.method_10573(TAG_MEDIA, class_2520.field_33254)) {
            this.media = tag.method_10537(TAG_MEDIA);
        }

        if (tag.method_10573(TAG_ERROR_MSG, class_2520.field_33258) && tag.method_10573(TAG_ERROR_DISPLAY, class_2520.field_33260)) {
            var msg = class_2561.class_2562.method_10877(tag.method_10558(TAG_ERROR_MSG), registries);
            var display = class_1799.method_57359(registries, tag.method_10562(TAG_ERROR_DISPLAY));
            this.displayMsg = msg;
            this.displayItem = display;
        } else {
            this.displayMsg = null;
            this.displayItem = null;
        }
        if (tag.method_10573(TAG_PIGMENT, class_2520.field_33260))
            this.pigment = FrozenPigment.CODEC.parse(class_2509.field_11560, tag.method_10562(TAG_PIGMENT)).getOrThrow();
    }

    public void applyScryingLensOverlay(List<Pair<class_1799, class_2561>> lines,
        class_2680 state, class_2338 pos, class_1657 observer, class_1937 world, class_2350 hitFace) {
        if (world.method_8321(pos) instanceof BlockEntityAbstractImpetus beai) {
            if (beai.getMedia() < 0) {
                lines.add(new Pair<>(new class_1799(HexItems.AMETHYST_DUST.get()), ItemCreativeUnlocker.infiniteMedia(world)));
            } else {
                var dustCount = (float) beai.getMedia() / (float) MediaConstants.DUST_UNIT;
                var dustCmp = class_2561.method_43469("hexcasting.tooltip.media",
                    DUST_AMOUNT.format(dustCount));
                lines.add(new Pair<>(new class_1799(HexItems.AMETHYST_DUST.get()), dustCmp));
            }

            if (this.displayMsg != null && this.displayItem != null) {
                lines.add(new Pair<>(this.displayItem, this.displayMsg));
            }
        }
    }

    //region music

    protected int semitoneFromScale(int note) {
        var blockBelow = this.field_11863.method_8320(this.method_11016().method_10074());
        var scale = MAJOR_SCALE;
        if (blockBelow.method_27852(class_2246.field_22423)) {
            scale = MINOR_SCALE;
        } else if (blockBelow.method_26164(class_3481.field_15495) || blockBelow.method_26164(class_3481.field_15487)) {
            scale = DORIAN_SCALE;
        } else if (blockBelow.method_27852(class_2246.field_10560) || blockBelow.method_27852(class_2246.field_10615)) {
            scale = MIXOLYDIAN_SCALE;
        } else if (blockBelow.method_27852(class_2246.field_10514)
            || blockBelow.method_27852(class_2246.field_10011) || blockBelow.method_27852(class_2246.field_10456)
            || blockBelow.method_27852(class_2246.field_10409) || blockBelow.method_27852(class_2246.field_10550)
            || blockBelow.method_27852(class_2246.field_10060) || blockBelow.method_27852(class_2246.field_9982)) {
            scale = BLUES_SCALE;
        } else if (blockBelow.method_27852(class_2246.field_10166)) {
            scale = BAD_TIME;
        } else if (blockBelow.method_27852(class_2246.field_17563)) {
            scale = SUSSY_BAKA;
        }

        note = class_3532.method_15340(note, 0, scale.length - 1);
        return scale[note];
    }

    // this is a good use of my time
    private static final int[] MAJOR_SCALE = {0, 2, 4, 5, 7, 9, 11, 12};
    private static final int[] MINOR_SCALE = {0, 2, 3, 5, 7, 8, 10, 12};
    private static final int[] DORIAN_SCALE = {0, 2, 3, 5, 7, 9, 10, 12};
    private static final int[] MIXOLYDIAN_SCALE = {0, 2, 4, 5, 7, 9, 10, 12};
    private static final int[] BLUES_SCALE = {0, 3, 5, 6, 7, 10, 12};
    private static final int[] BAD_TIME = {0, 0, 12, 7, 6, 5, 3, 0, 3, 5};
    private static final int[] SUSSY_BAKA = {5, 8, 10, 11, 10, 8, 5, 3, 7, 5};

    //endregion

    //region item handler contract stuff
    private static final int[] SLOTS = {0};

    @Override
    public int[] method_5494(class_2350 var1) {
        return SLOTS;
    }

    @Override
    public boolean method_5492(int index, class_1799 stack, @Nullable class_2350 dir) {
        return this.method_5437(index, stack);
    }

    @Override
    public boolean method_5493(int var1, class_1799 var2, class_2350 var3) {
        return false;
    }

    @Override
    public int method_5439() {
        return 1;
    }

    @Override
    public boolean method_5442() {
        return true;
    }

    @Override
    public class_1799 method_5438(int index) {
        return class_1799.field_8037.method_7972();
    }

    @Override
    public class_1799 method_5434(int index, int count) {
        return class_1799.field_8037.method_7972();
    }

    @Override
    public class_1799 method_5441(int index) {
        return class_1799.field_8037.method_7972();
    }

    @Override
    public void method_5447(int index, class_1799 stack) {
        insertMedia(stack);
    }

    @Override
    public boolean method_5443(class_1657 player) {
        return false;
    }

    @Override
    public void method_5448() {
        // NO-OP
    }

    @Override
    public boolean method_5437(int index, class_1799 stack) {
        if (remainingMediaCapacity() == 0) {
            return false;
        }

        if (stack.method_31574(HexItems.CREATIVE_UNLOCKER.get())) {
            return true;
        }

        var mediamount = extractMediaFromInsertedItem(stack, true);
        return mediamount > 0;
    }

    //endregion
}
