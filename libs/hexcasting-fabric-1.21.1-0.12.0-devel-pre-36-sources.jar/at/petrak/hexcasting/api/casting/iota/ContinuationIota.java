package at.petrak.hexcasting.api.casting.iota;

import at.petrak.hexcasting.api.casting.eval.CastResult;
import at.petrak.hexcasting.api.casting.eval.ResolvedPatternType;
import at.petrak.hexcasting.api.casting.eval.vm.CastingVM;
import at.petrak.hexcasting.api.casting.eval.vm.SpellContinuation;
import at.petrak.hexcasting.common.lib.hex.HexEvalSounds;
import at.petrak.hexcasting.common.lib.hex.HexIotaTypes;
import com.mojang.serialization.MapCodec;
import org.jetbrains.annotations.NotNull;

import java.util.List;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

/**
 * An iota storing a continuation (in essence an execution state).
 */
public class ContinuationIota extends Iota {
    public static final class_2561 DISPLAY = class_2561.method_43471("hexcasting.tooltip.jump_iota").method_27692(class_124.field_1061);
    private SpellContinuation value;

    public ContinuationIota(SpellContinuation cont) {
        super(() -> HexIotaTypes.CONTINUATION.get());
        this.value = cont;
    }

    public SpellContinuation getContinuation() {
        return value;
    }

    @Override
    public boolean isTruthy() {
        return true;
    }

    @Override
    public boolean toleratesOther(Iota that) {
        return typesMatch(this, that) && that instanceof ContinuationIota cont && cont.getContinuation().equals(getContinuation());
    }

    @Override
    public @NotNull CastResult execute(CastingVM vm, class_3218 world, SpellContinuation continuation) {
        return new CastResult(this, this.getContinuation(), vm.getImage(), List.of(), ResolvedPatternType.EVALUATED, HexEvalSounds.HERMES.get());
    }

    @Override
    public boolean executable() {
        return true;
    }

    @Override
    public int size() {
        var continuation = this.getContinuation();
        var size = 0;
        while (continuation instanceof SpellContinuation.NotDone notDone) {
            size += 1;
            size += notDone.component1().size();
            continuation = notDone.component2();
        }

        return Math.min(size, 1);
    }

    @Override
    public int hashCode() {
        return value.hashCode();
    }

    @Override
    public class_2561 display() {
        return DISPLAY;
    }

    public static IotaType<ContinuationIota> TYPE = new IotaType<>() {
        public static final MapCodec<ContinuationIota> CODEC = SpellContinuation.getCODEC()
                .xmap(ContinuationIota::new, ContinuationIota::getContinuation)
                .fieldOf("value");
        public static final class_9139<class_9129, ContinuationIota> STREAM_CODEC =
                SpellContinuation.getSTREAM_CODEC().method_56432(ContinuationIota::new, ContinuationIota::getContinuation);

        @Override
        public MapCodec<ContinuationIota> codec() {
            return CODEC;
        }

        @Override
        public class_9139<class_9129, ContinuationIota> streamCodec() {
            return STREAM_CODEC;
        }

        @Override
        public int color() {
            return 0xff_cc0000;
        }
    };
}
