package at.petrak.hexcasting.api.mod;

import at.petrak.hexcasting.api.casting.ActionRegistryEntry;
import at.petrak.hexcasting.xplat.IXplatAbstractions;
import net.minecraft.class_1299;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2960;
import net.minecraft.class_6862;
import net.minecraft.class_7924;

import static at.petrak.hexcasting.api.HexAPI.modLoc;

public class HexTags {
    public static final class Items {
        public static final class_6862<class_1792> EDIFIED_LOGS = create("edified_logs");
        public static final class_6862<class_1792> EDIFIED_PLANKS = create("edified_planks");
        public static final class_6862<class_1792> STAVES = create("staves");
        public static final class_6862<class_1792> PHIAL_BASE = create("phial_base");
        public static final class_6862<class_1792> GRANTS_ROOT_ADVANCEMENT = create("grants_root_advancement");
        public static final class_6862<class_1792> SEAL_MATERIALS = create("seal_materials");

        public static final class_6862<class_1792> IMPETI = create("impeti");
        public static final class_6862<class_1792> DIRECTRICES = create("directrices");
        public static final class_6862<class_1792> MINDFLAYED_CIRCLE_COMPONENTS = create("brainswept_circle_components");

        public static final class_6862<class_1792> SLATE_BLOCKS = create("slate_blocks");
        public static final class_6862<class_1792> AMETHYST_BLOCKS = create("amethyst_blocks");
        public static final class_6862<class_1792> QUENCHED_ALLAY_BLOCKS = create("quenched_allay_blocks");

        public static class_6862<class_1792> create(String name) {
            return create(modLoc(name));
        }

        public static class_6862<class_1792> create(class_2960 id) {
            return class_6862.method_40092(class_7924.field_41197, id);
        }
    }

    public static final class Blocks {
        public static final class_6862<class_2248> EDIFIED_LOGS = create("edified_logs");
        public static final class_6862<class_2248> EDIFIED_PLANKS = create("edified_planks");

        public static final class_6862<class_2248> IMPETI = create("impeti");
        public static final class_6862<class_2248> DIRECTRICES = create("directrices");
        public static final class_6862<class_2248> MINDFLAYED_CIRCLE_COMPONENTS = create("brainswept_circle_components");

        public static final class_6862<class_2248> SLATE_BLOCKS = create("slate_blocks");
        public static final class_6862<class_2248> AMETHYST_BLOCKS = create("amethyst_blocks");
        public static final class_6862<class_2248> QUENCHED_ALLAY_BLOCKS = create("quenched_allay_blocks");

        // Used to determine what blocks should be replaced with air by OpDestroyFluid
        public static final class_6862<class_2248> WATER_PLANTS = create("water_plants");

        public static final class_6862<class_2248> CHEAP_TO_BREAK_BLOCK = create("cheap_to_break_block");

        //blocks unbreakable by Break Block, regardless of tier
        public static final class_6862<class_2248> HEX_UNBREAKABLE = create("hex_unbreakable");

        public static class_6862<class_2248> create(String name) {
            return class_6862.method_40092(class_7924.field_41254, modLoc(name));
        }
    }

    public static final class Entities {
        public static final class_6862<class_1299<?>> STICKY_TELEPORTERS = create("sticky_teleporters");
        public static final class_6862<class_1299<?>> CANNOT_TELEPORT = create("cannot_teleport");

        public static final class_6862<class_1299<?>> NO_BRAINSWEEPING = create("cannot_brainsweep");

        public static class_6862<class_1299<?>> create(String name) {
            return class_6862.method_40092(class_7924.field_41266, modLoc(name));
        }
    }

    public static final class Actions {
        /**
         * Actions with this tag can't be used until the caster is enlightened and send the
         * "am I not skilled enough" message
         */
        public static final class_6862<ActionRegistryEntry> REQUIRES_ENLIGHTENMENT = create("requires_enlightenment");
        /**
         * Actions where the pattern is calculated per-world
         */
        public static final class_6862<ActionRegistryEntry> PER_WORLD_PATTERN = create("per_world_pattern");

        /**
         * Actions that can cause Blind Diversion
         */
        public static final class_6862<ActionRegistryEntry> CAN_START_ENLIGHTEN = create("can_start_enlighten");

        /**
         * Actions that should not be affected by the media_consumption attribute
         */
        public static final class_6862<ActionRegistryEntry> CANNOT_MODIFY_COST = create("cannot_modify_cost");

        public static class_6862<ActionRegistryEntry> create(String name) {
            return class_6862.method_40092(IXplatAbstractions.INSTANCE.getActionRegistry().method_30517(), modLoc(name));
        }
    }
}
