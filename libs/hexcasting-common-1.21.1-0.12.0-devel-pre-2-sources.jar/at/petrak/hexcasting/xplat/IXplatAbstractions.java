package at.petrak.hexcasting.xplat;

import at.petrak.hexcasting.api.HexAPI;
import at.petrak.hexcasting.api.addldata.ADHexHolder;
import at.petrak.hexcasting.api.addldata.ADIotaHolder;
import at.petrak.hexcasting.api.addldata.ADMediaHolder;
import at.petrak.hexcasting.api.addldata.ADVariantItem;
import at.petrak.hexcasting.api.casting.ActionRegistryEntry;
import at.petrak.hexcasting.api.casting.arithmetic.Arithmetic;
import at.petrak.hexcasting.api.casting.castables.SpecialHandler;
import at.petrak.hexcasting.api.casting.eval.ResolvedPattern;
import at.petrak.hexcasting.api.casting.eval.sideeffects.EvalSound;
import at.petrak.hexcasting.api.casting.eval.vm.CastingImage;
import at.petrak.hexcasting.api.casting.eval.vm.CastingVM;
import at.petrak.hexcasting.api.casting.eval.vm.ContinuationFrame;
import at.petrak.hexcasting.api.casting.iota.IotaType;
import at.petrak.hexcasting.api.pigment.ColorProvider;
import at.petrak.hexcasting.api.pigment.FrozenPigment;
import at.petrak.hexcasting.api.player.AltioraAbility;
import at.petrak.hexcasting.api.player.FlightAbility;
import at.petrak.hexcasting.api.player.Sentinel;
import at.petrak.hexcasting.common.recipe.ingredient.brainsweep.BrainsweepeeIngredientType;
import at.petrak.hexcasting.common.recipe.ingredient.state.StateIngredientType;
import at.petrak.hexcasting.interop.pehkui.PehkuiInterop;
import com.mojang.authlib.GameProfile;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.ServiceLoader;
import java.util.UUID;
import java.util.function.BiFunction;
import java.util.stream.Collectors;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1304;
import net.minecraft.class_1308;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1832;
import net.minecraft.class_1856;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2378;
import net.minecraft.class_243;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2596;
import net.minecraft.class_2602;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3611;
import net.minecraft.class_5321;
import net.minecraft.class_5341;
import net.minecraft.class_8710;

/**
 * more like IHexplatAbstracts lmaooooooo
 */

public interface IXplatAbstractions {
    Platform platform();

    boolean isModPresent(String id);

    boolean isPhysicalClient();

    void initPlatformSpecific();

    void sendPacketToPlayer(class_3222 target, class_8710 packet);

    void sendPacketNear(class_243 pos, double radius, class_3218 dimension, class_8710 packet);

    void sendPacketTracking(class_1297 entity, class_8710 packet);

    // https://github.com/VazkiiMods/Botania/blob/13b7bcd9cbb6b1a418b0afe455662d29b46f1a7f/Xplat/src/main/java/vazkii/botania/xplat/IXplatAbstractions.java#L157
    class_2596<class_2602> toVanillaClientboundPacket(class_8710 message);

//    double getReachDistance(Player player);

    // Things that used to be caps

    /**
     * Doesn't actually knock out its AI or anything anymore, just sets caps/ccs
     */
    // heheheheh addled data
    void setBrainsweepAddlData(class_1308 mob);

    boolean isBrainswept(class_1308 mob);

    @Nullable FrozenPigment setPigment(class_1657 target, @Nullable FrozenPigment colorizer);

    void setSentinel(class_1657 target, @Nullable Sentinel sentinel);

    void setFlight(class_3222 target, @Nullable FlightAbility flight);

    void setAltiora(class_1657 target, @Nullable AltioraAbility altiora);

    void setStaffcastImage(class_3222 target, @Nullable CastingImage image);

    void setPatterns(class_3222 target, List<ResolvedPattern> patterns);

    @Nullable FlightAbility getFlight(class_3222 player);

    @Nullable AltioraAbility getAltiora(class_1657 player);

    FrozenPigment getPigment(class_1657 player);

    @Nullable Sentinel getSentinel(class_1657 player);

    CastingVM getStaffcastVM(class_3222 player, class_1268 hand);

    List<ResolvedPattern> getPatternsSavedInUi(class_3222 player);

    void clearCastingData(class_3222 player);

    @Nullable
    ADMediaHolder findMediaHolder(class_1799 stack);

    @Nullable
    ADIotaHolder findDataHolder(class_1799 stack);

    @Nullable
    ADIotaHolder findDataHolder(class_1297 entity);

    @Nullable
    ADHexHolder findHexHolder(class_1799 stack);
    
    @Nullable
    ADVariantItem findVariantHolder(class_1799 stack);

    // coooollooorrrs

    boolean isPigment(class_1799 stack);

    ColorProvider getColorProvider(FrozenPigment pigment);

    // Items

    /**
     * No-op on forge (use a SoftImplement)
     */
    class_1792.class_1793 addEquipSlotFabric(class_1304 slot);

    // Blocks

    <T extends class_2586> class_2591<T> createBlockEntityType(BiFunction<class_2338, class_2680, T> func,
        class_2248... blocks);

    boolean tryPlaceFluid(class_1937 level, class_1268 hand, class_2338 pos, class_3611 fluid);

    boolean drainAllFluid(class_1937 level, class_2338 pos);

    // misc

    boolean isCorrectTierForDrops(class_1832 tier, class_2680 bs);

    class_1856 getUnsealedIngredient(class_1799 stack);

    IXplatTags tags();

    class_5341.class_210 isShearsCondition();

    String getModName(String namespace);

    /**
     * Registry for actions.
     * <p>
     * There's some internal caching (so we can directly look up signatures in a map, for example)
     * but this registry is the source of truth.
     */
    class_2378<ActionRegistryEntry> getActionRegistry();

    class_2378<SpecialHandler.Factory<?>> getSpecialHandlerRegistry();

    class_2378<IotaType<?>> getIotaTypeRegistry();

    class_2378<Arithmetic> getArithmeticRegistry();
    class_2378<ContinuationFrame.Type<?>> getContinuationTypeRegistry();

    class_2378<EvalSound> getEvalSoundRegistry();

    class_2378<StateIngredientType<?>> getStateIngredientRegistry();

    class_2378<BrainsweepeeIngredientType<?>> getBrainsweepeeIngredientRegistry();

    GameProfile HEXCASTING = new GameProfile(UUID.fromString("8BE7E9DA-1667-11EE-BE56-0242AC120002"), "[HexCasting]");

    boolean isBreakingAllowed(class_3218 world, class_2338 pos, class_2680 state, @Nullable class_1657 player);

    boolean isPlacingAllowed(class_3218 world, class_2338 pos, class_1799 blockStack, @Nullable class_1657 player);

    /**
     * Takes a ResourceKey representing a Registry for type B, returns an IXplatRegister of type B
     * @param registryKey
     * @return {@code IXplatRegister<B>}
     * @param <B>
     */
    <B> IXplatRegister<B> createRegistar(class_5321<class_2378<B>> registryKey);

    // interop

    PehkuiInterop.ApiAbstraction getPehkuiApi();

    ///

    IXplatAbstractions INSTANCE = find();

    private static IXplatAbstractions find() {
        var providers = ServiceLoader.load(IXplatAbstractions.class).stream().toList();
        if (providers.size() != 1) {
            var names = providers.stream().map(p -> p.type().getName()).collect(Collectors.joining(",", "[", "]"));
            throw new IllegalStateException(
                "There should be exactly one IXplatAbstractions implementation on the classpath. Found: " + names);
        } else {
            var provider = providers.get(0);
            HexAPI.LOGGER.debug("Instantiating xplat impl: " + provider.type().getName());
            return provider.get();
        }
    }

}
