package at.petrak.hexcasting.xplat;

import java.util.function.Supplier;
import net.minecraft.class_6880;

/**
 * A platform-agnostic registry of type {B} <br>
 * FabricRegister registers directly while ForgeRegister uses deferred registry instead
 * @param <B> The Type the IXplatRegister is registering
 */
public interface IXplatRegister<B> {

    <T extends B> Supplier<T> register(String id, Supplier<T> provider);

    <T extends B> class_6880<B> registerHolder(String id, Supplier<T> provider);

    /**
     * Call from mod initializer to actually register all entries in this register
     */
    void registerAll();
}