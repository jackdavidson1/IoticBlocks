package at.petrak.hexcasting.datagen;

import at.petrak.hexcasting.api.HexAPI;
import at.petrak.hexcasting.api.advancements.*;
import at.petrak.hexcasting.api.misc.MediaConstants;
import at.petrak.hexcasting.api.mod.HexTags;
import at.petrak.hexcasting.common.items.ItemLoreFragment;
import at.petrak.hexcasting.common.lib.HexBlocks;
import at.petrak.hexcasting.common.lib.HexItems;
import at.petrak.paucal.api.datagen.PaucalAdvancementSubProvider;
import net.minecraft.advancements.*;
import net.minecraft.advancements.critereon.*;
import net.minecraft.class_161;
import net.minecraft.class_174;
import net.minecraft.class_175;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_185;
import net.minecraft.class_189;
import net.minecraft.class_2010;
import net.minecraft.class_2062;
import net.minecraft.class_2066;
import net.minecraft.class_2073;
import net.minecraft.class_2096;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_7225;
import net.minecraft.class_8779;
import java.util.Optional;
import java.util.function.Consumer;

public class HexAdvancements extends PaucalAdvancementSubProvider {
    public static final OvercastTrigger.Instance ENLIGHTEN =
        new OvercastTrigger.Instance(Optional.empty(),
            class_2096.class_2100.field_9708,
            // add a little bit of slop here. use 80% or more health ...
            class_2096.class_2099.method_9050(0.8),
            // and be left with under 1 healthpoint (half a heart)
            // TODO this means if 80% of your health is less than half a heart, so if you have 2.5 hearts or
            //  less, you can't become enlightened.
            class_2096.class_2099.method_35285(Double.MIN_NORMAL, 1.0)
        );

    public HexAdvancements() {
        super(HexAPI.MOD_ID);
    }

    @Override
    public void method_10335(class_7225.class_7874 provider, Consumer<class_8779> consumer) {
        var root = class_161.class_162.method_707()
            // what an ergonomic design decision
            // i am so happy that data generators are the future
            .method_693(new class_185(new class_1799(class_1802.field_27065),
                class_2561.method_43471("advancement.hexcasting:root"),
                class_2561.method_43471("advancement.hexcasting:root.desc"),
                Optional.of(class_2960.method_60656("textures/block/calcite.png")),
                class_189.field_1254, true, true, true))
            // the only thing making this vaguely tolerable is the knowledge the json files are worse somehow
            .method_705("has_charged_amethyst", class_2066.class_2068.method_8957(
                class_2073.class_2074.method_8973().method_8975(HexTags.Items.GRANTS_ROOT_ADVANCEMENT).method_8976()))
            .method_694(consumer, prefix("root")); // how the hell does one even read this

        //Creative Debug Unlocker
        class_161.class_162.method_707()
            .method_693(new class_185(new class_1799(HexItems.CREATIVE_UNLOCKER),
                class_2561.method_43471("advancement.hexcasting:creative_unlocker"),
                class_2561.method_43471("advancement.hexcasting:creative_unlocker.desc"),
                Optional.of(class_2960.method_60656("textures/block/calcite.png")),
                    class_189.field_1254, true, false, true))
            .method_701(root)
            .method_705("has_creative_unlocker", class_2066.class_2068.method_8957(
                class_2073.class_2074.method_8973().method_8977(HexItems.CREATIVE_UNLOCKER).method_8976()))
            .method_694(consumer, prefix("creative_unlocker"));

        // weird names so we have alphabetical parity
        class_161.class_162.method_707()
            .method_693(simpleDisplay(class_1802.field_8597, "wasteful_cast", class_189.field_1254))
            .method_701(root)
            .method_705("waste_amt", new class_175<>(
                    HexAdvancementTriggers.SPEND_MEDIA_TRIGGER,
                    new SpendMediaTrigger.Instance(Optional.empty(),
                            MinMaxLongs.ANY,
                            MinMaxLongs.atLeast(89 * MediaConstants.DUST_UNIT / 10))
            ))
            .method_694(consumer, prefix("aaa_wasteful_cast"));
        class_161.class_162.method_707()
            .method_693(simpleDisplay(HexItems.CHARGED_AMETHYST, "big_cast", class_189.field_1254))
            .method_701(root)
            .method_705("cast_amt", new class_175<>(
                    HexAdvancementTriggers.SPEND_MEDIA_TRIGGER,
                    new SpendMediaTrigger.Instance(Optional.empty(),
                            MinMaxLongs.atLeast(64 * MediaConstants.CRYSTAL_UNIT),
                            MinMaxLongs.ANY)
            ))
            .method_694(consumer, prefix("aab_big_cast"));

        var impotence = class_161.class_162.method_707()
            .method_693(simpleDisplay(class_1802.field_8183, "y_u_no_cast_angy", class_189.field_1254))
            .method_701(root)
            .method_705("did_the_thing",
                new class_175<>(HexAdvancementTriggers.FAIL_GREAT_SPELL_TRIGGER,
                        new FailToCastGreatSpellTrigger.Instance(Optional.empty())))
            .method_694(consumer, prefix("y_u_no_cast_angy"));

        var opened_eyes = class_161.class_162.method_707()
            .method_693(simpleDisplay(class_1802.field_8449, "opened_eyes", class_189.field_1254))
            .method_701(impotence)
            .method_705("health_used",
                new class_175<>(
                        HexAdvancementTriggers.OVERCAST_TRIGGER,
                        new OvercastTrigger.Instance(Optional.empty(),
                                class_2096.class_2100.field_9708,
                                class_2096.class_2099.field_9705,
                                // you can't just kill yourself
                                class_2096.class_2099.method_9050(0.0)))
                )
            .method_694(consumer, prefix("opened_eyes"));

        class_161.class_162.method_707()
            .method_693(new class_185(new class_1799(class_1802.field_8731),
                class_2561.method_43471("advancement.hexcasting:enlightenment"),
                class_2561.method_43471("advancement.hexcasting:enlightenment.desc"),
                Optional.empty(),
                class_189.field_1250, true, true, true))
            .method_701(opened_eyes)
            .method_705("health_used", new class_175<>(HexAdvancementTriggers.OVERCAST_TRIGGER, ENLIGHTEN))
            .method_694(consumer, prefix("enlightenment"));

        var loreRoot = class_161.class_162.method_707()
            .method_693(simpleDisplayWithBackground(HexBlocks.AKASHIC_LIGATURE, "lore", class_189.field_1249,
                modLoc("textures/block/slate_block.png")))
            .method_705("used_item", new class_175<>(class_174.field_1198, new class_2010.class_2012(Optional.empty(),
                    Optional.of(class_2073.class_2074.method_8973().method_8977(HexItems.LORE_FRAGMENT).method_8976()))))
            .method_694(consumer, prefix("lore"));

        for (var advId : ItemLoreFragment.NAMES) {
            class_161.class_162.method_707()
                .method_693(new class_185(new class_1799(HexItems.LORE_FRAGMENT),
                    class_2561.method_43471("advancement." + advId), class_2561.method_43473(),
                        Optional.empty(), class_189.field_1254, true, true, true))
                .method_701(loreRoot)
                .method_705(ItemLoreFragment.CRITEREON_KEY, new class_175<>(class_174.field_1184, new class_2062.class_2063()))
                .method_694(consumer, advId.toString());
        }

//        super.registerAdvancements(consumer, fileHelper);
    }
}
