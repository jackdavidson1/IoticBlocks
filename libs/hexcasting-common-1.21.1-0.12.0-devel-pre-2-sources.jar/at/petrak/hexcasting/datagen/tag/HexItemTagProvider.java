package at.petrak.hexcasting.datagen.tag;

import at.petrak.hexcasting.api.mod.HexTags;
import at.petrak.hexcasting.common.lib.HexItems;
import at.petrak.hexcasting.xplat.IXplatTags;
import java.util.concurrent.CompletableFuture;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_2248;
import net.minecraft.class_3481;
import net.minecraft.class_3489;
import net.minecraft.class_7225;
import net.minecraft.class_7784;
import net.minecraft.class_7805;
import net.minecraft.class_7923;

public class HexItemTagProvider extends class_7805 {
    private final IXplatTags xtags;

    public HexItemTagProvider(class_7784 output, CompletableFuture<class_7225.class_7874> lookup, CompletableFuture<class_8211<class_2248>> pBlockTagsProvider, IXplatTags xtags) {
        super(output, lookup, pBlockTagsProvider);
        this.xtags = xtags;
    }

    @Override
    protected void method_10514(class_7225.class_7874 provider) {
        add(method_46827(xtags.gems()),
            HexItems.CHARGED_AMETHYST);
        add(method_46827(xtags.amethystDust()),
            HexItems.AMETHYST_DUST);

        add(method_46827(HexTags.Items.STAVES),
            HexItems.STAFF_EDIFIED,
            HexItems.STAFF_OAK, HexItems.STAFF_SPRUCE, HexItems.STAFF_BIRCH,
            HexItems.STAFF_JUNGLE, HexItems.STAFF_ACACIA, HexItems.STAFF_DARK_OAK,
            HexItems.STAFF_CRIMSON, HexItems.STAFF_WARPED, HexItems.STAFF_MANGROVE,
            HexItems.STAFF_CHERRY,HexItems.STAFF_BAMBOO,
            HexItems.STAFF_QUENCHED, HexItems.STAFF_MINDSPLICE);

        add(method_46827(HexTags.Items.PHIAL_BASE),
            class_1802.field_8469);
        add(method_46827(HexTags.Items.GRANTS_ROOT_ADVANCEMENT),
            HexItems.AMETHYST_DUST, class_1802.field_27063,
            HexItems.CHARGED_AMETHYST, HexItems.CREATIVE_UNLOCKER);
        add(method_46827(HexTags.Items.SEAL_MATERIALS),
            class_1802.field_20414);

        this.method_46218(HexTags.Blocks.EDIFIED_LOGS, HexTags.Items.EDIFIED_LOGS);
        this.method_46218(HexTags.Blocks.EDIFIED_PLANKS, HexTags.Items.EDIFIED_PLANKS);
        this.method_46218(HexTags.Blocks.IMPETI, HexTags.Items.IMPETI);
        this.method_46218(HexTags.Blocks.DIRECTRICES, HexTags.Items.DIRECTRICES);
        this.method_46218(HexTags.Blocks.MINDFLAYED_CIRCLE_COMPONENTS, HexTags.Items.MINDFLAYED_CIRCLE_COMPONENTS);
        this.method_46218(HexTags.Blocks.SLATE_BLOCKS, HexTags.Items.SLATE_BLOCKS);
        this.method_46218(HexTags.Blocks.AMETHYST_BLOCKS, HexTags.Items.AMETHYST_BLOCKS);
        this.method_46218(HexTags.Blocks.QUENCHED_ALLAY_BLOCKS, HexTags.Items.QUENCHED_ALLAY_BLOCKS);
        this.method_46218(class_3481.field_23210, class_3489.field_23212);
        this.method_46218(class_3481.field_15475, class_3489.field_15539);
        this.method_46218(class_3481.field_15471, class_3489.field_15537);
        this.method_46218(class_3481.field_15469, class_3489.field_15535);
        this.method_46218(class_3481.field_15468, class_3489.field_15534);
        this.method_46218(class_3481.field_15495, class_3489.field_15553);
        this.method_46218(class_3481.field_15494, class_3489.field_15552);
        this.method_46218(class_3481.field_15487, class_3489.field_15548);
        this.method_46218(class_3481.field_15491, class_3489.field_15550);
        this.method_46218(class_3481.field_15503, class_3489.field_15558);
        // Apparently, there's no "Pressure Plates" item tag.
        this.method_46218(class_3481.field_15477, class_3489.field_15540);
        this.method_46218(class_3481.field_15493, class_3489.field_15551);
        this.method_46218(class_3481.field_15499, class_3489.field_15555);
    }

    void add(class_5124<class_1792> appender, class_1792... items) {
        for (class_1792 item : items) {
            appender.method_46835(class_7923.field_41178.method_29113(item).orElseThrow());
        }
    }
}
