package at.petrak.hexcasting.api.casting.iota;

import at.petrak.hexcasting.common.lib.hex.HexIotaTypes;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import com.samsthenerd.inline.api.InlineAPI;
import com.samsthenerd.inline.api.data.EntityInlineData;
import com.samsthenerd.inline.api.data.PlayerHeadData;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.lang.ref.WeakReference;
import java.util.Optional;
import java.util.UUID;
import net.minecraft.class_124;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_4844;
import net.minecraft.class_5250;
import net.minecraft.class_8824;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import net.minecraft.class_9296;

public class EntityIota extends Iota {
    private final UUID entityId;
    @Nullable
    private final class_2561 entityName;

    public EntityIota(@NotNull class_1297 e) {
        this(e.method_5667(), getEntityNameWithInline(e));
    }

    public EntityIota(UUID entityId, @Nullable class_2561 entityName) {
        super(() -> HexIotaTypes.ENTITY);
        this.entityId = entityId;
        this.entityName = entityName;
    }

    public UUID getEntityId() {
        return entityId;
    }

    public class_1297 getEntity(class_3218 level) {
        return level.method_14190(entityId);
    }

    public @Nullable class_2561 getEntityName() {
        return entityName;
    }

    @Override
    public boolean toleratesOther(Iota that) {
        return typesMatch(this, that)
                && that instanceof EntityIota dent
                && this.getEntityId() == dent.getEntityId();
    }

    @Override
    public boolean isTruthy() {
        return true;
    }

    @Override
    public class_2561 display() {
        var name = getEntityName();
        return name != null ? name.method_27661().method_27692(class_124.field_1075) : class_2561.method_43471("hexcasting.spelldata.entity.whoknows");
    }

    @Override
    public int hashCode() {
        return entityId.hashCode();
    }

    private static class_2561 getEntityNameWithInline(class_1297 entity) {
        class_5250 baseName = entity.method_5477().method_27661();
        class_2561 inlineEnt;
        if(entity instanceof class_1657 player){
            inlineEnt = new PlayerHeadData(new class_9296(player.method_7334())).asText(false);
            inlineEnt = inlineEnt.method_27662().method_27696(InlineAPI.INSTANCE.withSizeModifier(inlineEnt.method_10866(), 1.5));
        } else {
            inlineEnt = EntityInlineData.fromType(entity.method_5864()).asText(false);
        }
        return baseName.method_10852(class_2561.method_43470(": ")).method_10852(inlineEnt);
    }



    public static IotaType<EntityIota> TYPE = new IotaType<>() {
        public static final MapCodec<EntityIota> CODEC = RecordCodecBuilder.mapCodec(inst ->
                inst.group(
                        class_4844.field_25122.fieldOf("entityId").forGetter(EntityIota::getEntityId),
                        class_8824.field_46597.optionalFieldOf("entityName").forGetter(iota -> Optional.ofNullable(iota.getEntityName()))
                ).apply(inst, (a, b) -> new EntityIota(a, b.orElse(null))));
        public static final class_9139<class_9129, EntityIota> STREAM_CODEC =
                class_9139.method_56435(
                        class_4844.field_48453, EntityIota::getEntityId,
                        class_9135.method_56382(class_8824.field_48540), iota -> Optional.ofNullable(iota.getEntityName()),
                        (a, b) -> new EntityIota(a, b.orElse(null))
                );

        @Override
        public boolean validate(EntityIota iota, class_3218 level) {
            var entity = iota.getEntity(level);
            return entity != null;
        }

        @Override
        public MapCodec<EntityIota> codec() {
            return CODEC;
        }

        @Override
        public class_9139<class_9129, EntityIota> streamCodec() {
            return STREAM_CODEC;
        }

        @Override
        public int color() {
            return 0xff_55ffff;
        }
    };
}
