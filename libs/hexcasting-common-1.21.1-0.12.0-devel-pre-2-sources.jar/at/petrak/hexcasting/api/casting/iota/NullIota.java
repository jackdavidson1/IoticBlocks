package at.petrak.hexcasting.api.casting.iota;

import at.petrak.hexcasting.common.lib.hex.HexIotaTypes;
import com.mojang.serialization.MapCodec;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

/**
 * An iota with no data associated with it.
 */
public class NullIota extends Iota {

    public static final class_2561 DISPLAY =
        class_2561.method_43471("hexcasting.tooltip.null_iota").method_27692(class_124.field_1080);

    public NullIota() {
        super(() -> HexIotaTypes.NULL);
    }

    @Override
    public boolean isTruthy() {
        return false;
    }

    @Override
    public boolean toleratesOther(Iota that) {
        return typesMatch(this, that);
    }

    @Override
    public int hashCode() { return 0; }

    @Override
    public class_2561 display() {
        return DISPLAY;
    }

    public static IotaType<NullIota> TYPE = new IotaType<>() {
        public static final MapCodec<NullIota> CODEC = MapCodec.unit(new NullIota());
        public static final class_9139<class_9129, NullIota> STREAM_CODEC =
                class_9139.method_56431(new NullIota());

        @Override
        public MapCodec<NullIota> codec() {
            return CODEC;
        }

        @Override
        public class_9139<class_9129, NullIota> streamCodec() {
            return STREAM_CODEC;
        }

        @Override
        public int color() {
            return 0xff_aaaaaa;
        }
    };
}
