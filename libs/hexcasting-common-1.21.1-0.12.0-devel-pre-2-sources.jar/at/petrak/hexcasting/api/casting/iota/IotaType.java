package at.petrak.hexcasting.api.casting.iota;

import at.petrak.hexcasting.common.lib.HexRegistries;
import at.petrak.hexcasting.common.lib.hex.HexIotaTypes;
import at.petrak.hexcasting.xplat.IXplatAbstractions;
import com.mojang.serialization.Codec;
import com.mojang.serialization.DataResult;
import com.mojang.serialization.MapCodec;
import java.util.List;
import java.util.function.Function;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

// Take notes from ForgeRegistryEntry
public abstract class IotaType<T extends Iota> {

    /**
     * Get a codec associated with this datum. It can be used with {@code TYPED_CODEC} to serialize and deserialize said datum.
     * @return {@code MapCodec<T extends Iota>}
     */
    public abstract MapCodec<T> codec();

    /**
     * Get a {@link class_9139} associated with this datum.
     * Is used for Client <-> Server communication.
     * <p>
     * It can be used with {@code TYPED_STREAM_CODEC} to deserde said datum with {@link class_9129}
     * @return {@link class_9139} of {@link IotaType}
     */
    public abstract class_9139<class_9129, T> streamCodec();

    /**
     * Get the color associated with this datum type.
     */
    public abstract int color();

    public static final Codec<Iota> TYPED_CODEC = Codec.lazyInitialized(() -> IXplatAbstractions.INSTANCE
            .getIotaTypeRegistry()
            .method_39673()
            .<Iota>dispatch("type", Iota::getType, IotaType::codec)
            .comapFlatMap(
                    iota -> {
                        if (isTooLargeToSerialize(List.of(iota), 0)) {
                            return DataResult.success(new GarbageIota());
                        }
                        return DataResult.success(iota);
                    },
                    Function.identity()
            ).orElse(new GarbageIota())
    );

    public static final class_9139<class_9129, Iota> TYPED_STREAM_CODEC = class_9135
            .method_56365(HexRegistries.IOTA_TYPE)
            .method_56440(Iota::getType, IotaType::streamCodec);

    public boolean validate(T iota, class_3218 level) {
        return true;
    }

    /**
     * Checks if an Iterable Iota object is too large for deserde.
     * @param examinee
     * @return {@code boolean}
     */
    public static boolean isTooLargeToSerialize(Iterable<Iota> examinee) {
        return isTooLargeToSerialize(examinee, 1);
    }

    private static boolean isTooLargeToSerialize(Iterable<Iota> examinee, int startingCount) {
        int totalSize = startingCount;
        for (Iota iota : examinee) {
            if (iota.depth() >= HexIotaTypes.MAX_SERIALIZATION_DEPTH)
                return true;
            totalSize += iota.size();
        }
        return totalSize >= HexIotaTypes.MAX_SERIALIZATION_TOTAL;
    }

    public static class_2561 brokenIota() {
        return class_2561.method_43471("hexcasting.spelldata.unknown")
            .method_27695(class_124.field_1080, class_124.field_1056);
    }
}
