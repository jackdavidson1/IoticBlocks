package at.petrak.hexcasting.api.casting.iota;

import at.petrak.hexcasting.api.utils.HexUtils;
import at.petrak.hexcasting.common.lib.hex.HexIotaTypes;
import com.mojang.serialization.MapCodec;
import org.jetbrains.annotations.NotNull;

import java.util.List;
import net.minecraft.class_124;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public class Vec3Iota extends Iota {
    private class_243 value;
    public Vec3Iota(@NotNull class_243 datum) {
        super(() -> HexIotaTypes.VEC3);
        this.value = datum;
    }

    public class_243 getVec3() {
        return new class_243(
            HexUtils.fixNAN(value.field_1352),
            HexUtils.fixNAN(value.field_1351),
            HexUtils.fixNAN(value.field_1350)
        );
    }

    @Override
    public boolean isTruthy() {
        var v = this.getVec3();
        return !(v.field_1352 == 0.0 && v.field_1351 == 0.0 && v.field_1350 == 0.0);
    }

    @Override
    public boolean toleratesOther(Iota that) {
        return typesMatch(this, that)
            && that instanceof Vec3Iota viota
            && this.getVec3().method_1025(viota.getVec3()) < DoubleIota.TOLERANCE * DoubleIota.TOLERANCE;
    }

    @Override
    public int hashCode() {
        return value.hashCode();
    }

    @Override
    public class_2561 display() {
        return Vec3Iota.display(getVec3());
    }

    public static IotaType<Vec3Iota> TYPE = new IotaType<>() {
        public static final MapCodec<Vec3Iota> CODEC = class_243.field_38277
                .xmap(Vec3Iota::new, Vec3Iota::getVec3)
                .fieldOf("value");
        // TODO replace with Vec3 codec if it will appear somewhere
        public static final class_9139<class_9129, Vec3Iota> STREAM_CODEC =
                class_9135.field_48553.method_56433(class_9135.method_56363())
                        .method_56432(
                                l -> new Vec3Iota(new class_243(l.get(0), l.get(1), l.get(2))),
                                iota -> List.of(iota.getVec3().field_1352, iota.getVec3().field_1351, iota.getVec3().field_1350)
                        )
                        .method_56439(b -> b);

        @Override
        public MapCodec<Vec3Iota> codec() {
            return CODEC;
        }

        @Override
        public class_9139<class_9129, Vec3Iota> streamCodec() {
            return STREAM_CODEC;
        }

        @Override
        public int color() {
            return 0xff_ff3030;
        }
    };

    public static class_2561 display(double x, double y, double z) {
        return class_2561.method_43470(String.format("(%.2f, %.2f, %.2f)", x, y, z))
            .method_27692(class_124.field_1061);
    }

    public static class_2561 display(class_243 v) {
        return display(v.field_1352, v.field_1351, v.field_1350);
    }
}
