package at.petrak.hexcasting.api.casting.iota;

import at.petrak.hexcasting.common.lib.hex.HexIotaTypes;
import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public class BooleanIota extends Iota {
    private boolean value;
    public BooleanIota(boolean d) {
        super(() -> HexIotaTypes.BOOLEAN);
        this.value = d;
    }

    public boolean getBool() {
        return value;
    }

    @Override
    public boolean isTruthy() {
        return this.getBool();
    }

    @Override
    public boolean toleratesOther(Iota that) {
        return typesMatch(this, that)
            && that instanceof BooleanIota b
            && this.getBool() == b.getBool();
    }

    @Override
    public int hashCode() {
        return Boolean.hashCode(value);
    }

    @Override
    public class_2561 display() {
        return BooleanIota.display(value);
    }

    public static IotaType<BooleanIota> TYPE = new IotaType<>() {
        public static final MapCodec<BooleanIota> CODEC = Codec.BOOL
                .xmap(BooleanIota::new, BooleanIota::getBool)
                .fieldOf("value");
        public static final class_9139<class_9129, BooleanIota> STREAM_CODEC =
                class_9135.field_48547.method_56432(BooleanIota::new, BooleanIota::getBool).method_56439(buffer -> buffer);

        @Override
        public MapCodec<BooleanIota> codec() {
            return CODEC;
        }

        @Override
        public class_9139<class_9129, BooleanIota> streamCodec() {
            return STREAM_CODEC;
        }

        @Override
        public int color() {
            // We can't set red or green ... so do yellow, I guess
            return 0xff_ffff55;
        }
    };

    public static class_2561 display(boolean b) {
        return class_2561.method_43471(b ? "hexcasting.tooltip.boolean_true" : "hexcasting.tooltip.boolean_false")
            .method_27692(b ? class_124.field_1077 : class_124.field_1079);
    }
}
