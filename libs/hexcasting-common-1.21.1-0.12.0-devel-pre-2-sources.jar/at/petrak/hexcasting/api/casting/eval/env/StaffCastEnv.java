package at.petrak.hexcasting.api.casting.eval.env;

import at.petrak.hexcasting.api.HexAPI;
import at.petrak.hexcasting.api.casting.ParticleSpray;
import at.petrak.hexcasting.api.casting.eval.CastResult;
import at.petrak.hexcasting.api.casting.eval.ExecutionClientView;
import at.petrak.hexcasting.api.casting.eval.ResolvedPattern;
import at.petrak.hexcasting.api.casting.eval.vm.CastingImage;
import at.petrak.hexcasting.api.casting.iota.PatternIota;
import at.petrak.hexcasting.api.casting.math.HexCoord;
import at.petrak.hexcasting.api.casting.math.HexPattern;
import at.petrak.hexcasting.api.mod.HexStatistics;
import at.petrak.hexcasting.api.pigment.FrozenPigment;
import at.petrak.hexcasting.common.msgs.MsgClearSpiralPatternsS2C;
import at.petrak.hexcasting.common.msgs.MsgNewSpellPatternC2S;
import at.petrak.hexcasting.common.msgs.MsgNewSpellPatternS2C;
import at.petrak.hexcasting.common.msgs.MsgNewSpiralPatternsS2C;
import at.petrak.hexcasting.xplat.IXplatAbstractions;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import net.minecraft.class_1268;
import net.minecraft.class_243;
import net.minecraft.class_3222;
import net.minecraft.class_3419;
import net.minecraft.class_8710;

public class StaffCastEnv extends PlayerBasedCastEnv {
    private final class_1268 castingHand;

    private final Set<HexPattern> castPatterns = new HashSet<>();
    private int soundsPlayed = 0;


    public StaffCastEnv(class_3222 caster, class_1268 castingHand) {
        super(caster, castingHand);

        this.castingHand = castingHand;
    }

    @Override
    public void postExecution(CastResult result) {
        super.postExecution(result);

        if (result.component1() instanceof PatternIota patternIota) {
            castPatterns.add(patternIota.getPattern());
        }

        // we always want to play this sound one at a time
        var sound = result.getSound().sound();
        if (soundsPlayed < 100 && sound != null) { // TODO: Make configurable
            var soundPos = this.caster.method_19538();
            this.world.method_43128(null, soundPos.field_1352, soundPos.field_1351, soundPos.field_1350,
                sound, class_3419.field_15248, 1f, 1f);
            soundsPlayed++;
        }
    }

    @Override
    public void postCast(CastingImage image) {
        super.postCast(image);

        var packet = new MsgNewSpiralPatternsS2C(
            this.caster.method_5667(), castPatterns.stream().toList(), Integer.MAX_VALUE
        );
        IXplatAbstractions.INSTANCE.sendPacketToPlayer(this.caster, packet);
        IXplatAbstractions.INSTANCE.sendPacketTracking(this.caster, packet);

        castPatterns.clear();
        soundsPlayed = 0;
    }

    @Override
    public long extractMediaEnvironment(long cost, boolean simulate) {
        if (this.caster.method_7337())
            return 0;

        var canOvercast = this.canOvercast();
        return this.extractMediaFromInventory(cost, canOvercast, simulate);
    }

    @Override
    public class_1268 getCastingHand() {
        return castingHand;
    }

    @Override
    public FrozenPigment getPigment() {
        return HexAPI.instance().getColorizer(this.caster);
    }

    public static void handleNewPatternOnServer(class_3222 sender, MsgNewSpellPatternC2S msg) {
        boolean cheatedPatternOverlap = false;

        List<ResolvedPattern> resolvedPatterns = msg.resolvedPatterns();
        if (!resolvedPatterns.isEmpty()) {
            var allPoints = new HashSet<HexCoord>();
            for (int i = 0; i < resolvedPatterns.size() - 1; i++) {
                ResolvedPattern pat = resolvedPatterns.get(i);
                allPoints.addAll(pat.getPattern().positions(pat.getOrigin()));
            }
            var currentResolvedPattern = resolvedPatterns.get(resolvedPatterns.size() - 1);
            var currentSpellPoints = currentResolvedPattern.getPattern()
                .positions(currentResolvedPattern.getOrigin());
            if (currentSpellPoints.stream().anyMatch(allPoints::contains)) {
                cheatedPatternOverlap = true;
            }
        }

        if (cheatedPatternOverlap) {
            return;
        }

        sender.method_7281(HexStatistics.PATTERNS_DRAWN);

        var vm = IXplatAbstractions.INSTANCE.getStaffcastVM(sender, msg.handUsed());

        // TODO: do we reset the number of evals run via the staff? because each new pat is a new tick.

        ExecutionClientView clientInfo = vm.queueExecuteAndWrapIota(new PatternIota(msg.pattern()), sender.method_51469());

        if (clientInfo.isStackClear()) {
            IXplatAbstractions.INSTANCE.setStaffcastImage(sender, null);
            IXplatAbstractions.INSTANCE.setPatterns(sender, List.of());
        } else {
            IXplatAbstractions.INSTANCE.setStaffcastImage(sender, vm.getImage().withOverriddenUsedOps(0));
            if (!resolvedPatterns.isEmpty()) {
                resolvedPatterns.get(resolvedPatterns.size() - 1).setType(clientInfo.getResolutionType());
            }
            IXplatAbstractions.INSTANCE.setPatterns(sender, resolvedPatterns);
        }

        IXplatAbstractions.INSTANCE.sendPacketToPlayer(sender,
            new MsgNewSpellPatternS2C(clientInfo, resolvedPatterns.size() - 1));

        class_8710 packet;
        if (clientInfo.isStackClear()) {
            packet = new MsgClearSpiralPatternsS2C(sender.method_5667());
        } else {
            packet = new MsgNewSpiralPatternsS2C(sender.method_5667(), List.of(msg.pattern()), Integer.MAX_VALUE);
        }
        IXplatAbstractions.INSTANCE.sendPacketToPlayer(sender, packet);
        IXplatAbstractions.INSTANCE.sendPacketTracking(sender, packet);

        if (clientInfo.getResolutionType().getSuccess()) {
            // Somehow we lost spraying particles on each new pattern, so do it here
            // this also nicely prevents particle spam on trinkets
            new ParticleSpray(sender.method_19538(), new class_243(0.0, 1.5, 0.0), 0.4, Math.PI / 3, 30)
                .sprayParticles(sender.method_51469(), IXplatAbstractions.INSTANCE.getPigment(sender));
        }
    }
}
