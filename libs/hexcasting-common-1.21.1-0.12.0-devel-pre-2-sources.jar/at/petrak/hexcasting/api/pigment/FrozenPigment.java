package at.petrak.hexcasting.api.pigment;

import at.petrak.hexcasting.common.lib.HexItems;
import at.petrak.hexcasting.xplat.IXplatAbstractions;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.UUID;
import java.util.function.Supplier;
import net.minecraft.class_156;
import net.minecraft.class_1799;
import net.minecraft.class_4844;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

/**
 * A snapshot of a pigment item and its owner.
 * <p>
 * Due to capabilities being really slow to query many times a tick on Forge, this returns a colorizer <i>supplier</i>.
 * Get it once, and then query it a lot.
 */
public record FrozenPigment(class_1799 item, UUID owner) {
    public static final Supplier<FrozenPigment> DEFAULT =
            () -> new FrozenPigment(new class_1799(HexItems.DEFAULT_PIGMENT), class_156.field_25140);
    public static final Supplier<FrozenPigment> ANCIENT =
            () -> new FrozenPigment(new class_1799(HexItems.ANCIENT_PIGMENT), class_156.field_25140);

    public static Codec<FrozenPigment> CODEC = RecordCodecBuilder.<FrozenPigment>create(inst ->
            inst.group(
                class_1799.field_24671.fieldOf("stack").forGetter(FrozenPigment::item),
                class_4844.field_25122.fieldOf("owner").forGetter(FrozenPigment::owner)
            ).apply(inst, FrozenPigment::new)).orElseGet(FrozenPigment.DEFAULT);
    //TODO port: maybe default here too somehow?..
    public static class_9139<class_9129, FrozenPigment> STREAM_CODEC = class_9139.method_56435(
            class_1799.field_48349, FrozenPigment::item,
            class_4844.field_48453, FrozenPigment::owner,
            FrozenPigment::new
    );


    public ColorProvider getColorProvider() {
        return IXplatAbstractions.INSTANCE.getColorProvider(this);
    }
}
