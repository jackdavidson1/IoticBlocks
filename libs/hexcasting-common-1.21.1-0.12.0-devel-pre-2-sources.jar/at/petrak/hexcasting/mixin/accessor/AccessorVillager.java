package at.petrak.hexcasting.mixin.accessor;

import net.minecraft.class_1297;
import net.minecraft.class_1646;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_1646.class)
public interface AccessorVillager {
    @Invoker("tellWitnessesThatIWasMurdered")
    void hex$tellWitnessesThatIWasMurdered(class_1297 murderer);

    @Invoker("releaseAllPois")
    void hex$releaseAllPois();
}
