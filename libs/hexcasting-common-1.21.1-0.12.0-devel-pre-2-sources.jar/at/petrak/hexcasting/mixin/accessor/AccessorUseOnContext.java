package at.petrak.hexcasting.mixin.accessor;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

import javax.annotation.Nullable;
import net.minecraft.class_1268;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1838;
import net.minecraft.class_1937;
import net.minecraft.class_3965;

@Mixin(class_1838.class)
public interface AccessorUseOnContext {
    @Invoker("<init>")
    static class_1838 hex$new(class_1937 $$0, @Nullable class_1657 $$1, class_1268 $$2, class_1799 $$3,
        class_3965 $$4) {
        throw new IllegalStateException();
    }
}
