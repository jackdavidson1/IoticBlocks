package at.petrak.hexcasting.mixin.accessor;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.gen.Accessor;

import java.util.List;
import java.util.function.BiFunction;
import net.minecraft.class_117;
import net.minecraft.class_1799;
import net.minecraft.class_47;
import net.minecraft.class_52;

@Mixin(class_52.class)
public interface AccessorLootTable {
    @Accessor("functions")
    List<class_117> hex$getFunctions();

    @Accessor("functions")
    @Mutable
    void hex$setFunctions(List<class_117> lifs);

    @Accessor("compositeFunction")
    @Mutable
    void hex$setCompositeFunction(BiFunction<class_1799, class_47, class_1799> bf);
}
