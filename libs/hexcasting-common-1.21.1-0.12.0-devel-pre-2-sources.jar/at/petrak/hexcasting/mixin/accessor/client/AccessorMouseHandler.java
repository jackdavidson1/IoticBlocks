package at.petrak.hexcasting.mixin.accessor.client;

import net.minecraft.class_312;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_312.class)
public interface AccessorMouseHandler {
    @Accessor("accumulatedScrollY")
    double hex$getAccumulatedScrollY();

    @Accessor("accumulatedScrollY")
    void hex$setAccumulatedScrollY(double scroll);
}
