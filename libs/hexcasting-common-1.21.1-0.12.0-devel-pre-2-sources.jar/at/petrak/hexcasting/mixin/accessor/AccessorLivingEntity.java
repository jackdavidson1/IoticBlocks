package at.petrak.hexcasting.mixin.accessor;

import net.minecraft.class_1282;
import net.minecraft.class_1309;
import net.minecraft.class_3414;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_1309.class)
public interface AccessorLivingEntity {
    @Accessor("lastHurt")
    float hex$getLastHurt();

    @Accessor("lastHurt")
    void hex$setLastHurt(float lastHurt);

    @Invoker("playHurtSound")
    void hex$playHurtSound(class_1282 source);

    @Invoker("checkTotemDeathProtection")
    boolean hex$checkTotemDeathProtection(class_1282 source);

    @Invoker("getDeathSound")
    class_3414 hex$getDeathSound();

    @Invoker("getSoundVolume")
    float hex$getSoundVolume();

    @Accessor("lastDamageSource")
    void hex$setLastDamageSource(class_1282 source);

    @Accessor("lastDamageStamp")
    void hex$setLastDamageStamp(long stamp);
}
