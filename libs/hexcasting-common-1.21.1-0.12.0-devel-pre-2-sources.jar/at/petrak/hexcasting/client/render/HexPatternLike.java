package at.petrak.hexcasting.client.render;

import at.petrak.hexcasting.api.casting.math.HexPattern;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import net.minecraft.class_241;

/**
 * A simple wrapper around the parts of HexPattern that are actually used for rendering.
 *
 * This lets the pattern renderer work on arbitrary lists of vecs - this is never used in base hex but is included
 * to future-proof and for if addons or something wants to use it.
 */
public interface HexPatternLike {
    List<class_241> getNonZappyPoints();

    String getName();

    Set<Integer> getDups();

    static HexPatternLike of(HexPattern pat){
        return new HexPatternLikeBecauseItsActuallyAHexPattern(pat);
    }

    static HexPatternLike of(List<class_241> lines, String name){
        return new PureLines(lines, name);
    }

    record HexPatternLikeBecauseItsActuallyAHexPattern(HexPattern pat) implements HexPatternLike{
        public List<class_241> getNonZappyPoints(){
            return pat.toLines(1, class_241.field_1340);
        }

        public String getName(){
            return pat.getStartDir() + "-" + pat.anglesSignature();
        }

        public Set<Integer> getDups(){
            return RenderLib.findDupIndices(pat.positions());
        }
    }

    record PureLines(List<class_241> lines, String name) implements HexPatternLike{

        public List<class_241> getNonZappyPoints(){
            return lines;
        }

        public String getName(){
            return name;
        }

        public Set<Integer> getDups(){
            return RenderLib.findDupIndices(
                lines().stream().map(p ->
                    // I hate mojang
                    new class_241(p.field_1343, p.field_1342){
                        @Override public boolean equals(Object other){
                            if(other instanceof class_241 otherVec) return p.method_1016(otherVec);
                            return false;
                        }

                        @Override public int hashCode(){ return Objects.hash(p.field_1343, p.field_1342); }
                    }).toList()
            );
        }
    }
}
