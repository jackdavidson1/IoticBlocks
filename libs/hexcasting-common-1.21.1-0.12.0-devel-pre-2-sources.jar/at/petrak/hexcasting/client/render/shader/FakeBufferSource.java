package at.petrak.hexcasting.client.render.shader;

import at.petrak.hexcasting.mixin.accessor.client.AccessorCompositeRenderType;
import at.petrak.hexcasting.mixin.accessor.client.AccessorEmptyTextureStateShard;
import at.petrak.hexcasting.mixin.accessor.client.AccessorRenderStateShard;
import org.jetbrains.annotations.NotNull;

import java.util.Optional;
import java.util.function.Function;
import net.minecraft.class_1921;
import net.minecraft.class_2960;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_4668;

public record FakeBufferSource(class_4597 parent,
                               Function<class_2960, class_1921> mapper) implements class_4597 {

    @Override
    @SuppressWarnings("ConstantConditions")
    public @NotNull class_4588 getBuffer(@NotNull class_1921 renderType) {
        if (((AccessorRenderStateShard) renderType).hex$name().equals("entity_cutout_no_cull")
            && renderType instanceof class_1921.class_4687) {
            class_1921.class_4688 state = ((AccessorCompositeRenderType) renderType).hex$state();
            class_4668.class_5939 shard = state.field_21406;
            Optional<class_2960> texture = ((AccessorEmptyTextureStateShard) shard).hex$cutoutTexture();
            if (texture.isPresent()) {
                return parent.getBuffer(mapper.apply(texture.get()));
            }
        }
        return parent.getBuffer(renderType);
    }
}
