package at.petrak.hexcasting.client.render.be;

import at.petrak.hexcasting.client.RegisterClientStuff;
import at.petrak.hexcasting.client.render.GaslightingTracker;
import at.petrak.hexcasting.common.blocks.BlockQuenchedAllay;
import at.petrak.hexcasting.common.blocks.entity.BlockEntityQuenchedAllay;
import at.petrak.hexcasting.xplat.IClientXplatAbstractions;
import net.minecraft.class_1921;
import net.minecraft.class_238;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_5614;
import net.minecraft.class_776;
import net.minecraft.class_7923;
import net.minecraft.class_827;

// TODO: this doesn't cover the block being *behind* something. Is it possible to cleanly do that?
// it would probably require some depth-texture bullshit that I don't want to worry about
public class BlockEntityQuenchedAllayRenderer implements class_827<BlockEntityQuenchedAllay> {
    private final class_5614.class_5615 ctx;

    public BlockEntityQuenchedAllayRenderer(class_5614.class_5615 ctx) {
        this.ctx = ctx;
    }

    private static void doRender(BlockQuenchedAllay block, class_776 dispatcher, class_4587 ps, class_4597 bufSource,
        int packedLight, int packedOverlay) {
        var buffer = bufSource.getBuffer(class_1921.method_23583());
        var pose = ps.method_23760();

        var idx = Math.abs(GaslightingTracker.getGaslightingAmount() % BlockQuenchedAllay.VARIANTS);
        var model = RegisterClientStuff.QUENCHED_ALLAY_VARIANTS.get(class_7923.field_41175.method_10221(block)).get(idx);

        dispatcher.method_3350().method_3367(pose, buffer, null, model, 1f, 1f, 1f, packedLight, packedOverlay);
    }

    @Override
    public void render(BlockEntityQuenchedAllay blockEntity, float partialTick, class_4587 poseStack,
        class_4597 bufferSource, int packedLight, int packedOverlay) {
        // https://github.com/MinecraftForge/MinecraftForge/blob/79dfdb0ace9694f9dd0f1d9e8c5c24a0ae2d77f8/patches/minecraft/net/minecraft/client/renderer/LevelRenderer.java.patch#L68
        // Forge fixes BEs rendering offscreen; Fabric doesn't!
        // So we do a special check on Fabric only
        var pos = blockEntity.method_11016();
        var aabb = new class_238(pos.method_10069(-1, 0, -1).method_46558(), pos.method_10069(1, 1, 1).method_46558());
        if (IClientXplatAbstractions.INSTANCE.fabricAdditionalQuenchFrustumCheck(aabb)) {
            doRender((BlockQuenchedAllay) blockEntity.method_11010().method_26204(), this.ctx.method_32141(), poseStack, bufferSource, packedLight, packedOverlay);
        }
    }

    @Override
    public boolean shouldRenderOffScreen(BlockEntityQuenchedAllay blockEntity) {
        return false;
    }

}
