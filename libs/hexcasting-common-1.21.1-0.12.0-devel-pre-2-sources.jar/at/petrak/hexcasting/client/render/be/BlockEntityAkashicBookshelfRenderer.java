package at.petrak.hexcasting.client.render.be;

import at.petrak.hexcasting.api.casting.math.HexPattern;
import at.petrak.hexcasting.client.render.WorldlyPatternRenderHelpers;
import at.petrak.hexcasting.common.blocks.akashic.BlockEntityAkashicBookshelf;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_5614;
import net.minecraft.class_827;

public class BlockEntityAkashicBookshelfRenderer implements class_827<BlockEntityAkashicBookshelf> {
    public BlockEntityAkashicBookshelfRenderer(class_5614.class_5615 ctx) {
        // NO-OP
    }

    @Override
    public void render(BlockEntityAkashicBookshelf tile, float pPartialTick, class_4587 ps,
        class_4597 buffer, int light, int overlay) {
        HexPattern pattern = tile.getPattern();
        if (pattern == null) {
            return;
        }

        var bs = tile.method_11010();

        WorldlyPatternRenderHelpers.renderPatternForAkashicBookshelf(tile, pattern, ps, buffer, light, bs);
    }
}
