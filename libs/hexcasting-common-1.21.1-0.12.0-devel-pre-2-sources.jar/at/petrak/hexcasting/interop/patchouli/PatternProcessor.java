package at.petrak.hexcasting.interop.patchouli;

import net.minecraft.class_1074;
import net.minecraft.class_1937;
import vazkii.patchouli.api.IComponentProcessor;
import vazkii.patchouli.api.IVariable;
import vazkii.patchouli.api.IVariableProvider;

public class PatternProcessor implements IComponentProcessor {
    private String translationKey;

    @Override
    public void setup(class_1937 level, IVariableProvider vars) {
        if (vars.has("header"))
            translationKey = vars.get("header", level.method_30349()).asString();
        else {
            IVariable key = vars.get("op_id", level.method_30349());
            String opName = key.asString();

            String prefix = "hexcasting.action.";
            boolean hasOverride = class_1074.method_4663(prefix + "book." + opName);
            translationKey = prefix + (hasOverride ? "book." : "") + opName;
        }
    }

    @Override
    public IVariable process(class_1937 level, String key) {
        if (key.equals("translation_key")) {
            return IVariable.wrap(translationKey, level.method_30349());
        }

        return null;
    }
}
