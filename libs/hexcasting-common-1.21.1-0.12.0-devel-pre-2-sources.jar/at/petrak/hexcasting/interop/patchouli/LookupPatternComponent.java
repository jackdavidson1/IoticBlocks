package at.petrak.hexcasting.interop.patchouli;

import at.petrak.hexcasting.api.casting.math.HexPattern;
import at.petrak.hexcasting.api.mod.HexTags;
import at.petrak.hexcasting.xplat.IXplatAbstractions;
import com.google.gson.annotations.SerializedName;
import vazkii.patchouli.api.IVariable;

import java.util.List;
import java.util.function.UnaryOperator;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7225;

/**
 * Grab the pattern from the registry
 */
public class LookupPatternComponent extends AbstractPatternComponent {
    @SerializedName("op_id")
    public String opNameRaw;

    protected class_2960 opName;
    protected boolean strokeOrder;

    @Override
    public List<HexPattern> getPatterns(UnaryOperator<IVariable> lookup) {
        var key = class_5321.method_29179(IXplatAbstractions.INSTANCE.getActionRegistry().method_30517(), this.opName);
        var entry = IXplatAbstractions.INSTANCE.getActionRegistry().method_29107(key);

        this.strokeOrder =
            !IXplatAbstractions.INSTANCE.getActionRegistry().method_40290(key).method_40220(HexTags.Actions.PER_WORLD_PATTERN);
        return List.of(entry.prototype());
    }

    @Override
    public boolean showStrokeOrder() {
        return this.strokeOrder;
    }

    @Override
    public void onVariablesAvailable(UnaryOperator<IVariable> lookup, class_7225.class_7874 registries) {
        var opName = lookup.apply(IVariable.wrap(this.opNameRaw)).asString();
        this.opName = class_2960.method_12829(opName);

        super.onVariablesAvailable(lookup, registries);
    }
}
