package at.petrak.hexcasting.common.entities;

import at.petrak.hexcasting.api.casting.math.HexPattern;
import at.petrak.hexcasting.common.lib.HexDataComponents;
import at.petrak.hexcasting.common.lib.HexItems;
import at.petrak.hexcasting.common.lib.HexSounds;
import at.petrak.hexcasting.common.msgs.MsgNewWallScrollS2C;
import at.petrak.hexcasting.common.msgs.MsgRecalcWallScrollDisplayS2C;
import at.petrak.hexcasting.xplat.IXplatAbstractions;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1530;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1928;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2596;
import net.minecraft.class_2602;
import net.minecraft.class_2604;
import net.minecraft.class_2940;
import net.minecraft.class_2943;
import net.minecraft.class_2945;
import net.minecraft.class_3218;
import net.minecraft.class_3231;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import org.jetbrains.annotations.Nullable;

public class EntityWallScroll extends class_1530 {
    private static final class_2940<Boolean> SHOWS_STROKE_ORDER = class_2945.method_12791(
        EntityWallScroll.class,
        class_2943.field_13323);

    public class_1799 scroll;
    @Nullable
    public HexPattern pattern;
    public boolean isAncient;
    public int blockSize;

    public EntityWallScroll(class_1299<? extends EntityWallScroll> type, class_1937 world) {
        super(type, world);
    }

    public EntityWallScroll(class_1937 world, class_2338 pos, class_2350 dir, class_1799 scroll, boolean showStrokeOrder,
        int blockSize) {
        super(HexEntities.WALL_SCROLL, world, pos);
        this.method_6892(dir);
        this.blockSize = blockSize;

        this.field_6011.method_12778(SHOWS_STROKE_ORDER, showStrokeOrder);
        this.scroll = scroll;
        this.recalculateDisplay();
        this.method_6895();
    }

    public void recalculateDisplay() {
        this.pattern = scroll.method_57824(HexDataComponents.PATTERN);
        this.isAncient = scroll.method_57826(HexDataComponents.ACTION);
    }

    @Override
    protected void method_5693(class_2945.class_9222 builder) {
        builder.method_56912(SHOWS_STROKE_ORDER, false);
    }

    public boolean getShowsStrokeOrder() {
        return this.field_6011.method_12789(SHOWS_STROKE_ORDER);
    }

    public void setShowsStrokeOrder(boolean b) {
        this.field_6011.method_12778(SHOWS_STROKE_ORDER, b);
    }

    @Override
    protected class_238 method_59943(class_2338 pos, class_2350 p_direction) {
        float f = 0.46875F;
        class_243 vec3 = class_243.method_24953(pos).method_43206(p_direction, -0.46875);
        double d0 = blockSize % 2 == 0 ? 0.5 : 0.0;
        class_2350 direction = p_direction.method_10160();
        class_243 vec31 = vec3.method_43206(direction, d0).method_43206(class_2350.field_11036, d0);
        class_2350.class_2351 direction$axis = p_direction.method_10166();
        double d2 = direction$axis == class_2350.class_2351.field_11048 ? 0.0625 : blockSize;
        double d3 = blockSize;
        double d4 = direction$axis == class_2350.class_2351.field_11051 ? 0.0625 : blockSize;
        return class_238.method_30048(vec31, d2, d3, d4);
    }

    @Override
    public void method_6889(@Nullable class_1297 pBrokenEntity) {
        if (this.method_37908().method_8450().method_8355(class_1928.field_19393)) {
            this.method_5783(class_3417.field_14809, 1.0F, 1.0F);
            if (pBrokenEntity instanceof class_1657 player) {
                if (player.method_31549().field_7477) {
                    return;
                }
            }

            this.method_5775(this.scroll);
        }
    }

    @Override
    public class_1269 method_5664(class_1657 pPlayer, class_243 pVec, class_1268 pHand) {
        var handStack = pPlayer.method_5998(pHand);
        if (handStack.method_31574(HexItems.AMETHYST_DUST) && !this.getShowsStrokeOrder()) {
            if (!pPlayer.method_31549().field_7477) {
                handStack.method_7934(1);
            }
            this.setShowsStrokeOrder(true);

            pPlayer.method_37908().method_43129(pPlayer, this, HexSounds.SCROLL_DUST, class_3419.field_15248, 1f, 1f);

            if (pPlayer.method_37908() instanceof class_3218 slevel) {
                IXplatAbstractions.INSTANCE.sendPacketNear(this.method_19538(), 32.0, slevel,
                        new MsgRecalcWallScrollDisplayS2C(this.method_5628(), true));
            } else {
                // Beat the packet roundtrip to the punch to get a quicker visual
                this.recalculateDisplay();
            }
            return class_1269.field_5812;
        }
        return super.method_5664(pPlayer, pVec, pHand);
    }

    @Override
    public void method_6894() {
        this.method_5783(class_3417.field_14875, 1.0F, 1.0F);
    }

    @Override
    public class_2596<class_2602> method_18002(class_3231 entity) {
        return IXplatAbstractions.INSTANCE.toVanillaClientboundPacket(
            new MsgNewWallScrollS2C(new class_2604(this, this.field_7099.method_10146(), this.method_59940()),
                field_51589, field_7099, scroll, getShowsStrokeOrder(), blockSize));
    }

    public void readSpawnData(class_2338 pos, class_2350 dir, class_1799 scrollItem,
        boolean showsStrokeOrder, int blockSize) {
        this.field_51589 = pos;
        this.scroll = scrollItem;
        this.blockSize = blockSize;

        this.method_6892(dir);
        this.setShowsStrokeOrder(showsStrokeOrder);

        this.recalculateDisplay();
        this.method_6895();
    }

    @Override
    public void method_5652(class_2487 tag) {
        tag.method_10567("direction", (byte) this.field_7099.ordinal());
        tag.method_10566("scroll", this.scroll.method_57358(method_56673()));
        tag.method_10556("showsStrokeOrder", this.getShowsStrokeOrder());
        tag.method_10569("blockSize", this.blockSize);
        super.method_5652(tag);
    }

    @Override
    public void method_5749(class_2487 tag) {
        this.field_7099 = class_2350.values()[tag.method_10571("direction")];
        this.scroll = class_1799.method_57360(method_56673(), tag.method_10562("scroll")).orElse(class_1799.field_8037);
        this.blockSize = tag.method_10550("blockSize");

        this.method_6892(this.field_7099);
        this.setShowsStrokeOrder(tag.method_10577("showsStrokeOrder"));

        this.recalculateDisplay();
        this.method_6895();

        super.method_5749(tag);
    }

    @Override
    public void method_5808(double pX, double pY, double pZ, float pYaw, float pPitch) {
        this.method_5814(pX, pY, pZ);
    }

    @Override
    public void method_5759(double x, double y, double z, float yRot, float xRot, int steps) {
        class_2338 blockpos = this.field_51589.method_10069((int) (x - this.method_23317()), (int) (y - this.method_23318()), (int) (z - this.method_23321()));
        this.method_5814(blockpos.method_10263(), blockpos.method_10264(), blockpos.method_10260());
    }

    @Nullable
    @Override
    public class_1799 method_31480() {
        return this.scroll.method_7972();
    }
}
