package at.petrak.hexcasting.common.lib;

import at.petrak.hexcasting.api.HexAPI;
import at.petrak.hexcasting.common.recipe.ingredient.state.*;
import at.petrak.hexcasting.xplat.IXplatAbstractions;
import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import java.util.List;
import java.util.Random;
import java.util.function.BiConsumer;
import net.minecraft.class_1799;
import net.minecraft.class_2248;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_6862;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public class HexStateIngredients {
    public static final Codec<StateIngredient> TYPED_CODEC = Codec.lazyInitialized(() -> IXplatAbstractions.INSTANCE
            .getStateIngredientRegistry()
            .method_39673()
            .dispatch("type", StateIngredient::getType, StateIngredientType::codec));
    public static final class_9139<class_9129, StateIngredient> TYPED_STREAM_CODEC = class_9135
            .method_56365(HexRegistries.STATE_INGREDIENT)
            .method_56440(StateIngredient::getType, StateIngredientType::streamCodec);

    public static final StateIngredientType<StateIngredientBlock> BLOCK_TYPE = new StateIngredientBlock.Type();
    public static final StateIngredientType<StateIngredientBlockState> BLOCK_STATE = new StateIngredientBlockState.Type();
    public static final StateIngredientType<StateIngredientBlocks> BLOCKS = new StateIngredientBlocks.Type();
    public static final StateIngredientType<StateIngredientTag> TAG = new StateIngredientTag.Type();
    public static final StateIngredientType<StateIngredientTagExcluding> TAG_EXCLUDING = new StateIngredientTagExcluding.Type();

    public static final StateIngredientType<? extends StateIngredient> NONE_TYPE = new StateIngredientType<>() {
        @Override
        public MapCodec<StateIngredient> codec() {
            return MapCodec.unit(NONE);
        }

        @Override
        public class_9139<class_9129, StateIngredient> streamCodec() {
            return class_9139.method_56431(NONE);
        }
    };

    public static final StateIngredient NONE = new StateIngredient() {
        @Override
        public boolean test(class_2680 state) {
            return true;
        }

        @Override
        public class_2680 pick(Random random) {
            throw new UnsupportedOperationException("Should never try to pick from NONE state ingredient");
        }

        @Override
        public StateIngredientType<?> getType() {
            return NONE_TYPE;
        }

        @Override
        public List<class_1799> getDisplayedStacks() {
            return List.of();
        }

        @Override
        public List<class_2680> getDisplayed() {
            return List.of();
        }
    };

    public static void register(BiConsumer<StateIngredientType<?>, class_2960> r) {
        r.accept(NONE_TYPE, HexAPI.modLoc("none"));
        r.accept(BLOCK_TYPE, HexAPI.modLoc("block"));
        r.accept(BLOCK_STATE, HexAPI.modLoc("state"));
        r.accept(BLOCKS, HexAPI.modLoc("blocks"));
        r.accept(TAG, HexAPI.modLoc("tag"));
        r.accept(TAG_EXCLUDING, HexAPI.modLoc("tag_excluding"));
    }

    public static StateIngredient of(class_2248 block) {
        return new StateIngredientBlock(block);
    }

    public static StateIngredient of(class_2680 state) {
        return new StateIngredientBlockState(state);
    }

    public static StateIngredient of(class_6862<class_2248> tag) {
        return new StateIngredientTag(tag);
    }
}
