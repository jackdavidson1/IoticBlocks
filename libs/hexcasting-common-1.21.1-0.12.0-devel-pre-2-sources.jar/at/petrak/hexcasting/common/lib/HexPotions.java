package at.petrak.hexcasting.common.lib;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.function.BiConsumer;
import net.minecraft.class_1293;
import net.minecraft.class_1802;
import net.minecraft.class_1842;
import net.minecraft.class_1845;
import net.minecraft.class_1847;
import net.minecraft.class_2960;
import net.minecraft.class_5455;
import net.minecraft.class_7924;

import static at.petrak.hexcasting.api.HexAPI.modLoc;

public class HexPotions {
    private static final Map<class_2960, class_1842> POTIONS = new LinkedHashMap<>();

    public static final class_1842 ENLARGE_GRID = make("enlarge_grid",
        new class_1842("enlarge_grid", new class_1293(HexMobEffects.ENLARGE_GRID, 3600)));
    public static final class_1842 ENLARGE_GRID_LONG = make("enlarge_grid_long",
        new class_1842("enlarge_grid_long", new class_1293(HexMobEffects.ENLARGE_GRID, 9600)));
    public static final class_1842 ENLARGE_GRID_STRONG = make("enlarge_grid_strong",
        new class_1842("enlarge_grid_strong", new class_1293(HexMobEffects.ENLARGE_GRID, 1800, 1)));

    public static final class_1842 SHRINK_GRID = make("shrink_grid",
        new class_1842("shrink_grid", new class_1293(HexMobEffects.SHRINK_GRID, 3600)));
    public static final class_1842 SHRINK_GRID_LONG = make("shrink_grid_long",
        new class_1842("shrink_grid_long", new class_1293(HexMobEffects.SHRINK_GRID, 9600)));
    public static final class_1842 SHRINK_GRID_STRONG = make("shrink_grid_strong",
        new class_1842("shrink_grid_strong", new class_1293(HexMobEffects.SHRINK_GRID, 1800, 1)));

    public static void registerPotions(BiConsumer<class_1842, class_2960> r) {
        for (var e : POTIONS.entrySet()) {
            r.accept(e.getValue(), e.getKey());
        }
    }

    public static void addRecipes(class_1845.class_9665 builder, class_5455 registryAccess) {
        var potionRegistry = registryAccess.method_30530(class_7924.field_41215);

        builder.method_59705(class_1847.field_8999, HexItems.AMETHYST_DUST, potionRegistry.method_47983(ENLARGE_GRID));
        builder.method_59705(potionRegistry.method_47983(ENLARGE_GRID), class_1802.field_8725, potionRegistry.method_47983(ENLARGE_GRID_LONG));
        builder.method_59705(potionRegistry.method_47983(ENLARGE_GRID), class_1802.field_8601, potionRegistry.method_47983(ENLARGE_GRID_STRONG));

        builder.method_59705(potionRegistry.method_47983(ENLARGE_GRID), class_1802.field_8711, potionRegistry.method_47983(SHRINK_GRID));
        builder.method_59705(potionRegistry.method_47983(ENLARGE_GRID_LONG), class_1802.field_8711, potionRegistry.method_47983(SHRINK_GRID_LONG));
        builder.method_59705(potionRegistry.method_47983(ENLARGE_GRID_STRONG), class_1802.field_8711, potionRegistry.method_47983(SHRINK_GRID_STRONG));

        builder.method_59705(potionRegistry.method_47983(SHRINK_GRID), class_1802.field_8725, potionRegistry.method_47983(SHRINK_GRID_LONG));
        builder.method_59705(potionRegistry.method_47983(SHRINK_GRID), class_1802.field_8601, potionRegistry.method_47983(SHRINK_GRID_STRONG));
    }

    private static <T extends class_1842> T make(String id, T potion) {
        var old = POTIONS.put(modLoc(id), potion);
        if (old != null) {
            throw new IllegalArgumentException("Typo? Duplicate id " + id);
        }
        return potion;
    }
}
