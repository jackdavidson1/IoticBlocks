package at.petrak.hexcasting.common.lib;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import net.minecraft.class_8177;

public class HexBlockSetTypes {
    public static void registerBlocks(Consumer<class_8177> r) {
        for (var type : TYPES) {
            r.accept(type);
        }
    }

    private static final List<class_8177> TYPES = new ArrayList<>();

    public static final class_8177 EDIFIED_WOOD = register(
        new class_8177("edified_wood")
    );

    private static class_8177 register(class_8177 type) {
        TYPES.add(type);
        return type;
    }
}
