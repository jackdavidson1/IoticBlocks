package at.petrak.hexcasting.common.lib;

import at.petrak.hexcasting.common.command.BrainsweepCommand;
import at.petrak.hexcasting.common.command.ListPerWorldPatternsCommand;
import at.petrak.hexcasting.common.command.PatternTexturesCommand;
import at.petrak.hexcasting.common.command.RecalcPatternsCommand;
import com.mojang.brigadier.CommandDispatcher;
import net.minecraft.class_2168;
import net.minecraft.class_2170;

public class HexCommands {
    public static void register(CommandDispatcher<class_2168> dispatcher) {
        var mainCmd = class_2170.method_9247("hexcasting");

        BrainsweepCommand.add(mainCmd);
        ListPerWorldPatternsCommand.add(mainCmd);
        RecalcPatternsCommand.add(mainCmd);
        PatternTexturesCommand.add(mainCmd);

        dispatcher.register(mainCmd);
    }
}
