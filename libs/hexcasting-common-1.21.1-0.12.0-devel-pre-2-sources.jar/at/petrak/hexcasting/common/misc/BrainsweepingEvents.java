package at.petrak.hexcasting.common.misc;

import at.petrak.hexcasting.xplat.IXplatAbstractions;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1297;
import net.minecraft.class_1308;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_3966;
import org.jetbrains.annotations.Nullable;

public class BrainsweepingEvents {
    public static class_1269 interactWithBrainswept(class_1657 player, class_1937 world, class_1268 hand,
        class_1297 entity, @Nullable class_3966 hitResult) {
        if (entity instanceof class_1308 mob && IXplatAbstractions.INSTANCE.isBrainswept(mob)) {
            // As in, this interaction "successfully" consumes the result and doesn't pass it on
            return class_1269.field_5812;
        }

        return class_1269.field_5811;
    }

    public static class_1269 copyBrainsweepPostTransformation(class_1309 original, class_1309 outcome) {
        if (original instanceof class_1308 mOriginal && outcome instanceof class_1308 mOutcome
            && IXplatAbstractions.INSTANCE.isBrainswept(mOriginal)) {
            IXplatAbstractions.INSTANCE.setBrainsweepAddlData(mOutcome);
        }
        return class_1269.field_5811;
    }
}
