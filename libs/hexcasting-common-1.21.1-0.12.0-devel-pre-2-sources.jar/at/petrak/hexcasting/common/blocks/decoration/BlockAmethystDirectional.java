package at.petrak.hexcasting.common.blocks.decoration;

import com.mojang.serialization.MapCodec;
import net.minecraft.class_1676;
import net.minecraft.class_1750;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2318;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3965;

public class BlockAmethystDirectional extends class_2318 {
    public static final MapCodec<BlockAmethystDirectional> CODEC = method_54094(BlockAmethystDirectional::new);

    public BlockAmethystDirectional(class_2251 properties) {
        super(properties);
    }

    @Override
    protected MapCodec<? extends class_2318> method_53969() {
        return field_46280;
    }

    public void method_19286(class_1937 level, class_2680 state, class_3965 result, class_1676 projectile) {
        if (!level.field_9236) {
            class_2338 pos = result.method_17777();
            level.method_8396(null, pos, class_3417.field_26982, class_3419.field_15245, 1.0F, 0.5F + level.field_9229.method_43057() * 1.2F);
            level.method_8396(null, pos, class_3417.field_26980, class_3419.field_15245, 1.0F, 0.5F + level.field_9229.method_43057() * 1.2F);
        }
    }

    protected void method_9515(class_2689.class_2690<class_2248, class_2680> $$0) {
        $$0.method_11667(field_10927);
    }

    public class_2680 method_9605(class_1750 ctx) {
        return this.method_9564().method_11657(field_10927, ctx.method_8038());
    }
}