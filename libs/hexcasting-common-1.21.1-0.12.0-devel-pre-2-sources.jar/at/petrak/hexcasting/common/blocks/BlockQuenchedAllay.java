package at.petrak.hexcasting.common.blocks;

import at.petrak.hexcasting.common.blocks.entity.BlockEntityQuenchedAllay;
import at.petrak.hexcasting.common.particles.ConjureParticleOptions;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2343;
import net.minecraft.class_2350;
import net.minecraft.class_2394;
import net.minecraft.class_243;
import net.minecraft.class_2464;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_3532;
import net.minecraft.class_5819;
import org.jetbrains.annotations.Nullable;

public class BlockQuenchedAllay extends class_2248 implements class_2343 {
    public static final int VARIANTS = 4;

    public BlockQuenchedAllay(class_2251 properties) {
        super(properties);
    }

    @Nullable
    @Override
    public class_2586 method_10123(class_2338 pos, class_2680 state) {
        return new BlockEntityQuenchedAllay(this, pos, state);
    }

    @Override
    public class_2464 method_9604(class_2680 state) {
        return class_2464.field_11455;
    }

    @Override
    public void method_9496(class_2680 state, class_1937 level, class_2338 pos, class_5819 rand) {
        class_2394 options = new ConjureParticleOptions(0x8932b8);
        class_243 center = class_243.method_24953(pos);
        for (class_2350 direction : class_2350.values()) {
            int dX = direction.method_10148();
            int dY = direction.method_10164();
            int dZ = direction.method_10165();

            int count = rand.method_43048(10) / 4;
            for (int i = 0; i < count; i++) {
                double pX = center.field_1352 + (dX == 0 ? class_3532.method_15366(rand, -0.5D, 0.5D) : (double) dX * 0.55D);
                double pY = center.field_1351 + (dY == 0 ? class_3532.method_15366(rand, -0.5D, 0.5D) : (double) dY * 0.55D);
                double pZ = center.field_1350 + (dZ == 0 ? class_3532.method_15366(rand, -0.5D, 0.5D) : (double) dZ * 0.55D);
                double vPerp = class_3532.method_15366(rand, 0.0, 0.01);
                double vX = vPerp * dX;
                double vY = vPerp * dY;
                double vZ = vPerp * dZ;
                level.method_8406(options, pX, pY, pZ, vX, vY, vZ);
            }
        }
    }
}
