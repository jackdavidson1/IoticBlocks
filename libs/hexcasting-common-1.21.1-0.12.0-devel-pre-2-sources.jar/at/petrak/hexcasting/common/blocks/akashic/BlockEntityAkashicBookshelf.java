package at.petrak.hexcasting.common.blocks.akashic;

import at.petrak.hexcasting.api.block.HexBlockEntity;
import at.petrak.hexcasting.api.casting.iota.Iota;
import at.petrak.hexcasting.api.casting.iota.IotaType;
import at.petrak.hexcasting.api.casting.math.HexPattern;
import at.petrak.hexcasting.client.render.HexPatternPoints;
import at.petrak.hexcasting.common.lib.HexBlockEntities;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2509;
import net.minecraft.class_2680;
import net.minecraft.class_7225;
import org.jetbrains.annotations.Nullable;

public class BlockEntityAkashicBookshelf extends HexBlockEntity {
    public static final String TAG_PATTERN = "pattern";
    public static final String TAG_IOTA = "iota";
    public static final String TAG_DUMMY = "dummy";

    // This is only not null if this stores any data.
    private HexPattern pattern = null;
    // TODO port: check if it works
    // When the world is first loading we can sometimes try to deser this from nbt without the world existing yet.
    // We also need a way to display the iota to the client.
    // For both these cases we save just the tag of the iota.
    private Iota iota = null;

    public HexPatternPoints points;

    public BlockEntityAkashicBookshelf(class_2338 pWorldPosition, class_2680 pBlockState) {
        super(HexBlockEntities.AKASHIC_BOOKSHELF_TILE, pWorldPosition, pBlockState);
    }

    @Nullable
    public HexPattern getPattern() {
        return pattern;
    }

    @Nullable
    public Iota getIota() {
        return iota;
    }

    /*@Nullable
    public Tag getIotaTag() {
        return iotaTag;
    }*/

    public void setNewMapping(HexPattern pattern, Iota iota) {
        var previouslyEmpty = this.pattern == null;
        this.pattern = pattern;
        this.iota = iota;
        //this.iotaTag = IotaType.TYPED_CODEC.encodeStart(NbtOps.INSTANCE, iota).getOrThrow();

        if (previouslyEmpty) {
            var oldBs = this.method_11010();
            var newBs = oldBs.method_11657(BlockAkashicBookshelf.HAS_BOOKS, true);
            this.field_11863.method_8652(this.method_11016(), newBs, 3);
            this.field_11863.method_8413(this.method_11016(), oldBs, newBs, 3);
        } else {
            this.method_5431();
        }
    }

    public void clearIota() {
        var previouslyEmpty = this.pattern == null;
        this.pattern = null;
        //this.iotaTag = null;
        this.iota = null;

        if (!previouslyEmpty) {
            var oldBs = this.method_11010();
            var newBs = oldBs.method_11657(BlockAkashicBookshelf.HAS_BOOKS, false);
            this.field_11863.method_8652(this.method_11016(), newBs, 3);
            this.field_11863.method_8413(this.method_11016(), oldBs, newBs, 3);
        } else {
            this.method_5431();
        }
    }

    @Override
    protected void saveModData(class_2487 compoundTag, class_7225.class_7874 registries) {
        if (this.pattern != null && this.iota != null) {
            compoundTag.method_10566(TAG_PATTERN, HexPattern.CODEC.encodeStart(class_2509.field_11560, pattern).getOrThrow());
            compoundTag.method_10566(TAG_IOTA, IotaType.TYPED_CODEC.encodeStart(class_2509.field_11560, iota).getOrThrow());
        } else {
            compoundTag.method_10556(TAG_DUMMY, false);
        }
    }

    @Override
    protected void loadModData(class_2487 tag, class_7225.class_7874 registries) {
        if (tag.method_10545(TAG_PATTERN) && tag.method_10545(TAG_IOTA)) {
            this.pattern = HexPattern.CODEC.parse(class_2509.field_11560, tag.method_10562(TAG_PATTERN)).getOrThrow();
            //this.iotaTag = tag.getCompound(TAG_IOTA);
            this.iota = IotaType.TYPED_CODEC.parse(class_2509.field_11560, tag.method_10562(TAG_IOTA)).getOrThrow();
        } else if (tag.method_10545(TAG_DUMMY)) {
            this.pattern = null;
            //this.iotaTag = null;
            this.iota = null;
        }
    }
}
