package at.petrak.hexcasting.common.msgs;

import at.petrak.hexcasting.api.HexAPI;
import at.petrak.hexcasting.common.items.storage.ItemSpellbook;
import at.petrak.hexcasting.common.lib.HexDataComponents;
import at.petrak.hexcasting.common.lib.HexItems;
import at.petrak.hexcasting.common.lib.HexSounds;
import net.minecraft.class_124;
import net.minecraft.class_1268;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_3419;
import net.minecraft.class_5250;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import net.minecraft.class_9334;
import net.minecraft.server.MinecraftServer;

/**
 * Sent client->server when the client shift+scrolls with a shift-scrollable item
 * or scrolls in the spellcasting UI.
 */
public record MsgShiftScrollC2S(double mainHandDelta, double offHandDelta, boolean isCtrl, boolean invertSpellbook,
                                boolean invertAbacus) implements class_8710 {
    public static final class_8710.class_9154<MsgShiftScrollC2S> TYPE = new class_8710.class_9154<>(HexAPI.modLoc("scroll"));

    public static final class_9139<class_9129, MsgShiftScrollC2S> STREAM_CODEC = class_9139.method_56906(
            class_9135.field_48553, MsgShiftScrollC2S::mainHandDelta,
            class_9135.field_48553, MsgShiftScrollC2S::offHandDelta,
            class_9135.field_48547, MsgShiftScrollC2S::isCtrl,
            class_9135.field_48547, MsgShiftScrollC2S::invertSpellbook,
            class_9135.field_48547, MsgShiftScrollC2S::invertAbacus,
            MsgShiftScrollC2S::new
    );

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }

    public void handle(MinecraftServer server, class_3222 sender) {
        server.execute(() -> {
            handleForHand(sender, class_1268.field_5808, mainHandDelta);
            handleForHand(sender, class_1268.field_5810, offHandDelta);
        });
    }

    private void handleForHand(class_3222 sender, class_1268 hand, double delta) {
        if (delta != 0) {
            var stack = sender.method_5998(hand);

            if (stack.method_7909() == HexItems.SPELLBOOK) {
                spellbook(sender, hand, stack, delta);
            } else if (stack.method_7909() == HexItems.ABACUS) {
                abacus(sender, hand, stack, delta);
            }
        }
    }

    private void spellbook(class_3222 sender, class_1268 hand, class_1799 stack, double delta) {
        if (invertSpellbook) {
            delta = -delta;
        }

        var newIdx = ItemSpellbook.rotatePageIdx(stack, delta < 0.0, sender.method_37908());

        var len = ItemSpellbook.highestPage(stack);

        var sealed = ItemSpellbook.isSealed(stack);

        class_5250 component;
        if (hand == class_1268.field_5810 && stack.method_57826(class_9334.field_49631)) {
            if (sealed) {
                component = class_2561.method_43469("hexcasting.tooltip.spellbook.page_with_name.sealed",
                    class_2561.method_43470(String.valueOf(newIdx)).method_27692(class_124.field_1068),
                    class_2561.method_43470(String.valueOf(len)).method_27692(class_124.field_1068),
                    class_2561.method_43470("").method_27692(stack.method_7932().method_58413()).method_27692(class_124.field_1056)
                        .method_10852(stack.method_7964()),
                    class_2561.method_43471("hexcasting.tooltip.spellbook.sealed").method_27692(class_124.field_1065));
            } else {
                component = class_2561.method_43469("hexcasting.tooltip.spellbook.page_with_name",
                    class_2561.method_43470(String.valueOf(newIdx)).method_27692(class_124.field_1068),
                    class_2561.method_43470(String.valueOf(len)).method_27692(class_124.field_1068),
                    class_2561.method_43470("").method_27692(stack.method_7932().method_58413()).method_27692(class_124.field_1056)
                        .method_10852(stack.method_7964()));
            }

        } else {
            if (sealed) {
                component = class_2561.method_43469("hexcasting.tooltip.spellbook.page.sealed",
                    class_2561.method_43470(String.valueOf(newIdx)).method_27692(class_124.field_1068),
                    class_2561.method_43470(String.valueOf(len)).method_27692(class_124.field_1068),
                    class_2561.method_43471("hexcasting.tooltip.spellbook.sealed").method_27692(class_124.field_1065));
            } else {
                component = class_2561.method_43469("hexcasting.tooltip.spellbook.page",
                    class_2561.method_43470(String.valueOf(newIdx)).method_27692(class_124.field_1068),
                    class_2561.method_43470(String.valueOf(len)).method_27692(class_124.field_1068));
            }
        }

        sender.method_7353(component.method_27692(class_124.field_1080), true);
    }

    private void abacus(class_3222 sender, class_1268 hand, class_1799 stack, double delta) {
        if (invertAbacus) {
            delta = -delta;
        }

        var increase = delta < 0;
        Double num = stack.method_57824(HexDataComponents.ABACUS_VALUE);
        if(num == null)
            num = 0.0;

        double shiftDelta;
        float pitch;
        if (hand == class_1268.field_5808) {
            shiftDelta = this.isCtrl ? 10 : 1;
            pitch = this.isCtrl ? 0.7f : 0.9f;
        } else {
            shiftDelta = this.isCtrl ? 0.01 : 0.1;
            pitch = this.isCtrl ? 1.3f : 1.0f;
        }

        int scale = Math.max((int) Math.floor(Math.abs(delta)), 1);

        num += scale * shiftDelta * (increase ? 1 : -1);
        stack.method_57379(HexDataComponents.ABACUS_VALUE, num);

        pitch *= (increase ? 1.05f : 0.95f);
        pitch += (Math.random() - 0.5) * 0.1;
        sender.method_37908().method_43128(null, sender.method_23317(), sender.method_23318(), sender.method_23321(),
            HexSounds.ABACUS, class_3419.field_15248, 0.5f, pitch);

        var datum = HexItems.ABACUS.readIota(stack);
        if (datum != null) {
            var popup = datum.display();
            sender.method_7353(
                class_2561.method_43469("hexcasting.tooltip.abacus", popup).method_27692(class_124.field_1060), true);
        }
    }
}
