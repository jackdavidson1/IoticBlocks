package at.petrak.hexcasting.common.msgs;

import at.petrak.hexcasting.api.HexAPI;
import at.petrak.hexcasting.common.entities.EntityWallScroll;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2604;
import net.minecraft.class_310;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

// https://github.com/VazkiiMods/Botania/blob/1.18.x/Xplat/src/main/java/vazkii/botania/network/clientbound/PacketSpawnDoppleganger.java
public record MsgNewWallScrollS2C(class_2604 inner, class_2338 pos, class_2350 dir, class_1799 scrollItem,
                                  boolean showsStrokeOrder, int blockSize) implements class_8710 {
    public static final class_8710.class_9154<MsgNewWallScrollS2C> TYPE = new class_8710.class_9154<>(HexAPI.modLoc("wallscr"));

    public static final class_9139<class_9129, MsgNewWallScrollS2C> STREAM_CODEC = class_9139.method_58025(
            class_2604.field_47896, MsgNewWallScrollS2C::inner,
            class_2338.field_48404, MsgNewWallScrollS2C::pos,
            class_2350.field_48450, MsgNewWallScrollS2C::dir,
            class_1799.field_48349, MsgNewWallScrollS2C::scrollItem,
            class_9135.field_48547, MsgNewWallScrollS2C::showsStrokeOrder,
            class_9135.field_48550, MsgNewWallScrollS2C::blockSize,
            MsgNewWallScrollS2C::new
    );

    @Override
    public class_8710.class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }

    public void handle() {
        Handler.handle(this);
    }

    public static final class Handler {

        public static void handle(MsgNewWallScrollS2C self) {
            class_310.method_1551().execute(() -> {
                var player = class_310.method_1551().field_1724;
                if (player != null) {
                    player.field_3944.method_11112(self.inner);
                    var e = player.method_37908().method_8469(self.inner.method_11167());
                    if (e instanceof EntityWallScroll scroll) {
                        scroll.readSpawnData(self.pos, self.dir, self.scrollItem, self.showsStrokeOrder,
                                self.blockSize);
                    }
                }
            });
        }
    }
}
