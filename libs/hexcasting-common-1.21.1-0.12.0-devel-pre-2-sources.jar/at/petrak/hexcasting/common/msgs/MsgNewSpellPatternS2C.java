package at.petrak.hexcasting.common.msgs;

import at.petrak.hexcasting.api.HexAPI;
import at.petrak.hexcasting.api.casting.eval.ExecutionClientView;
import at.petrak.hexcasting.client.gui.GuiSpellcasting;
import at.petrak.hexcasting.common.lib.HexSounds;
import net.minecraft.class_310;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

/**
 * Sent server->client when the player finishes casting a spell.
 */
public record MsgNewSpellPatternS2C(ExecutionClientView info, int index) implements class_8710 {
    public static final class_8710.class_9154<MsgNewSpellPatternS2C> TYPE = new class_8710.class_9154<>(HexAPI.modLoc("pat_sc"));

    public static final class_9139<class_9129, MsgNewSpellPatternS2C> STREAM_CODEC = class_9139.method_56435(
            ExecutionClientView.getSTREAM_CODEC(), MsgNewSpellPatternS2C::info,
            class_9135.field_48550, MsgNewSpellPatternS2C::index,
            MsgNewSpellPatternS2C::new
    );

    @Override
    public class_8710.class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }

    public void handle() {
        Handler.handle(this);
    }

    public static final class Handler {

        public static void handle(MsgNewSpellPatternS2C self) {
            class_310.method_1551().execute(() -> {
                var mc = class_310.method_1551();
                if (self.info().isStackClear()) {
                    // don't pay attention to the screen, so it also stops when we die
                    mc.method_1483().method_4875(HexSounds.CASTING_AMBIANCE.method_14833(), null);
                }
                var screen = class_310.method_1551().field_1755;
                if (screen instanceof GuiSpellcasting spellGui) {
                    spellGui.recvServerUpdate(self.info(), self.index());
                }
            });
        }
    }
}
