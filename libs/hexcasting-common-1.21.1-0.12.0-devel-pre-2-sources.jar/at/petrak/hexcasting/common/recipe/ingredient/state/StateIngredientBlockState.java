package at.petrak.hexcasting.common.recipe.ingredient.state;

import at.petrak.hexcasting.common.lib.HexStateIngredients;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import javax.annotation.Nullable;
import net.minecraft.class_124;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2248;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_2769;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import java.util.*;

public class StateIngredientBlockState implements StateIngredient {
    private final class_2680 state;

    public StateIngredientBlockState(class_2680 state) {
        this.state = state;
    }

    @Override
    public StateIngredientType<?> getType() {
        return HexStateIngredients.BLOCK_STATE;
    }

    @Override
    public boolean test(class_2680 blockState) {
        return this.state == blockState;
    }

    @Override
    public class_2680 pick(Random random) {
        return state;
    }

    @Override
    public List<class_1799> getDisplayedStacks() {
        class_2248 block = state.method_26204();
        if (block.method_8389() == class_1802.field_8162) {
            return Collections.emptyList();
        }
        return Collections.singletonList(new class_1799(block));
    }

    @Nullable
    @Override
    public List<class_2561> descriptionTooltip() {
        Map<class_2769<?>, Comparable<?>> map = state.method_11656();
        if (map.isEmpty()) {
            return StateIngredient.super.descriptionTooltip();
        }
        List<class_2561> tooltip = new ArrayList<>(map.size());
        for (Map.Entry<class_2769<?>, Comparable<?>> entry : map.entrySet()) {
            class_2769<?> key = entry.getKey();
            @SuppressWarnings({"unchecked", "rawtypes"})
            String name = ((class_2769) key).method_11901(entry.getValue());

            tooltip.add(class_2561.method_43470(key.method_11899() + " = " + name).method_27692(class_124.field_1080));
        }
        return tooltip;
    }

    @Override
    public List<class_2680> getDisplayed() {
        return Collections.singletonList(state);
    }

    public class_2680 getState() {
        return state;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        return state == ((StateIngredientBlockState) o).state;
    }

    @Override
    public int hashCode() {
        return state.hashCode();
    }

    @Override
    public String toString() {
        return "StateIngredientBlockState{" + state + "}";
    }


    public static class Type implements StateIngredientType<StateIngredientBlockState> {
        public static final MapCodec<StateIngredientBlockState> CODEC = RecordCodecBuilder.mapCodec(instance -> instance.group(
                class_2680.field_24734.fieldOf("state").forGetter(StateIngredientBlockState::getState)
        ).apply(instance, StateIngredientBlockState::new));
        public static final class_9139<class_9129, StateIngredientBlockState> STREAM_CODEC = class_9139.method_56434(
                class_9135.field_48550.method_56432(class_2248::method_9531, class_2248::method_9507), StateIngredientBlockState::getState,
                StateIngredientBlockState::new
        );

        @Override
        public MapCodec<StateIngredientBlockState> codec() {
            return CODEC;
        }

        @Override
        public class_9139<class_9129, StateIngredientBlockState> streamCodec() {
            return STREAM_CODEC;
        }
    }
}