package at.petrak.hexcasting.common.items;

import at.petrak.hexcasting.common.lib.HexItems;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1810;
import net.minecraft.class_1832;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2680;

public class ItemJewelerHammer extends class_1810 {
    public ItemJewelerHammer(class_1832 tier, class_1793 props) {
        super(tier, props);
    }

    public static boolean shouldFailToBreak(class_1657 player, class_2680 state, class_2338 pos) {
        class_1799 stack = player.method_6047();
        return stack.method_31574(HexItems.JEWELER_HAMMER) && class_2248.method_9614(state.method_26218(player.method_37908(), pos));
    }
}
