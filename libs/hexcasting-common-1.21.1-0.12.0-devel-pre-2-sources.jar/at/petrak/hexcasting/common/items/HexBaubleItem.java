package at.petrak.hexcasting.common.items;

import com.google.common.collect.Multimap;
import net.minecraft.class_1320;
import net.minecraft.class_1322;
import net.minecraft.class_1799;
import net.minecraft.class_6880;

/**
 * Why don't we just use the same API mod on Forge and Fabric? Beats me. botania does it like this.
 * I feel like botnia probably does it this way becase it's older than xplat curios
 */
public interface HexBaubleItem {
    Multimap<class_6880<class_1320>, class_1322> getHexBaubleAttrs(class_1799 stack);
}
