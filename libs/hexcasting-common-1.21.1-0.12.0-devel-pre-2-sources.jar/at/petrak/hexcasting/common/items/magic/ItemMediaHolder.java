package at.petrak.hexcasting.common.items.magic;

import at.petrak.hexcasting.api.item.MediaHolderItem;
import at.petrak.hexcasting.api.misc.MediaConstants;
import at.petrak.hexcasting.api.utils.MathUtils;
import at.petrak.hexcasting.api.utils.MediaHelper;
import at.petrak.hexcasting.common.lib.HexDataComponents;
import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.util.List;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_2561;
import net.minecraft.class_5251;

public abstract class ItemMediaHolder extends class_1792 implements MediaHolderItem {
    public static final String TAG_MEDIA = "hexcasting:media";
    public static final String TAG_MAX_MEDIA = "hexcasting:start_media";

    public static final class_5251 HEX_COLOR = class_5251.method_27717(0xb38ef3);

    private static final DecimalFormat PERCENTAGE = new DecimalFormat("####");

    static {
        PERCENTAGE.setRoundingMode(RoundingMode.DOWN);
    }

    private static final DecimalFormat DUST_AMOUNT = new DecimalFormat("###,###.##");

    public ItemMediaHolder(class_1793 pProperties) {
        super(pProperties);
    }

    public static class_1799 withMedia(class_1799 stack, long media, long maxMedia) {
        class_1792 item = stack.method_7909();
        if (item instanceof ItemMediaHolder) {
            stack.method_57379(HexDataComponents.MEDIA, media);
            stack.method_57379(HexDataComponents.MEDIA_MAX, media);
        }

        return stack;
    }

    @Override
    public long getMedia(class_1799 stack) {
        var media = stack.method_57824(HexDataComponents.MEDIA);
        return media != null ? media : 0L;
    }

    @Override
    public long getMaxMedia(class_1799 stack) {
        var maxMedia = stack.method_57824(HexDataComponents.MEDIA_MAX);
        return maxMedia != null ? maxMedia : 0L;
    }

    @Override
    public void setMedia(class_1799 stack, long media) {
        stack.method_57379(HexDataComponents.MEDIA, MathUtils.clamp(media, 0, getMaxMedia(stack)));
    }

    @Override
    public boolean method_31567(class_1799 pStack) {
        return getMaxMedia(pStack) > 0;
    }

    @Override
    public int method_31571(class_1799 pStack) {
        var media = getMedia(pStack);
        var maxMedia = getMaxMedia(pStack);
        return MediaHelper.mediaBarColor(media, maxMedia);
    }

    @Override
    public int method_31569(class_1799 pStack) {
        var media = getMedia(pStack);
        var maxMedia = getMaxMedia(pStack);
        return MediaHelper.mediaBarWidth(media, maxMedia);
    }

    // TODO port: where did it came from?
    /*@Override
    public boolean canBeDepleted() {
        return false;
    }*/

    @Override
    public void method_7851(class_1799 stack, class_9635 context, List<class_2561> tooltipComponents, class_1836 tooltipFlag) {
        var maxMedia = getMaxMedia(stack);
        if (maxMedia > 0) {
            var media = getMedia(stack);
            var fullness = getMediaFullness(stack);

            var color = class_5251.method_27717(MediaHelper.mediaBarColor(media, maxMedia));

            var mediamount = class_2561.method_43470(DUST_AMOUNT.format(media / (float) MediaConstants.DUST_UNIT));
            var percentFull = class_2561.method_43470(PERCENTAGE.format(100f * fullness) + "%");
            var maxCapacity = class_2561.method_43469("hexcasting.tooltip.media", DUST_AMOUNT.format(maxMedia / (float) MediaConstants.DUST_UNIT));

            mediamount.method_27694(style -> style.method_27703(HEX_COLOR));
            maxCapacity.method_27694(style -> style.method_27703(HEX_COLOR));
            percentFull.method_27694(style -> style.method_27703(color));

            tooltipComponents.add(
                class_2561.method_43469("hexcasting.tooltip.media_amount.advanced",
                    mediamount, maxCapacity, percentFull));
        }

        super.method_7851(stack, context, tooltipComponents, tooltipFlag);
    }
}
