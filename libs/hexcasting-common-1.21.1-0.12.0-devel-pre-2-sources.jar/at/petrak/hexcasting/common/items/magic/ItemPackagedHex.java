package at.petrak.hexcasting.common.items.magic;

import at.petrak.hexcasting.api.casting.ParticleSpray;
import at.petrak.hexcasting.api.casting.eval.env.PackagedItemCastEnv;
import at.petrak.hexcasting.api.casting.eval.vm.CastingVM;
import at.petrak.hexcasting.api.casting.iota.Iota;
import at.petrak.hexcasting.api.casting.iota.PatternIota;
import at.petrak.hexcasting.api.item.HexHolderItem;
import at.petrak.hexcasting.api.pigment.FrozenPigment;
import at.petrak.hexcasting.common.lib.HexDataComponents;
import at.petrak.hexcasting.common.msgs.MsgNewSpiralPatternsS2C;
import at.petrak.hexcasting.xplat.IXplatAbstractions;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1304;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1839;
import net.minecraft.class_1937;
import net.minecraft.class_243;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3419;
import net.minecraft.class_3445;
import net.minecraft.class_3468;

import static at.petrak.hexcasting.api.HexAPI.modLoc;

/**
 * Item that holds a list of patterns in it ready to be cast
 */
public abstract class ItemPackagedHex extends ItemMediaHolder implements HexHolderItem {
    public static final String TAG_PROGRAM = "patterns";
    public static final String TAG_PIGMENT = "pigment";
    public static final class_2960 HAS_PATTERNS_PRED = modLoc("has_patterns");

    public ItemPackagedHex(class_1793 pProperties) {
        super(pProperties);
    }

    public abstract boolean breakAfterDepletion();

    public abstract int cooldown();

    @Override
    public boolean canRecharge(class_1799 stack) {
        return !breakAfterDepletion();
    }

    @Override
    public boolean canProvideMedia(class_1799 stack) {
        return false;
    }

    @Override
    public boolean hasHex(class_1799 stack) {
        return stack.method_57826(HexDataComponents.HEX_HOLDER_PATTERNS);
    }

    @Override
    public @Nullable List<Iota> getHex(class_1799 stack, class_3218 level) {
        return stack.method_57824(HexDataComponents.HEX_HOLDER_PATTERNS);
    }

    @Override
    public void writeHex(class_1799 stack, List<Iota> program, @Nullable FrozenPigment pigment, long media) {
        stack.method_57379(HexDataComponents.HEX_HOLDER_PATTERNS, program);
        if (pigment != null)
            stack.method_57379(HexDataComponents.PIGMENT, pigment);

        withMedia(stack, media, media);
    }

    @Override
    public void clearHex(class_1799 stack) {
        stack.method_57381(HexDataComponents.HEX_HOLDER_PATTERNS);
        stack.method_57381(HexDataComponents.PIGMENT);
        stack.method_57381(HexDataComponents.MEDIA);
        stack.method_57381(HexDataComponents.MEDIA_MAX);
    }

    @Override
    public @Nullable FrozenPigment getPigment(class_1799 stack) {
        return stack.method_57824(HexDataComponents.PIGMENT);
    }

    @Override
    public class_1271<class_1799> method_7836(class_1937 world, class_1657 player, class_1268 usedHand) {
        var stack = player.method_5998(usedHand);
        if (!hasHex(stack)) {
            return class_1271.method_22431(stack);
        }

        if (world.field_9236) {
            return class_1271.method_22427(stack);
        }

        List<Iota> instrs = getHex(stack, (class_3218) world);
        if (instrs == null) {
            return class_1271.method_22431(stack);
        }
        var sPlayer = (class_3222) player;
        var ctx = new PackagedItemCastEnv(sPlayer, usedHand);
        var vm = CastingVM.empty(ctx);
        var clientView = vm.queueExecuteAndWrapIotas(instrs, sPlayer.method_51469());

        var patterns = instrs.stream()
                .filter(i -> i instanceof PatternIota)
                .map(i -> ((PatternIota) i).getPattern())
                .toList();
        var packet = new MsgNewSpiralPatternsS2C(sPlayer.method_5667(), patterns, 140);
        IXplatAbstractions.INSTANCE.sendPacketToPlayer(sPlayer, packet);
        IXplatAbstractions.INSTANCE.sendPacketTracking(sPlayer, packet);

        boolean broken = breakAfterDepletion() && getMedia(stack) == 0;

        class_3445<?> stat;
        if (broken) {
            stat = class_3468.field_15383.method_14956(this);
        } else {
            stat = class_3468.field_15372.method_14956(this);
        }
        player.method_7259(stat);

        sPlayer.method_7357().method_7906(this, this.cooldown());

        if (clientView.getResolutionType().getSuccess()) {
            // Somehow we lost spraying particles on each new pattern, so do it here
            // this also nicely prevents particle spam on trinkets
            new ParticleSpray(player.method_19538(), new class_243(0.0, 1.5, 0.0), 0.4, Math.PI / 3, 30)
                    .sprayParticles(sPlayer.method_51469(), ctx.getPigment());
        }

        var sound = ctx.getSound().sound();
        if (sound != null) {
            var soundPos = sPlayer.method_19538();
            sPlayer.method_37908().method_43128(null, soundPos.field_1352, soundPos.field_1351, soundPos.field_1350,
                    sound, class_3419.field_15248, 1f, 1f);
        }

        if (broken) {
            stack.method_7934(1);
            sPlayer.method_20235(stack.method_7909(), usedHand == class_1268.field_5808 ? class_1304.field_6173 : class_1304.field_6171);
            return class_1271.method_22428(stack);
        } else {
            return class_1271.method_22427(stack);
        }
    }

    @Override
    public class_1839 method_7853(class_1799 pStack) {
        return class_1839.field_8949;
    }
}
