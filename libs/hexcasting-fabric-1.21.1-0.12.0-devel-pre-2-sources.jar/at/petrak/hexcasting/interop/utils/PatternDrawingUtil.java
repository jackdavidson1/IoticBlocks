package at.petrak.hexcasting.interop.utils;

import at.petrak.hexcasting.api.casting.math.HexCoord;
import at.petrak.hexcasting.api.casting.math.HexPattern;
import at.petrak.hexcasting.api.utils.HexUtils;
import at.petrak.hexcasting.client.render.RenderLib;
import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.datafixers.util.Pair;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import net.minecraft.class_241;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_5253;
import net.minecraft.class_757;

public final class PatternDrawingUtil {
    public static void drawPattern(class_332 graphics, int x, int y, List<PatternEntry> patterns, List<class_241> dots,
                   boolean strokeOrder, int outer, int innerLight, int innerDark,
                   int dotColor) {
        var poseStack = graphics.method_51448();
        poseStack.method_22903();
        poseStack.method_46416(x, y, 1);
        var mat = poseStack.method_23760().method_23761();
        var prevShader = RenderSystem.getShader();
        RenderSystem.setShader(class_757::method_34540);
//        RenderSystem.disableDepthTest();
        RenderSystem.disableCull();
        RenderSystem.blendFunc(GlStateManager.class_4535.SRC_ALPHA, GlStateManager.class_4534.ONE_MINUS_SRC_ALPHA);

        // mark center
//        RenderLib.drawSpot(mat, Vec2.ZERO, 0f, 0f, 0f, 1f);

        for (var pat : patterns) {
            RenderLib.drawLineSeq(mat, pat.zappyPoints(), 5f, 0, outer, outer);
            RenderLib.drawLineSeq(mat, pat.zappyPoints(), 2f, 0,
                strokeOrder ? innerDark : innerLight, innerLight);

            if (strokeOrder) {
                RenderLib.drawSpot(mat, pat.zappyPoints().get(0), 2.5f, 1f, 0.1f, 0.15f, 0.6f);
            }
        }

        float dotR = class_5253.class_5254.method_27765(dotColor) / 255f;
        float dotG = class_5253.class_5254.method_27766(dotColor) / 255f;
        float dotB = class_5253.class_5254.method_27767(dotColor) / 255f;
        float dotA = class_5253.class_5254.method_27762(dotColor) / 255f;

        for (var dot : dots) {
            RenderLib.drawSpot(mat, dot, 1.5f, dotR, dotG, dotB, dotA);
        }

        RenderSystem.defaultBlendFunc();
        RenderSystem.setShader(() -> prevShader);

        RenderSystem.enableCull();

        poseStack.method_22909();
    }

    public static PatternRenderingData loadPatterns(List<Pair<HexPattern, HexCoord>> patterns,
        float readabilityOffset, float lastLineLenProp) {
        var patternEntries = new ArrayList<PatternEntry>(patterns.size());

        var fakeScale = 1;
        var seenFakePoints = new ArrayList<class_241>();
        var seenCoords = new HashSet<HexCoord>();
        for (var pair : patterns) {
            var pattern = pair.getFirst();
            var origin = pair.getSecond();
            for (var pos : pattern.positions(origin)) {
                var px = HexUtils.coordToPx(pos, fakeScale, class_241.field_1340);
                seenFakePoints.add(px);
            }

            // And while we're looping add the (COORD ONLY) things internally
            patternEntries.add(new PatternEntry(pattern, origin, new ArrayList<>()));
            seenCoords.addAll(pattern.positions(origin));
        }
        var fakeCom = HexUtils.findCenter(seenFakePoints);

        var maxDx = -1f;
        var maxDy = -1f;
        for (var dot : seenFakePoints) {
            var dx = class_3532.method_15379(dot.field_1343 - fakeCom.field_1343);
            if (dx > maxDx) {
                maxDx = dx;
            }
            var dy = class_3532.method_15379(dot.field_1342 - fakeCom.field_1342);
            if (dy > maxDy) {
                maxDy = dy;
            }
        }
        var hexSize = Math.min(12, Math.min(120 / 2.5f / maxDx, 70 / 2.5f / maxDy));

        var seenRealPoints = new ArrayList<class_241>();
        for (var pat : patternEntries) {
            for (var pos : pat.pattern().positions(pat.origin())) {
                var px = HexUtils.coordToPx(pos, hexSize, class_241.field_1340);
                seenRealPoints.add(px);
            }
        }
        var realCom = HexUtils.findCenter(seenRealPoints);

        // and NOW for real!
        for (int i = 0; i < patternEntries.size(); i++) {
            PatternEntry pat = patternEntries.get(i);
            var localOrigin = HexUtils.coordToPx(pat.origin(), hexSize, realCom.method_35588());
            var points = pat.pattern().toLines(hexSize, localOrigin);
            pat.zappyPoints()
                .addAll(RenderLib.makeZappy(points, RenderLib.findDupIndices(pat.pattern().positions()), 10, 0.8f, 0f,
                    0f, readabilityOffset, lastLineLenProp, i));
        }

        var pathfinderDots = seenCoords.stream()
            .map(coord -> HexUtils.coordToPx(coord, hexSize, realCom.method_35588())).toList();

        return new PatternRenderingData(patternEntries, pathfinderDots, hexSize);
    }

    public record PatternRenderingData(List<PatternEntry> patterns, List<class_241> pathfinderDots, float hexSize) {
        // NO-OP
    }
}
