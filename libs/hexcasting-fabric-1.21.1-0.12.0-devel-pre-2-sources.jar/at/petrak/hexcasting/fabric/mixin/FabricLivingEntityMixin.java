package at.petrak.hexcasting.fabric.mixin;

import at.petrak.hexcasting.xplat.IForgeLikeBlock;
import net.minecraft.class_1309;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3532;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(class_1309.class)
public class FabricLivingEntityMixin {
    @Unique
    private class_2680 hex$cachedParticleState;

    @ModifyVariable(method = "checkFallDamage", at = @At(value = "LOAD", ordinal = 0), argsOnly = true)
    private class_2680 overwrite(class_2680 state, double d, boolean bl, class_2680 _ignored, class_2338 pos) {
        class_1309 entity = (class_1309) (Object) this;

        if (state.method_26204() instanceof IForgeLikeBlock forgeLike) {
            float dist = (float) class_3532.method_15386(entity.field_6017 - 3.0F);
            double e = Math.min(0.2F + dist / 15.0F, 2.5D);
            int i = (int)(150.0D * e);
            if (forgeLike.addLandingEffects(state, (class_3218) entity.method_37908(), pos, entity, i)) {
                hex$cachedParticleState = state;
                return class_2246.field_10124.method_9564();
            }
        }

        return state;
    }

    @ModifyArg(method = "checkFallDamage", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/Entity;checkFallDamage(DZLnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/core/BlockPos;)V"))
    private class_2680 restore(class_2680 state) {
        if (hex$cachedParticleState != null) {
            class_2680 cached = hex$cachedParticleState;
            hex$cachedParticleState = null;
            return cached;
        }
        return state;
    }
}
