package at.petrak.hexcasting.fabric.mixin;

import at.petrak.hexcasting.fabric.event.VillagerConversionCallback;
import net.minecraft.class_1299;
import net.minecraft.class_1308;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1308.class)
public class FabricMobMixin {
    @Inject(method = "convertTo", at = @At("RETURN"))
    public <T extends class_1308> void onThunderHit(class_1299<T> entityType, boolean bl, CallbackInfoReturnable<T> cir) {
        var self = (class_1308) (Object) this;
        var mob = cir.getReturnValue();
        if (mob != null) {
            VillagerConversionCallback.EVENT.invoker().interact(self, mob);
        }
    }
}
