package at.petrak.hexcasting.fabric.mixin;

import at.petrak.hexcasting.xplat.IForgeLikeBlock;
import net.minecraft.class_1937;
import net.minecraft.class_2331;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_2331.class)
public class FabricEnchantmentTableBlockMixin {
    @Inject(method = "isValidBookShelf", at = @At("HEAD"), cancellable = true)
    private static void treatAsBookshelf(class_1937 level, class_2338 blockPos, class_2338 blockPos2, CallbackInfoReturnable<Boolean> cir) {
        class_2680 state = level.method_8320(blockPos.method_10081(blockPos2));
        if (state.method_26204() instanceof IForgeLikeBlock forgeLike) {
            boolean emptyBetween = level.method_22347(blockPos.method_10069(blockPos2.method_10263() / 2, blockPos2.method_10264(), blockPos2.method_10260() / 2));
            cir.setReturnValue(emptyBetween && forgeLike.hasEnchantPowerBonus(state, level, blockPos));
        }
    }
}
