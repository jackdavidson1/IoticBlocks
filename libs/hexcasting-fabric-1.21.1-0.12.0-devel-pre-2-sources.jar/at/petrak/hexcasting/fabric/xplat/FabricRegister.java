package at.petrak.hexcasting.fabric.xplat;

import at.petrak.hexcasting.xplat.IXplatRegister;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Supplier;
import net.minecraft.class_2378;
import net.minecraft.class_5321;
import net.minecraft.class_6880;
import net.minecraft.class_7923;

import static at.petrak.hexcasting.api.HexAPI.modLoc;

public class FabricRegister<B> implements IXplatRegister<B> {
    private final class_2378<B> register;
    private final Map<String, B> map;

    @SuppressWarnings("unchecked")
    public FabricRegister(class_5321<class_2378<B>> registryKey) {
        this.register = (class_2378<B>) class_7923.field_41167.method_10223(registryKey.method_29177());
        this.map = new HashMap<>();
    }

    @SuppressWarnings("unchecked")
    public FabricRegister(class_5321<class_2378<B>> registryKey, Map<String, B> map) {
        this.register = (class_2378<B>) class_7923.field_41167.method_10223(registryKey.method_29177());
        this.map = map;
    }


    @Override
    public <T extends B> Supplier<T> register(String id, Supplier<T> provider) {
        T value = provider.get();
        class_2378.method_10230(register, modLoc(id), value);
        return () -> value;
    }

    @Override
    public <T extends B> class_6880<B> registerHolder(String id, Supplier<T> provider) {
        T value = provider.get();
        map.put(id, value);
        return register.method_47983(value);
    }

    @Override
    public void registerAll() {
        map.forEach((string, value) ->
                class_2378.method_10230(register, modLoc(string), value)
        );
    }
}
