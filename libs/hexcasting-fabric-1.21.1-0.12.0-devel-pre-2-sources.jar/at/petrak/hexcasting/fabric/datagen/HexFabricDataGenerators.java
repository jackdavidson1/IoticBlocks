package at.petrak.hexcasting.fabric.datagen;

import at.petrak.hexcasting.api.HexAPI;
import at.petrak.hexcasting.datagen.HexLootTables;
import at.petrak.hexcasting.datagen.IXplatIngredients;
import at.petrak.hexcasting.datagen.recipe.HexplatRecipes;
import at.petrak.hexcasting.datagen.recipe.builders.FarmersDelightToolIngredient;
import at.petrak.hexcasting.datagen.tag.HexActionTagProvider;
import at.petrak.hexcasting.datagen.tag.HexBlockTagProvider;
import at.petrak.hexcasting.datagen.tag.HexItemTagProvider;
import at.petrak.hexcasting.fabric.recipe.FabricModConditionalIngredient;
import at.petrak.hexcasting.xplat.IXplatAbstractions;
import com.google.gson.JsonObject;
import net.fabricmc.fabric.api.datagen.v1.DataGeneratorEntrypoint;
import net.fabricmc.fabric.api.datagen.v1.FabricDataGenerator;
import net.minecraft.class_173;
import net.minecraft.class_1767;
import net.minecraft.class_1769;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1856;
import net.minecraft.class_2438;
import net.minecraft.class_2960;
import net.minecraft.class_6862;
import net.minecraft.class_7877;
import net.minecraft.class_7924;
import net.minecraft.world.item.*;
import java.util.EnumMap;
import java.util.List;
import java.util.Set;
import java.util.stream.Stream;

public class HexFabricDataGenerators implements DataGeneratorEntrypoint {
    @Override
    public void onInitializeDataGenerator(FabricDataGenerator gen) {
        HexAPI.LOGGER.info("Starting Fabric-specific datagen");

        var pack = gen.createPack();
        var xtags = IXplatAbstractions.INSTANCE.tags();
        var provider = gen.getRegistries();

        pack.addProvider((FabricDataGenerator.Pack.Factory<HexplatRecipes>) x -> new HexplatRecipes(x, provider, INGREDIENTS, HexFabricConditionsBuilder::new));

        var btagProviderWrapper = new BlockTagProviderWrapper(); // CURSED
        pack.addProvider((output, lookup) -> {
            btagProviderWrapper.provider = new HexBlockTagProvider(output, lookup, xtags);
            return btagProviderWrapper.provider;
        });
        pack.addProvider((output, lookup) -> new HexItemTagProvider(output, lookup, btagProviderWrapper.provider.method_49662(), xtags));

        pack.addProvider(HexActionTagProvider::new);

        pack.addProvider((FabricDataGenerator.Pack.Factory<class_2438>) (output) -> new class_2438(
                output, Set.of(), List.of(new class_2438.class_7790(HexLootTables::new, class_173.field_1177)), provider
        ));
    }

    private static class BlockTagProviderWrapper {
        HexBlockTagProvider provider;
    }

    private static final IXplatIngredients INGREDIENTS = new IXplatIngredients() {
        @Override
        public class_1856 glowstoneDust() {
            return new class_1856(Stream.of(
                new class_1856.class_1857(new class_1799(class_1802.field_8601)),
                new class_1856.class_1858(tag("glowstone_dusts"))
            ));
        }

        @Override
        public class_1856 leather() {
            // apparently c:leather also includes rabbit hide
            return class_1856.method_8091(class_1802.field_8745);
        }

        @Override
        public class_1856 ironNugget() {
            return new class_1856(Stream.of(
                new class_1856.class_1857(new class_1799(class_1802.field_8675)),
                new class_1856.class_1858(tag("iron_nuggets"))
            ));
        }

        @Override
        public class_1856 goldNugget() {
            return new class_1856(Stream.of(
                new class_1856.class_1857(new class_1799(class_1802.field_8397)),
                new class_1856.class_1858(tag("gold_nuggets"))
            ));
        }

        @Override
        public class_1856 copperIngot() {
            return new class_1856(Stream.of(
                new class_1856.class_1857(new class_1799(class_1802.field_27022)),
                new class_1856.class_1858(tag("copper_ingots"))
            ));
        }

        @Override
        public class_1856 ironIngot() {
            return new class_1856(Stream.of(
                new class_1856.class_1857(new class_1799(class_1802.field_8620)),
                new class_1856.class_1858(tag("iron_ingots"))
            ));
        }

        @Override
        public class_1856 goldIngot() {
            return new class_1856(Stream.of(
                new class_1856.class_1857(new class_1799(class_1802.field_8695)),
                new class_1856.class_1858(tag("gold_ingots"))
            ));
        }

        @Override
        public EnumMap<class_1767, class_1856> dyes() {
            var out = new EnumMap<class_1767, class_1856>(class_1767.class);
            for (var col : class_1767.values()) {
                out.put(col, new class_1856(Stream.of(
                    new class_1856.class_1857(new class_1799(class_1769.method_7803(col))),
                    new class_1856.class_1858(
                        class_6862.method_40092(class_7924.field_41197,
                            class_2960.method_60655("c", col.method_15434() + "_dye"))),
                    new class_1856.class_1858(
                        class_6862.method_40092(class_7924.field_41197,
                            class_2960.method_60655("c", col.method_15434() + "_dyes"))
                    ))));
            }
            return out;
        }

        @Override
        public class_1856 stick() {
            return new class_1856(Stream.of(
                new class_1856.class_1857(new class_1799(class_1802.field_8600)),
                new class_1856.class_1858(tag("wood_sticks"))
            ));
        }

        @Override
        public class_1856 whenModIngredient(class_1856 defaultIngredient, String modid, class_1856 modIngredient) {
            return FabricModConditionalIngredient.of(defaultIngredient, modid, modIngredient);
        }

        private final FarmersDelightToolIngredient AXE_INGREDIENT = () -> {
            JsonObject object = new JsonObject();
            object.addProperty("type", "farmersdelight:tool");
            object.addProperty("tag", "c:tools/axes");
            return object;
        };

        @Override
        public FarmersDelightToolIngredient axeStrip() {
            return AXE_INGREDIENT;
        }

        @Override
        public FarmersDelightToolIngredient axeDig() {
            return AXE_INGREDIENT;
        }
    };

    private static class_6862<class_1792> tag(String s) {
        return tag("c", s);
    }

    private static class_6862<class_1792> tag(String namespace, String s) {
        return class_6862.method_40092(class_7924.field_41197, class_2960.method_60655(namespace, s));
    }

    @Override
    public void buildRegistry(class_7877 registryBuilder) {

    }
}
