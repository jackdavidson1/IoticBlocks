package at.petrak.hexcasting.fabric.cc;

import at.petrak.hexcasting.api.player.AltioraAbility;
import net.minecraft.class_1657;
import net.minecraft.class_2487;
import net.minecraft.class_7225;
import org.jetbrains.annotations.Nullable;
import org.ladysnake.cca.api.v3.component.Component;
import org.ladysnake.cca.api.v3.component.sync.AutoSyncedComponent;

public class CCAltiora implements Component, AutoSyncedComponent {
    public static final String
        TAG_ALLOWED = "allowed",
        TAG_GRACE = "grace_period";

    @Nullable
    private AltioraAbility altiora = null;

    private final class_1657 owner;

    public CCAltiora(class_1657 owner) {
        this.owner = owner;
    }


    @Nullable
    public AltioraAbility getAltiora() {
        return this.altiora;
    }


    public void setAltiora(AltioraAbility altiora) {
        this.altiora = altiora;
        HexCardinalComponents.ALTIORA.sync(this.owner);
    }

    @Override
    public void readFromNbt(class_2487 tag, class_7225.class_7874 registryLookup) {
        var allowed = tag.method_10577(TAG_ALLOWED);
        if (!allowed) {
            this.altiora = null;
        } else {
            var grace = tag.method_10550(TAG_GRACE);
            this.altiora = new AltioraAbility(grace);
        }
    }

    @Override
    public void writeToNbt(class_2487 tag, class_7225.class_7874 registryLookup) {
        tag.method_10556(TAG_ALLOWED, this.altiora != null);
        if (this.altiora != null) {
            tag.method_10569(TAG_GRACE, this.altiora.gracePeriod());
        }
    }
}
