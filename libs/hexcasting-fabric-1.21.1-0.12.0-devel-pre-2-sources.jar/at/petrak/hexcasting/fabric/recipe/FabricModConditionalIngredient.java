package at.petrak.hexcasting.fabric.recipe;

import at.petrak.hexcasting.xplat.IXplatAbstractions;
import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.fabricmc.fabric.api.recipe.v1.ingredient.CustomIngredient;
import net.fabricmc.fabric.api.recipe.v1.ingredient.CustomIngredientSerializer;
import net.minecraft.class_1799;
import net.minecraft.class_1856;
import net.minecraft.class_2960;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import javax.annotation.Nullable;
import java.util.Arrays;
import java.util.List;

import static at.petrak.hexcasting.api.HexAPI.modLoc;


public class FabricModConditionalIngredient extends class_1856 implements CustomIngredient {
    public static final class_2960 ID = modLoc("mod_conditional");

    private final class_1856 main;
    private final String modid;
    private final class_1856 ifModLoaded;

    private final class_1856 toUse;

    public static final MapCodec<FabricModConditionalIngredient> CODEC = RecordCodecBuilder.mapCodec(instance -> instance.group(
            class_1856.field_46095.fieldOf("main").forGetter(FabricModConditionalIngredient::getMain),
            Codec.STRING.fieldOf("modid").forGetter(FabricModConditionalIngredient::getModid),
            class_1856.field_46095.fieldOf("ifModLoaded").forGetter(FabricModConditionalIngredient::getIfModLoaded)
    ).apply(instance, FabricModConditionalIngredient::new));

    public static final class_9139<class_9129, FabricModConditionalIngredient> STREAM_CODEC = class_9139.method_56436(
            class_1856.field_48355, FabricModConditionalIngredient::getMain,
            class_9135.field_48554, FabricModConditionalIngredient::getModid,
            class_1856.field_48355, FabricModConditionalIngredient::getIfModLoaded,
            FabricModConditionalIngredient::new
    );

    protected FabricModConditionalIngredient(class_1856 main, String modid, class_1856 ifModLoaded) {
        super(Arrays.stream((IXplatAbstractions.INSTANCE.isModPresent(modid) ? ifModLoaded : main).field_9019));
        this.main = main;
        this.modid = modid;
        this.ifModLoaded = ifModLoaded;

        this.toUse = IXplatAbstractions.INSTANCE.isModPresent(modid) ? ifModLoaded : main;
    }


    public static FabricModConditionalIngredient of(class_1856 main, String modid, class_1856 ifModLoaded) {
        return new FabricModConditionalIngredient(main, modid, ifModLoaded);
    }

    @Override
    public boolean method_8093(@Nullable class_1799 input) {
        return toUse.method_8093(input);
    }

    @Override
    public List<class_1799> getMatchingStacks() {
        return List.of();
    }

    @Override
    public boolean requiresTesting() {
        return false;
    }

    public class_1856 getMain() {
        return main;
    }

    public class_1856 getToUse() {
        return toUse;
    }

    public class_1856 getIfModLoaded() {
        return ifModLoaded;
    }

    public String getModid() {
        return modid;
    }

    @Override
    public CustomIngredientSerializer<?> getSerializer() {
        return Serializer.INSTANCE;
    }

    public static class Serializer implements CustomIngredientSerializer {
        public static final Serializer INSTANCE = new Serializer();

        @Override
        public class_2960 getIdentifier() {
            return FabricModConditionalIngredient.ID;
        }

        @Override
        public MapCodec<?> getCodec(boolean b) {
            return CODEC;
        }

        @Override
        public class_9139<class_9129, ?> getPacketCodec() {
            return STREAM_CODEC;
        }
    }
}
