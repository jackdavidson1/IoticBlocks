package at.petrak.hexcasting.common.items.storage;

import at.petrak.hexcasting.annotations.SoftImplement;
import at.petrak.hexcasting.api.HexAPI;
import at.petrak.hexcasting.api.casting.iota.Iota;
import at.petrak.hexcasting.api.casting.iota.PatternIota;
import at.petrak.hexcasting.api.casting.math.HexPattern;
import at.petrak.hexcasting.api.item.IotaHolderItem;
import at.petrak.hexcasting.client.gui.PatternTooltipComponent;
import at.petrak.hexcasting.common.lib.HexDataComponents;
import at.petrak.hexcasting.common.misc.PatternTooltip;
import at.petrak.hexcasting.interop.inline.InlinePatternData;
import org.jetbrains.annotations.Nullable;

import java.util.Optional;
import net.minecraft.class_1297;
import net.minecraft.class_1542;
import net.minecraft.class_1747;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_5632;

import static at.petrak.hexcasting.api.HexAPI.modLoc;

public class ItemSlate extends class_1747 implements IotaHolderItem {
    public static final class_2960 WRITTEN_PRED = modLoc("written");

    public ItemSlate(class_2248 pBlock, class_1793 pProperties) {
        super(pBlock, pProperties);
    }

    @Override
    public class_2561 method_7864(class_1799 pStack) {
        var key = "block." + HexAPI.MOD_ID + ".slate." + (hasPattern(pStack) ? "written" : "blank");
        class_2561 patternText = getPattern(pStack)
            .map(pat -> class_2561.method_43470(": ").method_10852(new InlinePatternData(pat).asText(false)))
            .orElse(class_2561.method_43470(""));
        return class_2561.method_43471(key).method_10852(patternText);
    }

    public static Optional<HexPattern> getPattern(class_1799 stack){
        return Optional.ofNullable(stack.method_57824(HexDataComponents.PATTERN));
    }

    public static boolean hasPattern(class_1799 stack) {
        return getPattern(stack).isPresent();
    }

    @SoftImplement("IForgeItem")
    public boolean onEntityItemUpdate(class_1799 stack, class_1542 entity) {
        if (!hasPattern(stack)) {
            stack.method_57381(HexDataComponents.PATTERN);
        }
        return false;
    }

    @Override
    public void method_7888(class_1799 pStack, class_1937 pLevel, class_1297 pEntity, int pSlotId, boolean pIsSelected) {
        if (!hasPattern(pStack)) {
            pStack.method_57381(HexDataComponents.PATTERN);
        }
    }

    @Override
    public @Nullable Iota readIota(class_1799 stack) {
        return getPattern(stack).map(PatternIota::new).orElse(null);
    }

    @Override
    public boolean writeable(class_1799 stack) {
        return true;
    }

    @Override
    public boolean canWrite(class_1799 stack, Iota datum) {
        return datum instanceof PatternIota || datum == null;
    }

    @Override
    public void writeDatum(class_1799 stack, Iota datum) {
        if(this.canWrite(stack, datum)) {
            if (datum == null) {
                stack.method_57381(HexDataComponents.PATTERN);
            } else if (datum instanceof PatternIota pat) {
                stack.method_57379(HexDataComponents.PATTERN, pat.getPattern());
            }
        }
    }

    @Override
    public Optional<class_5632> method_32346(class_1799 stack) {
        return getPattern(stack).map(pat -> new PatternTooltip(pat, PatternTooltipComponent.SLATE_BG));
    }
}
