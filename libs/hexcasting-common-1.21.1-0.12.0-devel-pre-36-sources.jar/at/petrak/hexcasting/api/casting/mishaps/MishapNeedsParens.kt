package at.petrak.hexcasting.api.casting.mishaps

import at.petrak.hexcasting.api.casting.eval.CastingEnvironment
import at.petrak.hexcasting.api.casting.iota.Iota
import at.petrak.hexcasting.api.casting.iota.PatternIota
import at.petrak.hexcasting.api.pigment.FrozenPigment
import at.petrak.hexcasting.api.utils.TreeList
import net.minecraft.world.item.DyeColor

class MishapNeedsParens : Mishap() {
    override fun accentColor(ctx: CastingEnvironment, errorCtx: Context): FrozenPigment =
        dyeColor(DyeColor.ORANGE)

    override fun execute(env: CastingEnvironment, errorCtx: Context, stack: TreeList<Iota>): TreeList<Iota> {
        // TODO this is a kinda shitty mishap
        return if (errorCtx.pattern != null)
            stack.appended(PatternIota(errorCtx.pattern))
        else stack
    }

    override fun errorMessage(ctx: CastingEnvironment, errorCtx: Context) =
        error("needs_parens")
}
