package at.petrak.hexcasting.api.casting.circles;

import at.petrak.hexcasting.api.HexAPI;
import at.petrak.hexcasting.api.casting.eval.env.CircleCastEnv;
import at.petrak.hexcasting.api.casting.eval.vm.CastingImage;
import at.petrak.hexcasting.api.misc.Result;
import at.petrak.hexcasting.api.mod.HexConfig;
import at.petrak.hexcasting.api.pigment.FrozenPigment;
import at.petrak.hexcasting.api.utils.HexUtils;
import com.mojang.datafixers.util.Pair;
import net.minecraft.class_124;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2487;
import net.minecraft.class_2495;
import net.minecraft.class_2499;
import net.minecraft.class_2509;
import net.minecraft.class_2512;
import net.minecraft.class_2520;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_9380;
import net.minecraft.nbt.*;
import org.jetbrains.annotations.Nullable;

import java.util.*;

/**
 * See {@link BlockEntityAbstractImpetus}, this is what's stored in it
 */
public class CircleExecutionState {
    public static final String
        TAG_IMPETUS_POS = "impetus_pos",
        TAG_IMPETUS_DIR = "impetus_dir",
        TAG_REACHED_POSITIONS = "reached_positions",
        TAG_CURRENT_POS = "current_pos",
        TAG_ENTERED_FROM = "entered_from",
        TAG_IMAGE = "image",
        TAG_CASTER = "caster",
        TAG_PIGMENT = "pigment",
        TAG_REACHED_NUMBER = "reached_slate",
        TAG_POSITIVE_POS = "positive_pos",
        TAG_NEGATIVE_POS = "negative_pos";

    public final class_2338 impetusPos;
    public final class_2350 impetusDir;
    // Does contain the starting impetus
    public final HashSet<class_2338> reachedPositions;
    public class_2338 currentPos;
    public class_2350 enteredFrom;
    public CastingImage currentImage;
    public @Nullable UUID caster;
    public @Nullable FrozenPigment casterPigment;
    public long reachedSlate;

    // Tracks the highest pos, and lowest pos of the AABB
    public class_2338 greaterCorner;
    public class_2338 lesserCorner;

    public final class_9380 bounds;


    protected CircleExecutionState(class_2338 impetusPos, class_2350 impetusDir, HashSet<class_2338> reachedPositions,
       class_2338 currentPos, class_2350 enteredFrom, CastingImage currentImage, @Nullable UUID caster,
       @Nullable FrozenPigment casterPigment, Long reachedSlate, class_2338 greaterCorner, class_2338 lesserPos) {
        this.impetusPos = impetusPos;
        this.impetusDir = impetusDir;
        this.reachedPositions = reachedPositions;
        this.currentPos = currentPos;
        this.enteredFrom = enteredFrom;
        this.currentImage = currentImage;
        this.caster = caster;
        this.casterPigment = casterPigment;
        this.reachedSlate = reachedSlate;

        this.greaterCorner = greaterCorner;
        this.lesserCorner = lesserPos;
        this.bounds = new class_9380(greaterCorner, lesserPos);
    }

    public @Nullable class_3222 getCaster(class_3218 world) {
        if (this.caster == null) {
            return null;
        }
        var entity = world.method_14190(this.caster);
        if (entity instanceof class_3222 serverPlayer) {
            return serverPlayer;
        }
        // there's a problem if this branch is reached
        return null;
    }

    // Return OK if it succeeded; returns Err if it didn't close and the location
    public static Result<CircleExecutionState, @Nullable class_2338> createNew(BlockEntityAbstractImpetus impetus,
        @Nullable class_3222 caster) {
        var level = (class_3218) impetus.method_10997();

        if (level == null)
            return new Result.Err<>(null);

        // Flood fill! Just like VCC all over again.
        // this contains tentative positions and directions entered from
        var todo = new Stack<Pair<class_2350, class_2338>>();
        todo.add(Pair.of(impetus.getStartDirection(), impetus.method_11016().method_10093(impetus.getStartDirection())));
        var seenGoodPosSet = new HashSet<class_2338>();
        var impetusPos = impetus.method_11016();
        var positiveBlock = impetusPos.method_25503();
        var negativeBlock = impetusPos.method_25503();
        var lastBlockPos = impetusPos.method_25503();

        while (!todo.isEmpty()) {
            var pair = todo.pop();
            var enterDir = pair.getFirst();
            var herePos = pair.getSecond();

            var hereBs = level.method_8320(herePos);
            if (!(hereBs.method_26204() instanceof ICircleComponent cmp)) {
                continue;
            }
            if (!cmp.canEnterFromDirection(enterDir, herePos, hereBs, level)) {
                continue;
            }

            if (seenGoodPosSet.add(herePos)) {
                lastBlockPos.method_10101(herePos);
                // Updates the highest and or lowest corner of the Circle
                positiveBlock.method_33097(Math.max(herePos.method_10263(), positiveBlock.method_10263()));
                positiveBlock.method_33098(Math.max(herePos.method_10264(), positiveBlock.method_10264()));
                positiveBlock.method_33099(Math.max(herePos.method_10260(), positiveBlock.method_10260()));

                negativeBlock.method_33097(Math.min(herePos.method_10263(), negativeBlock.method_10263()));
                negativeBlock.method_33098(Math.min(herePos.method_10264(), negativeBlock.method_10264()));
                negativeBlock.method_33099(Math.min(herePos.method_10260(), negativeBlock.method_10260()));
                // it's new
                var outs = cmp.possibleExitDirections(herePos, hereBs, level);
                for (var out : outs) {
                    todo.add(Pair.of(out, herePos.method_10093(out)));
                }
            }
            // Who would leave out the config limit? If this is forgotten, someone could make a Spell Circle the size of a world
            if (seenGoodPosSet.size() >= HexConfig.server().maxSpellCircleLength()){
                return new Result.Err<>(null);
            }
        }

        if (lastBlockPos == impetus.method_11016()) {
            return new Result.Err<>(null);
        } else if (!seenGoodPosSet.contains(impetus.method_11016())) {
            // we can't enter from the side the impetus exits from, so this means we couldn't loop back.
            // the last item we tried to examine will always be a terminal slate (b/c if it wasn't,
            // then the *next* slate would be last qed)
            return new Result.Err<>(lastBlockPos);
        }

        var reachedPositions = new HashSet<class_2338>();
        reachedPositions.add(impetus.method_11016());

        FrozenPigment colorizer = null;
        UUID casterUUID;
        if (caster == null) {
            casterUUID = null;
        } else {
            colorizer = HexAPI.instance().getColorizer(caster);
            casterUUID = caster.method_5667();
        }
        return new Result.Ok<>(
            new CircleExecutionState(impetus.method_11016(), impetus.getStartDirection(),
                reachedPositions, impetus.method_11016().method_10081(impetus.getStartDirection().method_10163()),
                impetus.getStartDirection(), new CastingImage(), casterUUID, colorizer, 0L,
                positiveBlock.method_10100(1,1,1), negativeBlock));
    }

    public class_2487 save() {
        var out = new class_2487();

        out.method_10566(TAG_IMPETUS_POS, class_2512.method_10692(this.impetusPos));
        out.method_10567(TAG_IMPETUS_DIR, (byte) this.impetusDir.ordinal());

        var reachedTag = new class_2499();
        for (var bp : this.reachedPositions) {
            reachedTag.add(class_2512.method_10692(bp));
        }
        out.method_10566(TAG_REACHED_POSITIONS, reachedTag);

        out.method_10566(TAG_CURRENT_POS, class_2512.method_10692(this.currentPos));
        out.method_10567(TAG_ENTERED_FROM, (byte) this.enteredFrom.ordinal());
        out.method_10566(TAG_IMAGE, CastingImage.getCODEC().encodeStart(class_2509.field_11560, currentImage).getOrThrow());

        if (this.caster != null)
            out.method_25927(TAG_CASTER, this.caster);

        if (this.casterPigment != null)
            out.method_10566(TAG_PIGMENT, FrozenPigment.CODEC.encodeStart(class_2509.field_11560, casterPigment).getOrThrow());

        out.method_10544(TAG_REACHED_NUMBER, this.reachedSlate);

        out.method_10566(TAG_POSITIVE_POS,class_2512.method_10692(this.greaterCorner));
        out.method_10566(TAG_NEGATIVE_POS,class_2512.method_10692(this.lesserCorner));

        return out;
    }

    public static CircleExecutionState load(class_2487 nbt, class_3218 world) {
        var startPos = class_2512.method_10691(nbt, TAG_IMPETUS_POS).orElseThrow();
        var startDir = class_2350.values()[nbt.method_10571(TAG_IMPETUS_DIR)];

        var reachedPositions = new HashSet<class_2338>();
        var reachedTag = nbt.method_10554(TAG_REACHED_POSITIONS, class_2520.field_33260);
        for (var tag : reachedTag) {
            var pos = readBlockPos(HexUtils.downcast(tag, class_2495.field_21036).getAsIntArray());
            pos.ifPresent(reachedPositions::add);
        }

        var currentPos = class_2512.method_10691(nbt, TAG_CURRENT_POS).orElseThrow();
        var enteredFrom = class_2350.values()[nbt.method_10571(TAG_ENTERED_FROM)];
        var image = CastingImage.getCODEC().parse(class_2509.field_11560, nbt.method_10562(TAG_IMAGE)).getOrThrow();

        var reachedSlate = nbt.method_10537(TAG_REACHED_NUMBER);
        var positivePos = class_2512.method_10691(nbt, TAG_POSITIVE_POS).orElseThrow();
        var negativePos = class_2512.method_10691(nbt, TAG_NEGATIVE_POS).orElseThrow();

        UUID caster = null;
        if (nbt.method_25928(TAG_CASTER))
            caster = nbt.method_25926(TAG_CASTER);

        FrozenPigment pigment = null;
        if (nbt.method_10573(TAG_PIGMENT, class_2520.field_33260))
            pigment = FrozenPigment.CODEC.parse(class_2509.field_11560, nbt.method_10562(TAG_PIGMENT)).getOrThrow();

        return new CircleExecutionState(startPos, startDir, reachedPositions, currentPos,
            enteredFrom, image, caster, pigment, reachedSlate, positivePos, negativePos);
    }

    private static Optional<class_2338> readBlockPos(int[] aint) {
        return aint.length == 3 ? Optional.of(new class_2338(aint[0], aint[1], aint[2])) : Optional.empty();
    }

    /**
     * Update this, also mutates the impetus.
     * <p>
     * Returns whether to continue.
     */
    public boolean tick(BlockEntityAbstractImpetus impetus) {
        var world = (class_3218) impetus.method_10997();

        if (world == null)
            return true; // if the world is null, try again next tick.

        var env = new CircleCastEnv(world, this);

        var executorBlockState = world.method_8320(this.currentPos);
        if (!(executorBlockState.method_26204() instanceof ICircleComponent executor)) {
            // TODO: notification of the error?
            ICircleComponent.sfx(this.currentPos, executorBlockState, world,
                Objects.requireNonNull(env.getImpetus()), false);
            return false;
        }

        executorBlockState = executor.startEnergized(this.currentPos, executorBlockState, world);
        this.reachedPositions.add(this.currentPos);
        this.reachedSlate +=1;

        // Do the execution!
        boolean halt = false;
        var ctrl = executor.acceptControlFlow(this.currentImage, env, this.enteredFrom, this.currentPos,
            executorBlockState, world);

        if (env.getImpetus() == null)
            return false; //the impetus got removed during the cast and no longer exists in the world. stop casting

        if (ctrl instanceof ICircleComponent.ControlFlow.Stop) {
            // acceptControlFlow should have already posted the error
            halt = true;
        } else if (ctrl instanceof ICircleComponent.ControlFlow.Continue cont) {
            Pair<class_2338, class_2350> found = null;

            for (var exit : cont.exits) {
                var there = world.method_8320(exit.getFirst());
                if (there.method_26204() instanceof ICircleComponent cc
                    && cc.canEnterFromDirection(exit.getSecond(), exit.getFirst(), there, world)) {
                    if (found != null) {
                        // oh no!
                        impetus.postDisplay(
                            class_2561.method_43469("hexcasting.tooltip.circle.many_exits",
                                class_2561.method_43470(this.currentPos.method_23854()).method_27692(class_124.field_1061)),
                            new class_1799(class_1802.field_8251));
                        ICircleComponent.sfx(this.currentPos, executorBlockState, world,
                            Objects.requireNonNull(env.getImpetus()), false);
                        halt = true;
                        break;
                    } else {
                        found = exit;
                    }
                }
            }

            if (found == null) {
                // will never enter here if there were too many because found will have been set
                ICircleComponent.sfx(this.currentPos, executorBlockState, world,
                    Objects.requireNonNull(env.getImpetus()), false);
                impetus.postNoExits(this.currentPos);
                halt = true;
            } else {
                // A single valid exit position has been found.
                ICircleComponent.sfx(this.currentPos, executorBlockState, world,
                    Objects.requireNonNull(env.getImpetus()), true);
                currentPos = found.getFirst();
                enteredFrom = found.getSecond();
                currentImage = cont.update.withOverriddenUsedOps(0); // reset ops used after each slate finishes executing
            }
        }

        return !halt;
    }

    /**
     * How many ticks should pass between activations, given the number of blocks encountered so far.
     */
    protected int getTickSpeed() {
        return Math.max(2, (int) (10 - (this.reachedSlate - 1) / 3));
    }

    public void endExecution(BlockEntityAbstractImpetus impetus) {
        var world = (class_3218) impetus.method_10997();

        if (world == null)
            return; // TODO: error here?

        for (var pos : this.reachedPositions) {
            var there = world.method_8320(pos);
            if (there.method_26204() instanceof ICircleComponent cc) {
                cc.endEnergized(pos, there, world);
            }
        }
    }
}
