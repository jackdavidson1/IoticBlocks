package at.petrak.hexcasting.common.casting.actions.local

import at.petrak.hexcasting.api.casting.castables.Action
import at.petrak.hexcasting.api.casting.eval.CastingEnvironment
import at.petrak.hexcasting.api.casting.eval.OperationResult
import at.petrak.hexcasting.api.casting.eval.vm.CastingImage
import at.petrak.hexcasting.api.casting.eval.vm.SpellContinuation
import at.petrak.hexcasting.api.casting.iota.NullIota
import at.petrak.hexcasting.common.lib.hex.HexEvalSounds

object OpPeekLocal : Action {
    override fun operate(env: CastingEnvironment, image: CastingImage, continuation: SpellContinuation): OperationResult {
        val ravenmind = image.ravenmind()
        val stack = image.stack

        val rm = if (ravenmind.isPresent) {
            ravenmind.get()
        } else {
            NullIota()
        }
        val newStack = stack.appended(rm)

        // does not mutate userdata
        val image2 = image.withUsedOp().copy(stack = newStack)
        return OperationResult(image2, listOf(), continuation, HexEvalSounds.NORMAL_EXECUTE.get())
    }
}
