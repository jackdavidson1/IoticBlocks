package at.petrak.hexcasting.common.lib;

import at.petrak.hexcasting.api.casting.ActionRegistryEntry;
import at.petrak.hexcasting.api.casting.iota.Iota;
import at.petrak.hexcasting.api.casting.iota.IotaType;
import at.petrak.hexcasting.api.casting.math.HexPattern;
import at.petrak.hexcasting.api.pigment.FrozenPigment;
import at.petrak.hexcasting.xplat.IXplatAbstractions;
import at.petrak.hexcasting.xplat.IXplatRegister;
import com.mojang.serialization.Codec;
import java.util.*;
import java.util.function.Supplier;
import net.minecraft.class_2561;
import net.minecraft.class_3902;
import net.minecraft.class_5321;
import net.minecraft.class_7924;
import net.minecraft.class_8824;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import net.minecraft.class_9331;

public class HexDataComponents {
    private static final IXplatRegister<class_9331<?>> REGISTER = IXplatAbstractions.INSTANCE.createRegistar(class_7924.field_49659);

    public static void register() {
        REGISTER.registerAll();
    }

    public static final Supplier<class_9331<HexPattern>> PATTERN = REGISTER.register("pattern", () ->
            class_9331.<HexPattern>method_57873()
                    .persistent(HexPattern.CODEC)
                    .networkSynchronized(HexPattern.STREAM_CODEC)
                    .build());
    public static final Supplier<class_9331<class_5321<ActionRegistryEntry>>> ACTION = REGISTER.register("op_id", () ->
            class_9331.<class_5321<ActionRegistryEntry>>method_57873()
                    .method_57881(class_5321.method_39154(HexRegistries.ACTION))
                    .method_57882(class_5321.method_56038(HexRegistries.ACTION))
                    .method_57880());
    public static final Supplier<class_9331<class_5321<ActionRegistryEntry>>> RECALC_WARNING = REGISTER.register("recalc_warning", () ->
            class_9331.<class_5321<ActionRegistryEntry>>method_57873()
                    .method_57881(class_5321.method_39154(HexRegistries.ACTION))
                    .method_57882(class_5321.method_56038(HexRegistries.ACTION))
                    .method_57880());
    public static final Supplier<class_9331<class_3902>> NEEDS_PURCHASE = REGISTER.register("needs_purchase", () ->
            class_9331.<class_3902>method_57873()
                    .method_57882(class_9139.method_56431(class_3902.field_17274))
                    .method_57880());
    /**
     * If this datacomponent is set on the item, we ignore the rest of the item and render this as if it were of the
     * {@link at.petrak.hexcasting.api.casting.iota.IotaType IotaType} given by the resource location.
     * <p>
     * This is not useful to the player at all.
     */
    public static final Supplier<class_9331<Optional<IotaType<?>>>> VISUAL_OVERRIDE = REGISTER.register("visual_override", () ->
            class_9331.<Optional<IotaType<?>>>method_57873()
                    .method_57882(class_9135.method_56382(class_9135.method_56365(HexRegistries.IOTA_TYPE)))
                    .method_57880());
    public static final Supplier<class_9331<Integer>> ITEM_VARIANT = REGISTER.register("variant", () ->
            class_9331.<Integer>method_57873()
                    .method_57881(Codec.intRange(0, Integer.MAX_VALUE))
                    .method_57882(class_9135.field_48550)
                    .method_57880());
    public static final Supplier<class_9331<class_3902>> SEALED_IOTA_HOLDER = REGISTER.register("sealed", () ->
            class_9331.<class_3902>method_57873()
                    .method_57881(Codec.unit(class_3902.field_17274))
                    .method_57882(class_9139.method_56431(class_3902.field_17274))
                    .method_57880());
    // TODO port: Data components must implement equals and hashCode. Keep in mind they must also be immutable
    public static final Supplier<class_9331<Iota>> IOTA_HOLDER_IOTA = REGISTER.register("iota", () ->
            class_9331.<Iota>method_57873()
                    .method_57881(IotaType.TYPED_CODEC)
                    .method_57882(IotaType.TYPED_STREAM_CODEC)
                    .method_57880());

    public static final Supplier<class_9331<List<Iota>>> HEX_HOLDER_PATTERNS = REGISTER.register("patterns", () ->
            class_9331.<List<Iota>>method_57873()
                    .method_57881(IotaType.TYPED_CODEC.listOf())
                    .method_57882(IotaType.TYPED_STREAM_CODEC.method_56433(class_9135.method_56363()))
                    .method_57880());
    public static final Supplier<class_9331<Long>> MEDIA = REGISTER.register("media", () ->
            class_9331.<Long>method_57873()
                    .method_57881(Codec.LONG)
                    .method_57882(class_9135.field_48551)
                    .method_57880());
    public static final Supplier<class_9331<Long>> MEDIA_MAX = REGISTER.register("start_media", () ->
            class_9331.<Long>method_57873()
                    .method_57881(Codec.LONG)
                    .method_57882(class_9135.field_48551)
                    .method_57880());
    public static final Supplier<class_9331<String>> HEX_NAME = REGISTER.register("hex_name", () ->
            class_9331.<String>method_57873()
                    .method_57881(Codec.STRING)
                    .method_57882(class_9135.field_48554)
                    .method_57880());

    public static final Supplier<class_9331<FrozenPigment>> PIGMENT = REGISTER.register("pigment", () ->
            class_9331.<FrozenPigment>method_57873()
                    .method_57881(FrozenPigment.CODEC)
                    .method_57882(FrozenPigment.STREAM_CODEC)
                    .method_57880());

    public static final Supplier<class_9331<Double>> ABACUS_VALUE = REGISTER.register("abacus_value", () ->
            class_9331.<Double>method_57873()
                    .method_57881(Codec.DOUBLE)
                    .method_57882(class_9135.field_48553)
                    .method_57880());

    public static final Supplier<class_9331<Integer>> SELECTED_SPELLBOOK_PAGE = REGISTER.register("page_idx", () ->
            class_9331.<Integer>method_57873()
                    .method_57881(Codec.INT)
                    .method_57882(class_9135.field_49675)
                    .method_57880());

    public static final Supplier<class_9331<Map<String, Iota>>> SPELLBOOK_PAGES = REGISTER.register("pages", () ->
            class_9331.<Map<String, Iota>>method_57873()
                    .method_57881(Codec.unboundedMap(Codec.STRING, IotaType.TYPED_CODEC))
                    .method_57882(class_9135.method_56377(
                            HashMap::newHashMap,
                            class_9135.field_48554,
                            IotaType.TYPED_STREAM_CODEC
                    ))
                    .method_57880());

    public static final Supplier<class_9331<Map<String, class_2561>>> SPELLBOOK_PAGE_NAMES = REGISTER.register("page_names", () ->
            class_9331.<Map<String, class_2561>>method_57873()
                    .method_57881(Codec.unboundedMap(Codec.STRING, class_8824.field_46597))
                    .method_57882(class_9135.method_56377(
                            HashMap::newHashMap,
                            class_9135.field_48554,
                            class_8824.field_48540
                    ))
                    .method_57880());

    public static final Supplier<class_9331<Map<String, Boolean>>> SPELLBOOK_PAGE_SEALS = REGISTER.register("sealed_pages", () ->
            class_9331.<Map<String, Boolean>>method_57873()
                    .method_57881(Codec.unboundedMap(Codec.STRING, Codec.BOOL))
                    .method_57882(class_9135.method_56377(
                            HashMap::newHashMap,
                            class_9135.field_48554,
                            class_9135.field_48547
                    ))
                    .method_57880());

    public static final Supplier<class_9331<List<Long>>> MEDIA_EXTRACTIONS = REGISTER.register("media_extractions", () ->
            class_9331.<List<Long>>method_57873()
                    .method_57881(Codec.LONG.listOf())
                    .method_57882(class_9135.field_48551.method_56433(class_9135.method_56363()))
                    .method_57880());

    public static final Supplier<class_9331<List<Long>>> MEDIA_INSERTIONS = REGISTER.register("media_insertions", () ->
            class_9331.<List<Long>>method_57873()
                    .method_57881(Codec.LONG.listOf())
                    .method_57882(class_9135.field_48551.method_56433(class_9135.method_56363()))
                    .method_57880());
}
