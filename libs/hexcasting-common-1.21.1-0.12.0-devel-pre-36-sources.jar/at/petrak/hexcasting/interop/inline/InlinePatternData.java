package at.petrak.hexcasting.interop.inline;

import at.petrak.hexcasting.api.HexAPI;
import at.petrak.hexcasting.api.casting.PatternShapeMatch;
import at.petrak.hexcasting.api.casting.iota.PatternIota;
import at.petrak.hexcasting.api.casting.math.HexPattern;
import at.petrak.hexcasting.common.casting.PatternRegistryManifest;
import at.petrak.hexcasting.common.lib.HexItems;
import com.mojang.serialization.Codec;
import com.samsthenerd.inline.api.InlineData;
import net.minecraft.class_124;
import net.minecraft.class_1799;
import net.minecraft.class_2558;
import net.minecraft.class_2561;
import net.minecraft.class_2568;
import net.minecraft.class_2583;
import net.minecraft.class_2960;
import net.minecraft.class_9334;
import org.jetbrains.annotations.NotNull;

public class InlinePatternData implements InlineData<InlinePatternData>{

    public static final class_2960 rendererId = HexAPI.modLoc("pattern");

    @NotNull
    public final HexPattern pattern;

    public InlinePatternData(@NotNull HexPattern pattern){
        this.pattern = pattern;
    }

    @Override
    public InlinePatternDataType getType(){
        return InlinePatternDataType.INSTANCE;
    }

    @Override
    public class_2960 getRendererId(){
        return rendererId;
    }

    @Override
    public class_2583 getExtraStyle() {
        class_1799 scrollStack = new class_1799(HexItems.SCROLL_MEDIUM.get());
        HexItems.SCROLL_MEDIUM.get().writeDatum(scrollStack, new PatternIota(pattern));
        scrollStack.method_57379(class_9334.field_50239, getPatternName(pattern).copy().withStyle(class_124.field_1068));
        class_2568 he = new class_2568(class_2568.class_5247.field_24343, new class_2568.class_5249(scrollStack));
        class_2558 ce = new class_2558(class_2558.class_2559.field_21462, pattern.toString());
        return class_2583.field_24360.method_10949(he).method_10958(ce);
    }

    public static class_2561 getPatternName(HexPattern pattern){
        try {
            PatternShapeMatch shapeMatch = PatternRegistryManifest.matchPattern(pattern, null);
            if(shapeMatch instanceof PatternShapeMatch.Normal normMatch){
                return HexAPI.instance().getActionI18n(normMatch.key, false);
            }
            // TODO: this doesn't actually ever hit because it errors out with server castinv env stuff first :(
            if(shapeMatch instanceof PatternShapeMatch.Special specialMatch){
                return HexAPI.instance().getSpecialHandlerI18n(specialMatch.key);
            }
        } catch (Exception e){
            // nop
        }
        return PatternIota.displayNonInline(pattern);
    }

    @Override
    public class_2561 asText(boolean withExtra) {
        return class_2561.method_43470(pattern.toString()).withStyle(asStyle(withExtra));
    }

    public static class InlinePatternDataType implements InlineDataType<InlinePatternData> {
        private static final class_2960 ID = class_2960.method_60655(HexAPI.MOD_ID, "pattern");
        public static final InlinePatternDataType INSTANCE = new InlinePatternDataType();

        @Override
        public class_2960 getId(){
            return ID;
        }

        @Override
        public Codec<InlinePatternData> getCodec(){
            return HexPattern.CODEC.xmap(
                InlinePatternData::new,
                data -> data.pattern
            );
        }
    }
}
